#include "job.h"

// Nombre de processus en cours
int nbjobs = 0;

// compteur pour définir les id des processus
int job_id_counter = 0;

// Liste des processus
job * jobs = NULL;

/*
 * ajoute un processus à la liste des processus
*/
void add_job(int id, pid_t pid, char * state, char** cmd) {

	job *j = malloc(sizeof(job));
	j->id = id;
	j->pid = pid;
	j->state = strdup(state);
	
	int nbargscmd = 0;

	// compter le nombre d'arguments
	while (cmd[nbargscmd] != NULL) {
		nbargscmd ++;
	}
	
	// allouer la mémoire pour le tableau d'arguments
	j->cmd = malloc((nbargscmd + 1) * sizeof(char *));

	// copier les arguments
	for (int i = 0; i < nbargscmd; i++) {
		j->cmd[i] = strdup(cmd[i]);
	}

	// ajouter NULL à la fin du tableau
	j->cmd[nbargscmd] = NULL;

	if (jobs == NULL) {

     jobs = malloc(sizeof(job)); 
	 // Allouer la mémoire pour le premier processus

  } else {

  	jobs = realloc(jobs, (nbjobs + 1) * sizeof(job)); 
	// Redimensionner la mémoire pour ajouter un nouveau processus

  }

	// Ajouter le processus à la liste
  jobs[nbjobs] = *j; 
	nbjobs++;
}

/* 
 * Supprime un processus de la liste des processus.
*/
void remove_job(pid_t pid) {

    int index_to_remove = -1;

    // Trouver l'index du processus à supprimer
    for (int i = 0; i < nbjobs; i++) {

        if (jobs[i].pid == pid) {
            index_to_remove = i;
            break;
        }
    }

    // Si l'index n'est pas trouvé, ne rien faire
    if (index_to_remove == -1) {
        return;
    }

	// sinon, supprimer le processus
    // Libérer la mémoire allouée pour le job à supprimer
    free(jobs[index_to_remove].state);

		for (int i = 0; jobs[index_to_remove].cmd[i] != NULL; i++) {
      free(jobs[index_to_remove].cmd[i]);
    }

    free(jobs[index_to_remove].cmd);

    // Décaler tous les éléments suivants vers la gauche pour combler l'espace vide
    for (int i = index_to_remove; i < nbjobs - 1; i++) {
        jobs[i] = jobs[i + 1];
    }

    // Réduire la taille du tableau et mettre à jour le nombre de jobs
    nbjobs--;
		if (nbjobs == 0) {
			free(jobs);
			jobs = NULL;
		} else {
			jobs = realloc(jobs, (nbjobs) * sizeof(job));
  	}
}

/*
 * récupère le process id d'un processus en fonction de son 
 * minishell id
 * 0 si le processus n'existe pas dans cette liste
*/
pid_t get_pid(int id) {

	for (int i = 0; i < nbjobs; i++) {

		if (jobs[i].id == id) {
			return jobs[i].pid;
		}
	}

	return 0;
}

/* 
 * récupère les paramètres d'un processus en fonction de son 
 * id minishell.
 * Retourne un pointeur vers le job correspondant
 * Retourne NULL si aucun job ne correspond au pid donné
*/
job* get_job_id(int id) {

	for (int i = 0; i < nbjobs; i++) {

		if (jobs[i].id == id) {
			return &jobs[i];
		}
	}

	return NULL;
}


/*
 * récupère les paramètres d'un processus en fonction
 * de son process id
 * Retourne un pointeur vers le job correspondant
 * Retourne NULL si aucun job ne correspond au pid donné
*/
job* get_job(pid_t pid) {

    for (int i = 0; i < nbjobs; i++) {

        if (jobs[i].pid == pid) {
            return &jobs[i]; 
        }
    }

    return NULL;
}

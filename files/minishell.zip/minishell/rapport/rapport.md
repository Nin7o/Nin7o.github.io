Rappoort : Rendu Intermédiaire Minishell
======

## I - Questions traitées

### 1. Questions complètement traitées : 

Questions 1 à 6

### 2. Questions partiellement traitées :

Questions 7 à 11

## II - Choix de conception principaux 

Concernant la liste des processus en cours d'exécution, j'ai choisi de l'implémenter en créant une nouvelle structure de donnée contenant toutes les informations à propos du processus lancé :  

```c
struct job {
    int id;
    pid_t pid;
    char * state;
    char ** cmd;
};
```
J'ai ensuite crée une liste allouée dynamiquement de cette structure de donnée, permettant de stocker tous les processus lancés.

Concernant l'ID processus géré par le minishell, j'ai choisi de l'incrémenter à chaque fois qu'un nouveau processus est lancé, peu importe qu'il soit en avant plan ou en arrière plan. Les commandes internes ne sont pas comptabilisées dans l'ID. Le compteur gérant l'incrémentation de l'ID est quand à lui géré dans une variable à part.


Concernant l'enchaînement séquentiel des commandes, plus particulièrement en considérant la gestion des processus implantés, j'ai stocké dans une variable l'ID minishell du processus en éxecution en avant plan. C'est aussi en partie pourquoi j'ai choisi de donner un ID à chaque processus lancés par le minishell, et non pas seulement ceux en arrière plan, en plus d'être plus cohérent.
Le processus père attends donc la terminaison du processus en avant plan avant de lancer le processus suivant.
L'implémentation faite dans le code de l'attente des processus est vouée à évoluer pour plus de clareté, bien que celle ci fonctionne correctement.

Concernant les signaux : 

Pour chaque signal auquel nous souhaitons associer un comportement, j'ai créé un handler associé qui exécutera une fonction. Ce handler est défini avec la structure sigaction. Le signal initialement envoyé est donc géré différemment.
Ces handlers sont définis au lancement du programme, ainsi tous les processus lancés par le minishell auront le même comportement en cas de réception d'un signal. Comme nous le verrons plus tard, leurs comportements n'impactant en rien les processus fils eux mêmes grâce à une série de condition, ces derniers pourronts être considérés ignorés par les processus lancés depuis le minishell.

- SIGINT : SIGINT doit amener la terminaison du processus en avant plan. Comme indiqué précédemment, l'ID minishell du processus en avant plan est toujours stocké, ils nous suffit alors de récupérer le PID associé à ce processus selon la liste des processus en cours et de provoquer la terminaison du processus grâce au signal SIGTERM.
```c
kill(fg_pid, SIGTERM);
```
- SIGSTP : SIGSTP doit amener la suspension du processus en avant plan. En utilisant le même procédé que pour SIGINT, nous supendons cette fois le processus en avant plan grâce au signal SIGSTOP.
```c
kill(fg_pid, SIGSTOP);
```
- SIGCHLD : SIGCHLD est un signal envoyé par un processus fils a son pere lors de sa terminaison. Ainsi dans son handler, nous récupérons dans un premier temps le PID du processus venant de se terminer afin de faire le lien avec le processus dans la liste des processus en cours. Si ce derrnier est présent dans cette liste, nous le supprimons de la liste. Nous vérifions ensuite si le processus est en avant plan ou en arrière plan. Si il est en avant plan, nous remettons à zero l'ID minishell du processus en avant plan.

Dernier point important, tous les handler de signaux sont définis avec sigaction et le flag SA_RESTART, permettant de relancer la fonction appelée par le handler si elle est interrompue par un signal et ainsi de ne pas avoir d'erreurs à l'execution.

Concernant les redirections, si une redirection est spécifiée dans la ligne de commande, je redirige l'entrée standard ou la sortie standard vers le fichier spécifié.

Concernant les tubes, si un tube est spécifié, j'en crée autant que le nombre de commande - 1. Je redirige ensuite les entrées et sorties standards des processus fils dans les pipes, en prenant soin de ne pas rediriger l'entrée standard du premier processus et la sortie du dernier.

## III - points de blocage rencontrés: 

- Enchainement séquentiel des commandes : l'enchainement séquentiel s'est complexifié au cours des implémentations, notamment avec la gestion des processus. Le traitant nous permettais de réécrire une commande lorsque n'importe quel processus s'arrêtait, même en arrière plan. 

- Gestion de processus : La gestion des processus à causé le plus de problèmes dans mon code, en commençant par l'allocation dynamique de la mémoire du tableau, mais aussi principalement la reprise des processus en avant plan ou arrière plan. Cette implémentation nécéssiatait une bonne communication entre le processus pere et les traitant des signaux pour éviter de réimplanter simplement un wait dans la commande fg, ce qui est une implémentaion très chaotique.

## IV - Points d'amélioration :

- Création d'un module pour la gestion de la liste des processus en arrière plan.
- Séparation de la gestion des pipes en sous programmes.
- Suppression totale des variables globales hormis celles associées aux handler des signaux.
- Amélioration de la clareté générale du code.




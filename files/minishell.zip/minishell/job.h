
#ifndef JOB_H
#define JOB_H

// importation des librairies
#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <string.h>
#include <signal.h>
#include <sys/utsname.h>
#include <fcntl.h>
#include <libgen.h>


/* 
 * Définition de la structure de donnée utilisée pour la gestion
 * des processus 
 * id : id géré par le minishell
 * pid : process id du processus 
 * state : etat (suspendu, actif, ...);
 * cmd : commande exécutée
*/
struct job {
    int id;
    pid_t pid;
    char *state;
    char **cmd;
};


typedef struct job job;

/*
 * ajoute un processus à la liste des processus
*/
void add_job(int id, pid_t pid, char * state, char** cmd);

/* 
 * Supprime un processus de la liste des processus.
*/
void remove_job(pid_t pid);

/*
 * récupère le process id d'un processus en fonction de son 
 * minishell id
 * 0 si le processus n'existe pas dans cette liste
*/
pid_t get_pid(int id);

/* 
 * récupère les paramètres d'un processus en fonction de son 
 * id minishell.
 * Retourne un pointeur vers le job correspondant
 * Retourne NULL si aucun job ne correspond au pid donné
*/
job* get_job_id(int id);

/*
 * récupère les paramètres d'un processus en fonction
 * de son process id
 * Retourne un pointeur vers le job correspondant
 * Retourne NULL si aucun job ne correspond au pid donné
*/
job* get_job(pid_t pid);

#endif

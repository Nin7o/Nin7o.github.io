# Projet UART

### Carte cible : Nexys 4 DDR

## Avancement

L'UART est fonctionnel. A l'aide de minicom, le composant EchoUnit affiche bien 
"Hello " lors de l'appui sur le bouton central (reset). De même, les touches du 
clavier sont bien reportées sur minicom, ce qui montre que la communication 
série est fonctionnelle. 

AUCHERE Nathan - GAUTHIER Nino

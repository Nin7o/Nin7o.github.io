# Hagidoop

## Structure  du projet

```bash
./
├── data/
│   ├── filesample.txt
│   ├── filesamplekv.txt
│   └── generate.sh
├── doc/
│   ├── sujet-hagidoop.pdf
│   └── sujet-slides.pdf
├── scripts/
│   ├── kill.sh
│   ├── clean.sh
│   └── deploy.sh
└── src/
    ├── application/
    │   ├── Count.java
    ├── config/
    │   └── Project.java
    ├── daemon/
    │   ├── JobLauncher.java
    │   ├── WorkerImpl.java
    │   └── Worker.java
    ├── hdfs/
    │   ├── DataChunk.java
    │   ├── HdfsServer.java
    │   └── HdfsClient.java
    ├── interfaces/
    │   ├── FileReaderWriter.java
    │   ├── KV.java
    │   ├── Map.java
    │   ├── MapReduce.java
    │   ├── NetworkReaderWriter.java
    │   ├── Reader.java
    │   ├── ReaderWriter.java
    │   ├── Reduce.java
    │   └── Writer.java
    ├── io/
    │   ├── ImplFileReaderWriter.java
    │   └── ImplNetworkReaderWriter.java
    └── mapReduce/
        ├── KVMapReduce.java
        ├── TThread2.java
        └── MyMapReduce.java
```

- config : inclut les fichiers de configuration de hagidoop (notamment un fichier listant les nœuds du cluster)
- data : contient les fichiers de données que l'on peut traiter avec hagidoop. generate.sh est un script permettant de générer de gros fichier pour les évaluations (gros, c'est au moins
1 Gb).
- doc : pour la documentation
- scripts : pour les scripts de déploiement si je veux pouvoir lancer en une commande tous les daemons sur un ensemble de nœuds.
- src/application : les sources des applications. Je donne ici les 2 versions du WordCount en version iterative et MR.
- src/config : les classes qui doivent permettre de configurer hagidoop, par exemple lire le fichier listant les nœuds du cluster
- src/daemon : les classes implantant la partie hagidoop, c'est à dire Worker et JobLauncher
- src/hdfs : les classes implantant HDFS
- src/interface : les interfaces que je vous donne, pour le modèle de programmation MR (Map, Reduce, MapReduce) et pour la gestion des entrées-sorties (KV, Reader, Writer, ReaderWriter, FileReaderWriter, NetworkReaderWriter)
- src/io : les classes implantant les interfaces ci-dessus pour la gestion des entrées-sorties

SETUP : 

- src/application/Project.java : modifier les paths en fonction de son systeme
- scripts/deploy.sh
         /kill.sh
         /clean.sh : modifier les paths et login en fonction de son système

- config/nodes.txt : écrire ce fichier de configurations sous la forme : 
    "<adresse_node> <portHDFS> <portHagidoop>\n<adresse_node> <portHDFS>.....<portHagidoop>\0"


Scripts : 

- generate.sh : il a été modifié maison pour utiliser /work (/tmp/ a une limite de taille, inutilisable facilement pour générer + de 3go)

- deploy.sh : compile et deploie hdfs & hagidoop 

- kill.sh : kill tous les daemon HDFS & hagidoop

- clean.sh :  kill tout les daemons HDFS & hagidoop, récupère le répertoire que les nodes HDFS utilisent depuis Project.java et le nettoie.

Commandes Java :
A lancer dans /bin/

- hdfs.HdfsClient write <txt|kx> <filename>
- hdfs.HdfsClient read <filename>
- hdfs.HdfsClient delete <filename>
- hdfs.HdfsClient list

- mapReduce.MyMapReduce <filename>
- mapReduce.KVMapReduce <kvfilename>
- mapReduce.Thread2 <filename> <nb_of_threads>


## Résultats

### En local : 
les tests en local seront effectués sur la même machine, en listant dans le fichier nodes plusieurs fois localhost. 
Cela permet d'avoir un aperçu de la rapidité du programme sans les perturbations liées au réseau, ainsi que d'être certain
que tous les threads fonctionnent à une vitesse équivalente.

CPU : 6 coeurs - 12 threads - fréquence max : 4.2GHz
4 daemon HDFS | 4 daemons WorkerImpl

##### HDFS

Temps de transmission d'un fichier de 20Go sur HDFS : 
```bash
________________________________________________________
Executed in  613.85 secs    fish           external
   usr time  553.99 secs    0.00 micros  553.99 secs
   sys time   32.55 secs  594.00 micros   32.55 secs
```
soit environ ~2Go/min

Temps de récupération d'un fichier de 20Go sur HDFS : 
```bash
________________________________________________________
Executed in  559.10 secs    fish           external
   usr time  138.98 secs  310.00 micros  138.98 secs
   sys time   36.81 secs  196.00 micros   36.81 secs
```
temps équivalent / plus faible, aucun clacul de taille nécéssaire

```bash
0da6e2ad466062738008e63b0e94f362372a7f0630122c3ba643b0fcfabc185d  ../clientDir/data24.txt
0da6e2ad466062738008e63b0e94f362372a7f0630122c3ba643b0fcfabc185d  ../data/data24.txt
```
les deux checksum sont les mêmes, les fichiers sont donc les mêmes avant et après envoi.

##### hagidoop 

Lancement du mapReduce : 

```bash
➜ java mapReduce.MyMapReduce data24.txt
[+] Opening NetworkReaderWriter server on : 192.168.1.88:4000
[!] file /home/nin7o/Documents/Cours/hagidoop/clientDir/result-data24.txt already exists !
All writes will be appened to the file so that no data is lost.
You might want to delete the file and restart the process.
[+] fileReaderWriter opened on file /home/nin7o/Documents/Cours/hagidoop/clientDir/result-data24.txt in write mode
[+] New connection to the server !
[+] New connection to the server !
[+] New connection to the server !
[+] New connection to the server !
[-] Disconnection from a client
[-] Disconnection from a client
[-] Disconnection from a client
[-] Disconnection from a client
[-] fileReaderWriter on file /home/nin7o/Documents/Cours/hagidoop/clientDir/result-data24.txt closed
[-] Closing NetworkReaderWriter server
Job finished ! The result of the reduce can be found in : /home/nin7o/Documents/Cours/hagidoop/clientDir/result-data24.txt
time in ms =136620
```
temps : 136s

Lancement du mapReduce multithreadé. on donnera 3 threads à chaque Map

```bash
java mapReduce.Thread2 data24.txt 3
nbThreads = 3
[+] Opening NetworkReaderWriter server on : 192.168.1.88:4000
[!] file /home/nin7o/Documents/Cours/hagidoop/clientDir/result-data24.txt already exists !
All writes will be appened to the file so that no data is lost.
You might want to delete the file and restart the process.
[+] fileReaderWriter opened on file /home/nin7o/Documents/Cours/hagidoop/clientDir/result-data24.txt in write mode
[+] New connection to the server !
[+] New connection to the server !
[+] New connection to the server !
[+] New connection to the server !
[-] Disconnection from a client
[-] Disconnection from a client
[-] Disconnection from a client
[-] Disconnection from a client
[-] fileReaderWriter on file /home/nin7o/Documents/Cours/hagidoop/clientDir/result-data24.txt closed
[-] Closing NetworkReaderWriter server
Job finished ! The result of the reduce can be found in : /home/nin7o/Documents/Cours/hagidoop/clientDir/result-data24.txt
time in ms =102591
```
temps : 102s

##### Itératif
lancement du map en itératif :

```bash
java application.Count data24.txt
time in ms =304140
```
temps : 304s

hagidoop est donc bien plus rapide que l'itératif. Il n'est néanmoins pas 4 fois plus rapide, de par la nécéssité du reduce
et le temps de déploiement.

##### Comparaison des résultats

Nous allons prendre un mot comme référence. 

Le résultat en itératif nous dit que le mot Fou apparait 16777216 fois

```
Fou<->16777216
```

Le résultat via MyMapReduce donne : 

```
Fou<->16777216
```

hagidoop retourne donc bien les mêmes résultats que l'itératif, en fonctionnant plus rapidement.
cp $1 /temp/$3

# generate 2^$2 times file $1
for ((n=0;n<$2;n++))
do
cat /temp/$3 /temp/$3 > /temp/temp
mv /temp/temp /temp/$3
done
mv /temp/$3 .

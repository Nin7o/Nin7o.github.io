package daemon;

import java.rmi.Remote;
import java.rmi.RemoteException;

import interfaces.FileReaderWriter;
import interfaces.Map;
import interfaces.NetworkReaderWriter;

/**
 * Un démon qui permet l'exécution d'une fonction sur un fichier.
 * Il lit sur le disque et écrit sur le réseau.
 */
public interface Worker extends Remote {
	public void runMap (Map m, FileReaderWriter reader, NetworkReaderWriter writer) throws RemoteException;
}

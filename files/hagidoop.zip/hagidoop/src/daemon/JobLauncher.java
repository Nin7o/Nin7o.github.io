package daemon;

import java.rmi.Naming;
import java.util.ArrayList;
import java.util.List;

import config.Project;
import interfaces.FileReaderWriter;
import interfaces.MapReduce;
import interfaces.NetworkReaderWriter;
import io.ImplFileReaderWriter;
import io.ImplNetworkReaderWriter;

/**
 * Permet le lancement des démons Worker sur les serveurs.
 * Applique un traitement pour compiler les résultats reçus. (ex: Reduce d'un Map)
 */
public class JobLauncher {

	public static String ANSI_RESET = "\u001B[0m";
    public static String ANSI_RED = "\u001B[31m";
	public static String ANSI_GREEN = "\u001B[32m";
    public static String ANSI_YELLOW = "\u001B[33m";
    public static String ANSI_BLUE = "\u001B[34m";

	private static int nbNodes;
	private static List<Integer> ports = new ArrayList<>();
	private static List<Integer> WorkerPorts = new ArrayList<>();
	private static List<String> addresses = new ArrayList<>();

	private static Project project = new Project();


	
	/** 
	 * Si le fichier est deja un fichier de KV, on map pas on reduce juste
	 * @param mr le MapReduce
	 * @param format le format de lecteur/rédacteur sur fichier
	 * @param fname le nom du fichier visé
	 */
	public static void startJob (MapReduce mr, int format, String fname) {
		try  {

			// get the project configuration
			nbNodes = project.nbNodes;
			ports = project.ports;
			addresses = project.addresses;
			WorkerPorts = project.WorkerPorts;

			//open the NetworkReaderWriter server, to receive KVs for the reduce
			NetworkReaderWriter snrw = new ImplNetworkReaderWriter(project.CLIENT_ADDRESS, project.CLIENT_PORT, null);
			snrw.openServer();

			//create the FileReaderWriter for the server
			FileReaderWriter frw = new ImplFileReaderWriter(0, FileReaderWriter.FMT_KV);
			frw.setFname(fname);
			frw.open("write");

			//retrieve all the workers
			List<Worker> workers = new ArrayList<>();
			for (int i = 0; i < nbNodes; i++) {
				Worker worker = (Worker)Naming.lookup("//" + addresses.get(i) + ":" + WorkerPorts.get(i) + "/Worker");
				workers.add(worker);
			}

			//create a FileReaderWriter for each worker
			List<FileReaderWriter> frws = new ArrayList<>();
			for (int i = 0; i < nbNodes; i++) {
				//FileReaderWriter get the port of the worker, because it defines the working directory
				FileReaderWriter frwi = new ImplFileReaderWriter(ports.get(i), format);
				//add the prefix to the fname if it's a kv format
				//coherent with the naming convention of HDFS
				switch (format) {
					case FileReaderWriter.FMT_TXT:
						frwi.setFname(fname);
						break;
					case FileReaderWriter.FMT_KV:
						frwi.setFname("kv-" + fname);
						break;
					default:
						break;
				}
				frws.add(frwi);
			}

			//create a NetworkReaderWriter for each worker
			List<NetworkReaderWriter> nrw = new ArrayList<>();
			for (int i = 0; i < nbNodes; i++) {
				//NetworkReaderWriter get the details of the server, so that it can connect to it
				NetworkReaderWriter nrwi = new ImplNetworkReaderWriter(project.CLIENT_ADDRESS, project.CLIENT_PORT, null);
				nrw.add(nrwi);
			}
		
			// start all runMap on each worker
			for (int i = 0; i < nbNodes; i++) {
				workers.get(i).runMap(mr, frws.get(i), nrw.get(i));
			}

			//accept all the connections from the workers
			for (int i = 0; i < nbNodes; i++) {
				snrw.accept();
			}

			// at this point all the workers have their map running and are 
			//connected to the server
			//we can start the reduce on the master
			//the read method of the NetworkReaderWriter will read the KVs from the workers
			//until all of them are finished, and then return null

			//start the reduce on the master
			mr.reduce(snrw, frw);

			// close all the connections
			frw.close();
			snrw.closeServer();
			
			System.out.println(ANSI_GREEN + "Job finished ! The result of the reduce can be found in : " + Project.CLIENTPATH + "result-" + fname + ANSI_RESET);
		
		} catch (Exception e) {
			System.err.println("JobLauncher exception:");
			e.printStackTrace();
		}
		
			
	}

}
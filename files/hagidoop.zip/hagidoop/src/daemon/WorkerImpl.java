package daemon;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import interfaces.FileReaderWriter;
import interfaces.Map;
import interfaces.NetworkReaderWriter;

/** 
 * Implémentation du Worker.
 * Il posssède un port et une adresse. Il lit le fichier du serveur et applique
 * un traitement dessus. Il renvoie le résultat au client via le réseau.
 */
public class WorkerImpl extends UnicastRemoteObject implements Worker {

    public static String ANSI_RESET = "\u001B[0m";
    public static String ANSI_RED = "\u001B[31m";
	public static String ANSI_GREEN = "\u001B[32m";
    public static String ANSI_YELLOW = "\u001B[33m";
    public static String ANSI_BLUE = "\u001B[34m";

    private static String workerAddress; //adresse du worker
    private static int workerPort; //port du worker

    public WorkerImpl() throws RemoteException {}

    
    /** 
     * Programme principal du Worker
     * @param args les arguments : adresse et port
     */
    public static void main(String[] args) {

        if (args.length != 2) {
            System.out.println("Usage: java WorkerImpl <address> <port>");
            System.exit(0);
        }

        workerAddress = args[0];
        workerPort = Integer.parseInt(args[1]);

        try {

            System.setProperty("java.rmi.server.hostname", workerAddress);

            //creation du worker
            Worker worker = new WorkerImpl();

            //Creation du registre RMI
            @SuppressWarnings("unused")
            Registry registry = LocateRegistry.createRegistry(workerPort);

            System.out.println(ANSI_YELLOW + "Worker published on register " + "//"+ workerAddress + ":" + workerPort + "/Worker" + ANSI_RESET);

            //Publication de l'objet distant sur le registre RMI
            Naming.rebind("//"+ workerAddress + ":" + workerPort + "/Worker", worker);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    /** 
     * Exécute un traitement sur le fichier et renvoie son résultat sur le réseau
     * @param m le traitement à effectuer (ex: Map)
     * @param reader le lecteur sur le fichier local
     * @param writer le rédacteur sur le réseau, lié au client
     * @throws RemoteException
     */
    @Override
    public void runMap(Map m, FileReaderWriter reader, NetworkReaderWriter writer) throws RemoteException {
        //running in a thread in the node machine to avoid blocking the RMI call
        new Thread(() -> {
            
            //open the connexion to the jobLauncher to write the output KVs
            writer.openClient();
            //open the fileReaderWriter in read mode to read the input file
            reader.open("read");

            System.out.println(ANSI_GREEN + "[+] runMap starting on file " + reader.getFname() + ANSI_RESET);

            m.map(reader, writer);

            System.out.println(ANSI_RED + "[-] runMap finished" + ANSI_RESET);

            //close the fileReaderWriter and the connexion to the jobLauncher
            reader.close();
            writer.closeClient();

        }).start(); // running a single thread for each map, and running it instantly
    }
    
}

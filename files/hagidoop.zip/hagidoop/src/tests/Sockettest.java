package tests;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.*;

public class Sockettest {

    public static void main(String[] args) {
        try {

            ServerSocket serverSocket = new ServerSocket(8080);

            Socket socket = serverSocket.accept();

            System.out.println("Client connected");

            InputStream is = socket.getInputStream();
            ObjectInputStream ois = new ObjectInputStream(is);

            OutputStream os = socket.getOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(os);

            String message = (String) ois.readObject();
            System.out.println("Message received from client = " + message);

            oos.writeObject("Thank you for connecting to " + socket.getLocalSocketAddress() + "\nGoodbye!");

            socket.close();
            serverSocket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}

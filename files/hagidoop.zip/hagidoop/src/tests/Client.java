package tests;

import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;

public class Client {
    
    public static void main(String[] args) {
        try {
            System.out.println("usage : java Client port");
            int port = Integer.parseInt(args[0]);
            
            ItfTartiflette tartiflette = (ItfTartiflette) java.rmi.Naming.lookup("rmi://localhost:" + port + "/Tartiflette");
            
            tartiflette.manger();
            boolean estcuite = tartiflette.cuire(200);

            if (estcuite) {
                System.out.println("C'est cuit !");
            } else {
                System.out.println("C'est pas cuit !");
            }

            Socket socket = new Socket("localhost", 8080);
            
            System.out.println("Client connected");

            OutputStream os = socket.getOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(os);

            InputStream is = socket.getInputStream();
            ObjectInputStream ois = new ObjectInputStream(is);

            oos.writeObject("Hello from " + socket.getLocalSocketAddress());

            String message = (String) ois.readObject();

            System.out.println("Message received from server = " + message);

            socket.close();
            
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}

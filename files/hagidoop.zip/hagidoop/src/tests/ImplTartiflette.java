package tests;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class ImplTartiflette extends UnicastRemoteObject implements ItfTartiflette {

    protected ImplTartiflette() throws RemoteException {
        super();
    }

    public static void main(String[] args) {

        try {
            System.out.println("usage : java ImplTartiflette port");
            int port = Integer.parseInt(args[0]);

            // Création de la tartiflette
            ItfTartiflette tartiflette = new ImplTartiflette();

            //creation du registre RMI        
            Registry registry = LocateRegistry.createRegistry(port);
            Naming.rebind("rmi://localhost:" + port + "/Tartiflette", tartiflette);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Ces prints la vont s'afficher sur serveur !
    @Override
    public void manger() {
        System.out.println("miamiamiamiam");
    }

    @Override
    public boolean cuire(int temperature) {
        if (temperature > 180) {
            System.out.println("c'est assez chaud !");
            return true;
        } else {
            System.out.println("Pas assez chaud !");
            return false;
        }
    }
    
}

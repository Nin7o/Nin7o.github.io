package tests;

import java.rmi.Remote;

public interface ItfTartiflette extends Remote{
    public void manger();
    public boolean cuire(int temperature);
}

package hdfs;

import java.net.Socket;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;

import config.ProgressBar;
import config.Project;
import io.ImplFileReaderWriter;

/**
 * Côté client de hdfs : Permet de lancer les commandes hdfs
 * write, read, delete et list
 * write - envoie un fichier sur les serveurs en le découpant de manière équitable
 * read - récupère un fichier des serveurs
 * delete - supprime un fichier des serveurs
 * list - liste les fichiers présents sur les serveurs
 */
public class HdfsClient {

	public static String ANSI_RESET = "\u001B[0m";
    public static String ANSI_RED = "\u001B[31m";
	public static String ANSI_GREEN = "\u001B[32m";
    public static String ANSI_YELLOW = "\u001B[33m";
    public static String ANSI_BLUE = "\u001B[34m";

	private static String currentAddress = "";
	private static int currentPort = 0;

	private static Project project = new Project();

	private static List<Integer> ports = new ArrayList<>();
	private static List<String> addresses = new ArrayList<>();

	private static int nbNodes = 0;

	public static final int FMT_TXT = 0;
	public static final int FMT_KV = 1;

	private static final int WAIT_TIME = 1000;

	/**
	 * Prints the usage of the program
	 */
	private static void usage() {
		System.out.println("Usage: java HdfsClient read <file>");
		System.out.println("Usage: java HdfsClient write <txt|kv> <file>");
		System.out.println("Usage: java HdfsClient delete <file>");
		System.out.println("Usage: java HdfsClient list");
	}

	/**
	 * Verifies the arguments of the program
	 * @param args les arguments du programme
	 */
	private static void verifyArgs(String[] args) {
		boolean badUsage = true;

		if (args[0].equals("read")) {
			if (args.length != 2) {
				badUsage = true;
			} else {
				badUsage = false;
			}
		}

		if (args[0].equals("list")) {
			if (args.length != 1) {
				badUsage = true;
			} else {
				badUsage = false;
			}
		}

		if (args[0].equals("write")) {
			if (args.length != 3) {
				badUsage = true;
			} else {
				badUsage = false;
			}

			if (!args[1].equals("txt") && !args[1].equals("kv")) {
				badUsage = true;
			}
		}

		if (args[0].equals("delete")) {
			if (args.length != 2) {
				badUsage = true;
			} else {
				badUsage = false;
			}
		}

		if (badUsage) {
			usage();
			System.exit(1);
		}
	}

	/** 
	 * Checks if all used nodes are running
	*/
	public static void checkNodes() {

		System.out.println(ANSI_BLUE + "Checking if all nodes are running..." + ANSI_RESET);
		ProgressBar.updateProgressBar(0, nbNodes);

		boolean allNodesRunning = true;

		for (int i = 0; i < nbNodes; i++) {

			try {

				currentAddress = addresses.get(i);
				currentPort = ports.get(i);

				//initiate a socket 
				Socket clientSocket = new Socket(addresses.get(i), ports.get(i));
				OutputStream os = clientSocket.getOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(os);
				oos.writeUnshared(new DataChunk("", "", 5));
				clientSocket.close();

				ProgressBar.updateProgressBar(i + 1, nbNodes);

			} catch (java.net.ConnectException e) {
				System.out.println(ANSI_RED + "\nConnexion to server " + currentAddress + " to port " + currentPort + " has failed" + ANSI_RESET);
				allNodesRunning = false;
				e.printStackTrace();
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		ProgressBar.updateProgressBar(nbNodes, nbNodes);

		if (allNodesRunning) {
			System.out.println(ANSI_GREEN + "\nAll nodes are running !" + ANSI_RESET);
		} else {
			System.out.println(ANSI_RED + "\n[!] Some nodes are not running" + ANSI_RESET);
			System.exit(1);
		}

	}
	
	
	/** 
	 * Supprime un fichier des serveurs
	 * @param fname le nom du fichier
	 */
	public static void HdfsDelete(String fname) {

		System.out.println(ANSI_BLUE + "Deleting file " + fname + "\n" + ANSI_RESET);
		ProgressBar.updateProgressBar(0, nbNodes);

		//go through all the servers
		for (int i = 0; i < nbNodes; i++) {

			try {

				currentAddress = addresses.get(i);
				currentPort = ports.get(i);

				//filename to delete on the node
				String name = fname;

				//initiate a socket 
				Socket clientSocket = new Socket(addresses.get(i), ports.get(i));
				OutputStream os = clientSocket.getOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(os);

				//send the delete order to the server
				DataChunk chunk = new DataChunk("", name, 2);
				oos.writeUnshared(chunk);

				//wait for a response to validate the deletion
				InputStream is = clientSocket.getInputStream();
				ObjectInputStream ois = new ObjectInputStream(is);
				DataChunk response = (DataChunk) ois.readObject();

				if (response.action == 3) {
					System.out.println("Error while deleting the file on the server" + addresses.get(i) + ":" + ports.get(i));
					System.exit(1);
				}

				Thread.sleep(WAIT_TIME);

				//close the socket
				clientSocket.close();

			} catch (java.net.ConnectException e) {
				System.out.println(ANSI_RED + "\n[!] Error: ConnectException" + ANSI_RESET);
				System.out.println(ANSI_RED + "Check if the servers are running" + ANSI_RESET);
				System.out.println(ANSI_RED + "Connexion to server " + currentAddress + " to port " + currentPort + " has failed" + ANSI_RESET);
			} catch (Exception e) {
				e.printStackTrace();
			}

			ProgressBar.updateProgressBar(i + 1, nbNodes);

		}

		System.out.println(ANSI_GREEN + "\nFile deleted on all nodes" + ANSI_RESET);

	}
	
	
	/** 
	 * Écris un fichier sur les serveurs
	 * @param fmt le format du fichier (FMT_TXT=0 ou FMT_KV=1)
	 * @param fname le nom du fichier
	 */
	public static void HdfsWrite(int fmt, String fname) {

		System.out.println(ANSI_BLUE + "Writing file " + fname + " on HDFS" + ANSI_RESET);

		// file path to where the file to be sent is stored
		String filePath = Project.DATAPATH + fname;
		File file = new File(filePath);

		try {
			//instanciate a file reader and a scanner to read the file
			FileReader reader = new FileReader(filePath);
			Scanner scanner = new Scanner(reader);

			//regex to separate the reading of the file by line
			//we separate the file by line because of the default comportment 
			//of hagidoop when reading a text file (it reads it by line)
			String delimiterRegex = "(?<=\\n)";
			scanner.useDelimiter(delimiterRegex);

			//get file length in bytes
			long fileSize = file.length();
			System.out.println(ANSI_GREEN + "Total file size to write: " + fileSize + ANSI_RESET);

			// size of each chunk in bytes
			long sizeOfChunk = (long) (fileSize / nbNodes);
			System.out.println(ANSI_GREEN + "Size of each chunk: " + sizeOfChunk + ANSI_RESET);

			// size max of a datachunk to send to a server
			long sizeMax = DataChunk.sizeMax;

			System.out.println(ANSI_GREEN + "Sending data to the servers" + ANSI_RESET);

			//file stored under a different name depending on the file format
			String storedName = "";
			switch (fmt) {
				case ImplFileReaderWriter.FMT_TXT:
					storedName = fname ;
					break;
				case ImplFileReaderWriter.FMT_KV:
					storedName = "kv-" + fname ;
					break;
			}
			
			// stringbuilder to store the chunk
			StringBuilder sb = new StringBuilder();

			String data = "";

			//go through all the servers
			for (int i = 0; i < nbNodes; i++) {

				System.out.println(ANSI_YELLOW + "Sending data to server " + addresses.get(i) + ":" + ports.get(i) + ANSI_RESET);

				currentPort = ports.get(i);
				currentAddress = addresses.get(i);

				//filename in this node (port-(kv-)filename)
				String name = ports.get(i) + "-" + storedName;
				
				//initiate a socket for the server
				Socket clientSocket = new Socket(addresses.get(i), ports.get(i));
				OutputStream os = clientSocket.getOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(os);
			
				DataChunk chunk = new DataChunk("", name, 1);

				long totalSize = 0; // total size of the chunk
				long size = 0; // size of the current dataChunk to be sent

				long startTime = System.currentTimeMillis();

				// go through the file
				while (scanner.hasNext()) {
					
					// read a line and add it to the stringbuilder
					data = scanner.next();
					sb.append(data);
					

					// add the size of the line to the counters of size
					long wordSize = data.getBytes("UTF-8").length;
					size += wordSize;
					totalSize += wordSize;

					// if the size of the dataChunk is reached, create a chunk and send it to the node
					if (size >= sizeMax) {
						ProgressBar.updateProgressBarWithETA(totalSize, sizeOfChunk, startTime);
						chunk.text = sb.toString();
						oos.writeUnshared(chunk);
						oos.flush();
						oos.reset();
						sb = new StringBuilder();
						size = 0;

					}

					// if the size of the chunk is reached, stop reading the file
					if (totalSize >= sizeOfChunk) {
						break;
					}

				}

				//if there is still data in the stringbuilder, send it to the node
				if (size > 0) {
					DataChunk lastChunk = new DataChunk(sb.toString(), name, 1);
					oos.writeUnshared(lastChunk);
					oos.flush();
					sb.setLength(0);
				}

				//ProgressBar.updateProgressBar(i + 1, nbNodes);

				// send a null chunk to indicate the end of the sending
				oos.writeUnshared(new DataChunk("", name, 4));

				Thread.sleep(WAIT_TIME);

				System.gc();

				// close the socket
				clientSocket.close();

				ProgressBar.updateProgressBarWithETA(1, 1, startTime);

				System.out.println(ANSI_YELLOW + "\nData sent to server " + addresses.get(i) + ":" + ports.get(i) + ANSI_RESET);

			}

			
			// close the file reader and the scanner
			reader.close();
			scanner.close();

			System.out.println(ANSI_GREEN + "\nFile sent to the servers" + ANSI_RESET);

		} catch (java.net.ConnectException e) {
				System.out.println(ANSI_RED + "\n[!] Error: ConnectException" + ANSI_RESET);
				System.out.println(ANSI_RED + "Check if the servers are running" + ANSI_RESET);
				System.out.println(ANSI_RED + "Connexion to server " + currentAddress + " to port " + currentPort + " has failed" + ANSI_RESET);
		} catch (java.io.FileNotFoundException e) {
			System.out.println(ANSI_RED + "\n[!] Error: FileNotFoundException" + ANSI_RESET);
			System.out.println(ANSI_RED + "File " + filePath + " not found" + ANSI_RESET);
		} catch (Exception e) {
			e.printStackTrace();
		} 

	}

	
	/** 
	 * Lis un fichier à partir des serveurs et le stocke dans le dossier client
	 * @param fname le nom du fichier
	 */
	public static void HdfsRead(String fname) {

		System.out.println(ANSI_BLUE + "Reading file " + fname + " from the nodes\n" + ANSI_RESET);
		ProgressBar.updateProgressBar(0, nbNodes);

		// create the directory where the file will be stored if it does not exist
		String dirPath = Project.CLIENTPATH;
		File dir = new File(dirPath);
		dir.mkdir();

		String filePath = dirPath + fname;

		try {

			FileWriter fw = new FileWriter(filePath, true);
        	BufferedWriter bw = new BufferedWriter(fw); 

		//go through all the servers
		for (int i = 0; i < nbNodes; i++) {

			currentPort = ports.get(i);
			currentAddress = addresses.get(i);

			//filename to read on the node
			String name = fname;

			//initiate a socket 
			Socket clientSocket = new Socket(addresses.get(i), ports.get(i));

			//initiate an output stream
			OutputStream os = clientSocket.getOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(os);

			//send the read order to the server
			DataChunk chunk = new DataChunk("", name, 0);
			oos.writeUnshared(chunk);

			//initiate an input stream
			InputStream is = clientSocket.getInputStream();
			ObjectInputStream ois = new ObjectInputStream(is);

			DataChunk response = null;
			//receive all the datachunks from the server
			while (true) {

				response = (DataChunk) ois.readObject();

				//if the action is 4, all the datachunks have been received
				if (response.action == 4) {
					break;
				}

				bw.write(response.getText());
			}

			Thread.sleep(WAIT_TIME);

			//close the socket
			clientSocket.close();

			ProgressBar.updateProgressBar(i + 1, nbNodes);

		}

		System.out.println(ANSI_GREEN + "\nFile retrieved, stored in " + filePath + ANSI_RESET);

		//close the buffered writer
		bw.close();

		} catch (java.net.ConnectException e) {
				System.out.println(ANSI_RED + "\n[!] Error: ConnectException" + ANSI_RESET);
				System.out.println(ANSI_RED + "Check if the servers are running" + ANSI_RESET);
				System.out.println(ANSI_RED + "Connexion to server " + currentAddress + " to port " + currentPort + " has failed" + ANSI_RESET);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * Liste les fichiers présents sur les serveurs
	 * préviens si un fichier est présent sur certains serveurs et pas d'autres
	 */
	public static void HdfsList() {

		try {

			System.out.println(ANSI_BLUE + "Listing files on HDFS" + ANSI_RESET);
			ProgressBar.updateProgressBar(0, nbNodes);

			ConcurrentHashMap<String,Integer> hm = new ConcurrentHashMap<String,Integer>();

			//go through all the servers
			for (int i = 0; i < nbNodes; i++) {

				currentPort = ports.get(i);
				currentAddress = addresses.get(i);

				//initiate a socket 
				Socket clientSocket = new Socket(addresses.get(i), ports.get(i));

				//initiate an output stream
				OutputStream os = clientSocket.getOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(os);

				//initiate an input stream
				InputStream is = clientSocket.getInputStream();
				ObjectInputStream ois = new ObjectInputStream(is);

				//send the read order to the server
				DataChunk chunk = new DataChunk("", "", 6);
				oos.writeUnshared(chunk);

				//receive the list of files from the server

				DataChunk response = (DataChunk) ois.readObject();

				//add the files to the hashmap
				String[] files = response.getText().split("\n");
				for (String file : files) {
					String[] parts = file.split(ports.get(i) + "-");
					if (parts.length > 1) {
						String name = parts[1];
						if (hm.containsKey(name)) hm.put(name, hm.get(name)+1);
						else hm.put(name, 1);
					}
				}

				Thread.sleep(WAIT_TIME);

				//close the socket
				clientSocket.close();

				ProgressBar.updateProgressBar(i + 1, nbNodes);

			}

			if (hm.size() == 0) {
				System.out.println(ANSI_GREEN + "\nNo files on HDFS" + ANSI_RESET);
			} else {
				//if the file is present on all the nodes, print it
				System.out.println(ANSI_GREEN + "\nFiles present on all nodes:" + ANSI_RESET);
				for (String k : hm.keySet()) {
					if (hm.get(k) == nbNodes) {
						System.out.println(k);
						hm.remove(k);
					}
				}
			}

			if (hm.size() != 0) {
				//if the file is present on some nodes, print it
				System.out.println(ANSI_RED + "\nFiles present on some nodes:" + ANSI_RESET);
				for (String k : hm.keySet()) {
					if (hm.get(k) < nbNodes) {
						System.out.println(k);
					}
				}
				System.out.println(ANSI_RED + "Delete and resend these files to avoid any error during the execution of other processes" + ANSI_RESET);
			}

		} catch (java.net.ConnectException e) {
				System.out.println(ANSI_RED + "\n[!] Error: ConnectException" + ANSI_RESET);
				System.out.println(ANSI_RED + "Check if the servers are running" + ANSI_RESET);
				System.out.println(ANSI_RED + "Connexion to server " + currentAddress + " to port " + currentPort + " has failed" + ANSI_RESET);
		} catch (Exception e) {
			e.printStackTrace();
		}


	}


	
	/** 
	 * Programme principal du client HDFS
	 * @param args les arguments
	 */
	public static void main(String[] args) {

		//check the arguments
		verifyArgs(args);
		
		//get the project configuration
		ports = project.ports;
		addresses = project.addresses;
		nbNodes = project.nbNodes;

		//check if all nodes are running
		checkNodes();

		//start the right command
		String command = args[0];
		switch (command) {
			case "write":

				switch (args[1]) {
					case "txt":
						HdfsWrite(0, args[2]);
						break;
					case "kv":
						HdfsWrite(1, args[2]);
						break;
				}
				break;

			case "read":

				HdfsRead(args[1]);
				break;

			case "delete":

				HdfsDelete(args[1]);
				break;

			case "list":

				HdfsList();
				break;
				
		}
		
	}
}
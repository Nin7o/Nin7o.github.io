package hdfs;

import java.io.*;

/**
 * Objet qui va être utilisé par HDFS pour envoyer des données
 * comme du texte, le nom du fichier ou encore
 * l'action à effectuer par celui qui le reçoit
 */
public class DataChunk implements Serializable {
    private static final long serialVersionUID = 1L;

    public static final long sizeMax = 10000000; //in bytes

    public String text = "";

    public String name = "";

    // 0 = read, 1 = write, 2 = delete, 3 = error, 4 = break, 5 = ping, 6 = list files
    public int action = 0;

    public DataChunk(String text, String name, int action) {
        this.text = text;
        this.name = name;
        this.action = action;
    }

    
    /** 
     * Renvoie le texte lié au DataChunk
     * @return le texte lié au DataChunk
     */
    public String getText() {
        return this.text;
    }
    
}

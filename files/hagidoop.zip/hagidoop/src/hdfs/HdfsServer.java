package hdfs;

import java.net.*;
import java.util.Scanner;

import config.Project;

import java.io.*;

/**
 * Côté serveur de hdfs : reçoit des fichiers du client et répond à différentes 
 * requêtes.
 */
public class HdfsServer {

    public static String ANSI_RESET = "\u001B[0m";
    public static String ANSI_RED = "\u001B[31m";
	public static String ANSI_GREEN = "\u001B[32m";
    public static String ANSI_YELLOW = "\u001B[33m";
    public static String ANSI_BLUE = "\u001B[34m";

    private static int port = 0;
    private static boolean actionEnded = false;
    private static final int MAX_ITER = 1000000;
    
    
    /** 
     * Permet de lancer un serveur HDFS
     * @param args le port sur lequel le serveur va écouter
     */
    public static void main(String[] args) {

        // check usage
        if (args.length != 1) {
            System.out.println("Usage: java HdfsServer <port>");
            System.exit(1);
        }

        port = Integer.parseInt(args[0]);

        // set and reset environment
        createDir();
        //deleteDirContent(); // a enlever à un moment pour une gestion plus propre

        try {

            // create the server socket
            ServerSocket serverSocket;
            serverSocket = new ServerSocket(port);
            System.out.println(ANSI_BLUE + "Hagidoop Distributed File System started on port " + port + ANSI_RESET);

            //to remove warnings
            //have to be changed so that an order can close the server
            while (port < MAX_ITER) {
                
                //accept the client connection
                Socket socket = serverSocket.accept();
                System.out.println(ANSI_GREEN + "[+] Connection d'un client" + ANSI_RESET);

                //get the input stream from the connected socket
                InputStream inputStream = socket.getInputStream();
                ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);

                //get the output stream from the connected socket
                OutputStream outputStream = socket.getOutputStream();
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
                    
                //receive all the chunks / order from the client
                //will break when the order is completed
                while (true) {

                    try {
                        //receive the chunk
                        DataChunk chunk = (DataChunk) objectInputStream.readObject();
        
                        //break order
                        if (chunk.action == 4) {
                            System.out.println(ANSI_BLUE + "File " + chunk.name + " received" + ANSI_RESET);
                            System.out.println(ANSI_RED + "[-] Déconnexion du client\n" + ANSI_RESET);
                            break;
                        }

                        // else, do the action
                        switch (chunk.action) {

                            case 0:
                                System.out.println(ANSI_BLUE + "File " + chunk.name + " requested" + ANSI_RESET);
                                read(chunk.name, objectOutputStream);
                                actionEnded = true;
                                break;

                            case 1:
                                write(chunk);
                                break;

                            case 2:    
                                delete(chunk, objectOutputStream);
                                System.out.println(ANSI_BLUE + "File " + chunk.name + " deleted" + ANSI_RESET);
                                actionEnded = true;
                                break;

                            case 5:
                                System.out.println(ANSI_BLUE + "Ping received" + ANSI_RESET);
                                actionEnded = true;
                                break;

                            case 6:
                                System.out.println(ANSI_BLUE + "List files requested" + ANSI_RESET);
                                listFiles(objectOutputStream);
                                actionEnded = true;
                                break;
                        
                            default:
                                System.out.println(ANSI_YELLOW + "[!] Wrong action flag" + ANSI_RESET);
                                break;
                        }

                        System.gc();

                        //if the action server side is ended, break the loop
                        if (actionEnded) {
                            actionEnded = false;
                            System.out.println(ANSI_RED + "[-] Déconnexion du client\n" + ANSI_RESET);
                            break;
                        }

                    } catch (java.net.SocketException e) {
                        System.out.println(ANSI_RED + "[Error] Socket Exception : Back to waiting state of the server\nThe current action has stopped abruptly\nConsider deleting all generated files and trying again");
                        break;
                    }
                
                }

            }

            //close the socket
            serverSocket.close();

            System.out.println(ANSI_RED + "Server closed" + ANSI_RESET);
            
        } catch (Exception e) {
            e.printStackTrace();
        }      
        
    }

    
    /** 
     * Renvoie la liste de ses fichiers au client
     * @param oos l'ObjectOutputStream sur lequel écrire la liste
     */
    private static void listFiles(ObjectOutputStream oos) {
        try {

            String folderPath = Project.NODEPATH + port;
            File folder = new File(folderPath);

            String files = "";

            for (File file : folder.listFiles()) {
                files += file.getName() + "\n";
            }

            oos.writeUnshared(new DataChunk(files, "", 6));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Crée le dossier de travail du noeud
     */
    private static void createDir() {
        try {
            String folderPath = Project.NODEPATH + port;
            File folder = new File(folderPath);
            folder.mkdir();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Supprime le contenu du dossier de travail du noeud
     */
    @SuppressWarnings("unused")
    private static void deleteDirContent() {
        try {
            String folderPath = Project.NODEPATH + port;
            File folder = new File(folderPath);
            if (folder.exists()) {
                for (File file : folder.listFiles()) {
                    file.delete();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    
    /** 
     * Lit en fichier et renvoie sont contenu au client
     * @param filename le nom du fichier
     * @param objectOutputStream l'ObjectOutputStream sur lequel écrire le fichier
     */
    private static void read(String filename, ObjectOutputStream objectOutputStream) {
        try {

            String absolutePath = Project.NODEPATH + port + "/" + port + "-" + filename;
            File file = new File(absolutePath);

            if (!file.exists()) {
                absolutePath = Project.NODEPATH + port + "/" + port + "-kv-" + filename;
            }

            // instanciate the file reader
            FileReader fr = new FileReader(absolutePath);
            Scanner scanner = new Scanner(fr);

            // set the delimiter to \n
            String delimiterRegex = "(?<=\\n)";
			scanner.useDelimiter(delimiterRegex);

            // get the max size of a dataChunk
            long sizeMax = DataChunk.sizeMax;

            // stringbuilder to store the chunk
            StringBuilder sb = new StringBuilder();
            long size = 0;

            DataChunk chunk = new DataChunk("", filename, 1);

            String word = "";

            // read the file
            while (scanner.hasNext()) {

                word = scanner.next();
                sb.append(word);

                int wordSize = word.getBytes("UTF-8").length;
                size += wordSize;

                // if the size of the chunk is bigger than the max size, send it
                if (size >= sizeMax) {
                    chunk.text = sb.toString();
                    objectOutputStream.writeUnshared(chunk);
                    objectOutputStream.flush();
                    objectOutputStream.reset();
                    sb = new StringBuilder();
                    size = 0;
                }

            }

            // if there is still data in the stringbuilder, send it
            if (size > 0) {
                objectOutputStream.writeUnshared(new DataChunk(sb.toString(), filename, 1));
                objectOutputStream.flush();
                objectOutputStream.reset();
            }

            // send a null chunk to indicate the end of the reading
            objectOutputStream.writeUnshared(new DataChunk("", filename, 4));
            objectOutputStream.flush();
            objectOutputStream.reset();

            System.out.println(ANSI_GREEN + "File " + filename + " sent" + ANSI_RESET);

            scanner.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    
    /** 
     * Écrit un nouveau fichier
     * @param chunk le chunk de données à écrire - contient le nom du fichier et son contenu
     */
    private static void write(DataChunk chunk) {
        try {

            String absolutePath = Project.NODEPATH + port + "/" + chunk.name;

            FileWriter fw = new FileWriter(absolutePath, true);
            BufferedWriter bw = new BufferedWriter(fw);

            // write the chunk in the file
            bw.write(chunk.getText());

            bw.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    /** 
     * Supprime un fichier
     * @param chunk le nom du fichier
     * @param objectOutputStream l'ObjectOutputStream sur lequel renvoyer l'effectivité de la supression
     */
    private static void delete(DataChunk chunk, ObjectOutputStream objectOutputStream) {
        try {

            // file to delete
            String absolutePath = Project.NODEPATH + port + "/" + port + "-" + chunk.name;
            File file = new File(absolutePath);

            if (!file.exists()) {
                absolutePath = Project.NODEPATH + port + "/" + port + "-kv-" + chunk.name;
            }

            file = new File(absolutePath);

            // delete the file
            file.delete();

            // send a null chunk to indicate the end of the deleting
            objectOutputStream.writeUnshared(new DataChunk("", "", 2));
            objectOutputStream.flush();
            objectOutputStream.reset();

        } catch (Exception e) {
            // error handling
            try {
            objectOutputStream.writeUnshared(new DataChunk("", "", 3));
            objectOutputStream.flush();
            objectOutputStream.reset();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }


}

package io;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;

import interfaces.KV;
import interfaces.NetworkReaderWriter;

/**
 * Implémente le lecteur/rédacteur sur le réseau.
 * Il permet de lire/écrire sur le lien entre les résultats du Map et l'entrée
 * du reduce.
 */
public class ImplNetworkReaderWriter implements NetworkReaderWriter, Cloneable {

    public static String ANSI_RESET = "\u001B[0m";
    public static String ANSI_RED = "\u001B[31m";
	public static String ANSI_GREEN = "\u001B[32m";
    public static String ANSI_YELLOW = "\u001B[33m";
    public static String ANSI_BLUE = "\u001B[34m";

    private Socket connectedSocket;
    private ServerSocket serverSocket;

    private List<Socket> serverConnectedSockets = new ArrayList<>();
    private List<InputStream> inputStreams = new ArrayList<>();
    private List<ObjectInputStream> objectInputStreams = new ArrayList<>();

    private OutputStream outputStream;
    private ObjectOutputStream objectOutputStream;

    private String address;
    private int port;

    private final ReentrantLock rlock = new ReentrantLock();
    private final ReentrantLock wlock = new ReentrantLock();

    public ImplNetworkReaderWriter(String address, int port, Socket connectedSocket) {
        this.address = address;
        this.port = port;
        this.connectedSocket = connectedSocket;

    }

    private int l = 0;

    
    /** 
     * Permet de lire un KV sur le réseau
     * @return renvoie le KV lu
     */
    @Override
    public KV read() {
        //Read ça veut dire qu'on read depuis un des workers et qu'on est le server
        // on va donc lire depuis un des inputStreams
        // si la lecture est null, on ferme le socket et on le retire de la liste

        //si la liste est vide, on return null

        //sinon on lit depuis le premier de la liste

        //si la lecture est null, on ferme le socket et on le retire de la liste

        //sinon on return la lecture
        rlock.lock();
        try {

            l = objectInputStreams.size();
            if (l == 0) {
                return null;
            }    

            KV kv = null;
            for (int i = 0; i < l; i++) {
                try {
                    kv = (KV) objectInputStreams.get(i).readObject();
                    if (kv == null) {
                        serverConnectedSockets.get(i).close();
                        serverConnectedSockets.remove(i);
                        inputStreams.get(i).close();
                        inputStreams.remove(i);
                        objectInputStreams.get(i).close();
                        objectInputStreams.remove(i);
                        System.out.println(ANSI_BLUE + "[-] Disconnection from a client" + ANSI_RESET);
                        l--;
                        i--;
                    } else {
                        return kv;
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            rlock.unlock();
        }
    }

    
    /** 
     * Permet d'écrire un KV sur le réseau
     * @param record le KV à écrire
     */
    @Override
    public void write(KV record) {
        wlock.lock();
        try {
            objectOutputStream.writeUnshared(record);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            wlock.unlock();
        }

    }

    /**
     * Ouvre le lecteur/rédacteur en tant que serveur
     */
    @Override
    public void openServer() {
        try {
            System.out.println(ANSI_GREEN + "[+] Opening NetworkReaderWriter server on : " + address + ":" + port + ANSI_RESET);
            serverSocket = new ServerSocket(port);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Ouvre le lecteur/rédacteur en tant que client
     * Essaye alors de se connecter au serveur
     */
    @Override
    public void openClient() {
        try {
            // create the client socket connected to the server
            connectedSocket = new Socket(address, port);
            System.out.println(ANSI_GREEN + "[+] Connected NetworkReaderWriter to the server on : " + address + ":" + port + ANSI_RESET);

            //get the output stream from the connected socket
            outputStream = connectedSocket.getOutputStream();
            objectOutputStream = new ObjectOutputStream(outputStream);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    /** 
     * Accepte une connection sur un socket
     * @return renvoie une copie de l'objet, ou le socket à été accepté ett stocké
     */
    @Override
    public NetworkReaderWriter accept() {
        // accept a connection on the server socket
        // here we don't care about the return value, we just want to add the socket to the list
        // once all the sockets are added to the list, we can start reading from them
        // so we return a clone of this object
        try {
            Socket s = serverSocket.accept();
            serverConnectedSockets.add(s);
            
            //get the input stream from the connected socket
            InputStream is = s.getInputStream();
            inputStreams.add(is);
            ObjectInputStream ois = new ObjectInputStream(is);
            objectInputStreams.add(ois);
            
            System.out.println(ANSI_BLUE + "[+] New connection to the server !" + ANSI_RESET);

            return (NetworkReaderWriter) super.clone();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Ferme le lecteur/rédacteur en tant que serveur
     */
    @Override
    public void closeServer() {
        if (serverSocket != null) {
            try {
                serverSocket.close();
                System.out.println(ANSI_RED + "[-] Closing NetworkReaderWriter server" + ANSI_RESET);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Ferme le lecteur/rédacteur en tant que client
     */
    @Override
    public void closeClient() {
        if (connectedSocket != null) {
            try {
                objectOutputStream.writeObject(null);
                connectedSocket.close();
                System.out.println(ANSI_RED + "[-] Disconnected from NetworkReaderWriter server " + ANSI_RESET);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
}

package io;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Scanner;
import java.util.concurrent.locks.ReentrantLock;

import config.Project;
import interfaces.FileReaderWriter;
import interfaces.KV;

/**
 * Implémente le lecteur/rédacteur sur les fichiers.
 * Permet la lecture des fichiers nécessaire au Map.
 */
public class ImplFileReaderWriter implements FileReaderWriter {

    public static String ANSI_RESET = "\u001B[0m";
    public static String ANSI_RED = "\u001B[31m";
	public static String ANSI_GREEN = "\u001B[32m";
    public static String ANSI_YELLOW = "\u001B[33m";
    public static String ANSI_BLUE = "\u001B[34m";

    private String fname;
    private String fpath;
    private String workingDir;

    private FileWriter fw;
    private BufferedWriter bw;

    private FileReader fr;
    private Scanner scanner;

    private int fileType;
    private int port;

    private final ReentrantLock rlock = new ReentrantLock();
    private final ReentrantLock wlock = new ReentrantLock();

    public ImplFileReaderWriter(int port, int fileType) {
        this.port = port;
        this.fileType = fileType;
    }

    
    /** 
     * Permet de lire un fichier
     * @return le KV lu
     */
    @Override
    public KV read() {
        // read the file according to the format
        rlock.lock();
        try{

            switch (fileType) {
                case FMT_TXT:
                    scanner.useDelimiter("\n");
                    if (scanner.hasNext()) {
                        String line = scanner.next();
                        return new KV("", line);
                    } else {
                        return null;
                    }
                
                case FMT_KV:

                    scanner.useDelimiter("\n|<->");
                    if (scanner.hasNext()) {
                        String k = scanner.next();
                        String v = scanner.next();
                        return new KV(k, v);
                    } else {
                        return null;
                    }
            }

            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            rlock.unlock();
        }
    }

    
    /** 
     * Permet d'écrire un KV
     * @param record le KV à écrire
     */
    @Override
    public void write(KV record) {
        wlock.lock();
        try{
            // write the record in the file according to the format
            if (record != null) {
                try {

                    switch (fileType) {
                        case FMT_TXT:
                            this.bw.write(record.v + "\n");
                            break;
                        case FMT_KV:
                            this.bw.write(record.k + "<->" + record.v + "\n");
                            break;
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {}
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            wlock.unlock();
        }
    }

    
    /** 
     * Permet d'ouvrir un fichier en lecture ou écriture
     * @param mode le mode d'ouverture "read"/"write"
     */
    @Override
    public void open(String mode) {
        // open the file according to the mode
        try {

            File folder = new File(this.workingDir);
            if (!folder.exists()) {
                folder.mkdir();
            }

            switch (mode) {
                case "read":
                    this.fr = new FileReader(this.fpath);
                    this.scanner = new Scanner(this.fr);
                    break;
                case "write":
                    this.fw = new FileWriter(this.fpath, true);
                    this.bw = new BufferedWriter(this.fw);

                    File file = new File(this.fpath);
                    if (file.exists()) {
                        System.out.println(ANSI_YELLOW + "[!] file " + this.fpath + " already exists !\nAll writes will be appened to the file so that no data is lost.\nYou might want to delete the file and restart the process." + ANSI_RESET);
                    }
                    break;
            }

            System.out.println(ANSI_GREEN + "[+] fileReaderWriter opened on file " + this.fpath + " in " + mode + " mode" + ANSI_RESET);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Ferme le fichier ouvert
     */
    @Override
    public void close() {
        // close everything thet have been opened
        try {
            if (this.fr != null) {
                this.fr.close();
            }
            if (this.scanner != null) {
                this.scanner.close();
            }
            if (this.bw != null) {
                this.bw.close();
            }
            if (this.fw != null) {
                this.fw.close();
            }

            System.out.println(ANSI_RED + "[-] fileReaderWriter on file " + this.fpath + " closed" + ANSI_RESET);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    /** 
     * Permet de récupérer l'index de l'écriture dans le fichier (ligne courante)
     * @return la taille du fichier
     */
    @Override
    public long getIndex() {
        File file = new File(this.fname);
        return file.length();
    }

    
    /** 
     * Renvoie le nom du fichier
     * @return le nom du fichier
     */
    @Override
    public String getFname() {
        return this.fname;
    }

    
    /** 
     * Permet de modifier le nom du fichier
     * @param fname le nom du fichier
     */
    @Override
    public void setFname(String fname) {
        //set the filename according to the port : 
        //if the port is 0, then it is a client, and the file is in /tmp/client
        //if the port is not 0, then it is a server, and the file is in /tmp/port
        this.fname = fname;
        switch(port) {
            case 0:
                this.fpath = Project.CLIENTPATH + "result-" + this.fname;
                this.workingDir = Project.CLIENTPATH;
                break;
            default:
                this.fpath = Project.NODEPATH + this.port + "/" + this.port + "-" + this.fname;
                this.workingDir = Project.NODEPATH + this.port + "/";
                break;
        }
    }
    
}

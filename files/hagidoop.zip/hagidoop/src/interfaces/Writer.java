package interfaces;

public interface Writer {
	public void write(KV record);
}

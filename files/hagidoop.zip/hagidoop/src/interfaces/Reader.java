package interfaces;

public interface Reader {
	public KV read();
}

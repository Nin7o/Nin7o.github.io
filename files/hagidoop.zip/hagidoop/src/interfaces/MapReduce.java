package interfaces;

public interface MapReduce extends Map, Reduce {
}

package interfaces;

import java.io.Serializable;

public interface ReaderWriter extends Reader, Writer, Serializable {
}

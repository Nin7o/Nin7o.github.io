package mapReduce;

import java.util.HashMap;

import daemon.JobLauncher;
import interfaces.FileReaderWriter;
import interfaces.KV;
import interfaces.MapReduce;
import interfaces.Reader;
import interfaces.Writer;

/**
 * Classe de test pour le MapReduce, travaillant cette fois si sur
 * un fichier de type KV
 */
public class KVMapReduce implements MapReduce {

    @Override
    public void map(Reader reader, Writer writer) {
        KV kv;
        while ((kv = reader.read()) != null) {
            System.out.println(kv.toString());
            writer.write(kv);
        }
    }

    @Override
    public void reduce(Reader reader, Writer writer) {
        HashMap<String,Integer> hm = new HashMap<String,Integer>();
		KV kv;
		while ((kv = reader.read()) != null) {
			String key = kv.k;
            if (hm.containsKey(key)) {
                hm.put(key, hm.get(key) + Integer.parseInt(kv.v));
            } else {
                hm.put(key, Integer.parseInt(kv.v));
            }
        }
        for (String k : hm.keySet()) {
            writer.write(new KV(k,hm.get(k).toString()));
        }
    }

    public static void main(String args[]) {
        long t1 = System.currentTimeMillis();
        JobLauncher.startJob(new KVMapReduce(), FileReaderWriter.FMT_KV, args[0]);
        long t2 = System.currentTimeMillis();
        System.out.println("time in ms ="+(t2-t1));
        System.exit(0);
    }

}
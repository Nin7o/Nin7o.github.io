package mapReduce;

import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.ArrayList;

import daemon.JobLauncher;
import interfaces.FileReaderWriter;
import interfaces.KV;
import interfaces.MapReduce;
import interfaces.Reader;
import interfaces.Writer;

/**
 * Classe MapReduce qui utilise plusieurs threads pour le Map
 * et un thread pour le Reduce
 * 
 * Dans le map, la lecture est faite par un thread, et le traitement
 * par plusieurs threads
 */
public class Thread implements MapReduce{
    private static final long serialVersionUID = 1L;

    static class MapRunnable implements Runnable {
        private int threadNumber;
        private int nbThreads;
        private List<KV> kvs;
        private List<ConcurrentHashMap<String,Integer>> hms;

        public MapRunnable(int threadNumber, int nbThreads, List<KV> kvs, List<ConcurrentHashMap<String,Integer>> hms) {
            this.threadNumber = threadNumber;
            this.nbThreads = nbThreads;
            this.kvs = kvs;
            this.hms = hms;
        }

        @Override
        public void run() {
            int nbKVs = kvs.size();
            int nbKVsPerThread = nbKVs / nbThreads;
            int nbKVsLastThread = nbKVs - nbKVsPerThread * (nbThreads - 1);

            int nbKVsThread = (threadNumber == nbThreads - 1) ? nbKVsLastThread : nbKVsPerThread;
            ConcurrentHashMap<String,Integer> hm = new ConcurrentHashMap<String,Integer>();
            for (int j = 0; j < nbKVsThread; j++) {
                KV kv = kvs.get(threadNumber * nbKVsPerThread + j);
                String tokens[] = kv.v.split(" ");
                for (String tok : tokens) {
                    if (hm.containsKey(tok)) hm.put(tok, hm.get(tok)+1);
                    else hm.put(tok, 1);
                }
            }
            hms.add(hm);
            hm = null;
        }
    }

    private int nbThreads;

    /**
     * Permet de définir le nombre de threads à utiliser
     * @param nbThreads
     */
    public void setNbThreads(int nbThreads) {
        this.nbThreads = nbThreads;
    }

    /**
     * Permet de lancer le Map
     * @param reader le reader
     * @param writer le writer
     */
    @Override
    public void map(Reader reader, Writer writer) {

        //List<Thread> threads = new ArrayList<>();
        List<ConcurrentHashMap<String,Integer>> hms = new ArrayList<>();
        ConcurrentHashMap<String,Integer> mainHashMap = new ConcurrentHashMap<String,Integer>();
        List<KV> kvs = new ArrayList<>();
        List<KV> threadKvs = new ArrayList<>();
        Boolean readall = false;
        KV kv;

        while (true) {
            kv = reader.read();
            if (kv == null) {
                readall = true;
                break;
            }
            threadKvs.add(kv);
            if (threadKvs.size() == 100000) break;
        }

        do {

            ExecutorService executor = Executors.newFixedThreadPool(nbThreads);

            for (int i = 0; i < nbThreads; i++) {
                executor.execute(new MapRunnable(i, nbThreads, threadKvs, hms));
            }

            while (true) {
                
                if ((kv = reader.read()) == null) {
                    readall = true;
                    break;
                }
                kvs.add(kv);
                if (kvs.size() == 100000) break;
            }

            try{
                executor.shutdown();
                executor.awaitTermination(Long.MAX_VALUE, java.util.concurrent.TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            threadKvs.clear();
            threadKvs.addAll(kvs);
            kvs.clear();

            //add all the hashmaps to the main hashmap
            for (ConcurrentHashMap<String,Integer> hm : hms) {
                for (String k : hm.keySet()) {
                    if (mainHashMap.containsKey(k)) mainHashMap.put(k, mainHashMap.get(k)+hm.get(k));
                    else mainHashMap.put(k, hm.get(k));
                }
            }

            hms.clear();

        } while (!readall || !threadKvs.isEmpty());

        for (String k : mainHashMap.keySet()) writer.write(new KV(k,mainHashMap.get(k).toString()));

        mainHashMap = null;
        hms = null;
        kvs = null;
        threadKvs = null;
    }

    /**
     * Permet de lancer le Reduce
     * @param reader le reader
     * @param writer le writer
     */
    @Override
    public void reduce(Reader reader, Writer writer) {
        HashMap<String,Integer> hm = new HashMap<String,Integer>();
		KV kv;
		while ((kv = reader.read()) != null) {
			if (hm.containsKey(kv.k)) hm.put(kv.k, hm.get(kv.k)+Integer.parseInt(kv.v));
			else hm.put(kv.k, Integer.parseInt(kv.v));
		}
		for (String k : hm.keySet()) writer.write(new KV(k,hm.get(k).toString()));
    }
    
    /**
     * Méthode main
     * @param args nom du fichier à traiter et nombre de threads à utiliser
     */
    public static void main(String args[]) {
        int nbThreads = Integer.parseInt(args[1]);
        System.out.println("nbThreads = "+nbThreads);
        long t1 = System.currentTimeMillis();
        Thread myMapReduceMultiThread = new Thread();
        myMapReduceMultiThread.setNbThreads(nbThreads);
        JobLauncher.startJob(myMapReduceMultiThread, FileReaderWriter.FMT_TXT, args[0]);
        long t2 = System.currentTimeMillis();
        System.out.println("time in ms ="+(t2-t1));
        System.exit(0);
    }
}

package mapReduce;

import interfaces.KV;
import interfaces.MapReduce;
import interfaces.Reader;
import interfaces.Writer;

/**
 * Classe de test pour le MapReduce
 * Affiche les KV lus
*/
public class TestMapReduce implements MapReduce {

    @Override
    public void map(Reader reader, Writer writer) {
        KV kv;
        while ((kv = reader.read()) != null) {
            System.out.println(kv.toString());
        }
        }

    @Override
    public void reduce(Reader reader, Writer writer) {
         
        throw new UnsupportedOperationException("Unimplemented method 'reduce'");
    }
    
}

package config;

/**
 * Classe permettant d'afficher une barre de progression
 */
public class ProgressBar {

    
    /** 
     * Permet de mettre à jour la barre d'avancement
     * @param current le nombre courant de traitements effectués
     * @param total le nombre total de traitements à effectuer
     */
    public static void updateProgressBar(int current, int total) {
        updateProgressBar((long) current, (long) total);
    }

    
    /** 
     * Permet de mettre à jour la barre d'avancement
     * @param current le nombre courant de traitements effectués
     * @param total le nombre total de traitements à effectuer
     */
    public static void updateProgressBar(long current, long total) {
        int progress = (int) ((double) current / total * 100);
        StringBuilder progressBar = new StringBuilder("[");
        int progressBarWidth = 50;
        int numHashes = (int) ((double) progress / 100 * progressBarWidth);

        for (int i = 0; i < progressBarWidth; i++) {
            if (i < numHashes) {
                progressBar.append('#');
            } else {
                progressBar.append(' ');
            }
        }

        progressBar.append("] " + progress + "%");
        System.out.print("\r" + progressBar.toString());
    }

    
    /** 
     * Permet de mettre à jour la barre d'avancement avec ETA
     * @param current le nombre courant de traitements effectués
     * @param total le nombre total de traitements à effectuer
     * @param startTime l'heure de départ en ms
     */
    public static void updateProgressBarWithETA(long current, long total, long startTime) {
        int progress = (int) ((double) current / total * 100);
        StringBuilder progressBar = new StringBuilder("[");
        int progressBarWidth = 50;
        int numHashes = (int) ((double) progress / 100 * progressBarWidth);
    
        for (int i = 0; i < progressBarWidth; i++) {
            if (i < numHashes) {
                progressBar.append('#');
            } else {
                progressBar.append(' ');
            }
        }
    
        progressBar.append("] " + progress + "%");
    
        // Calculate elapsed time
        long elapsedTime = System.currentTimeMillis() - startTime;
    
        // Calculate estimated time to completion
        long estimatedTimeToCompletion = (long) ((double) elapsedTime / progress * (100 - progress));
    
        // Format estimated time to completion
        String etaFormatted = formatETA(estimatedTimeToCompletion);
    
        progressBar.append(" Estimate: " + etaFormatted + "           ");
        System.out.print("\r" + progressBar.toString());
    }
    
    
    /** 
     * Cette fonction permet de formater un temps en ms en une chaîne hh:mm:ss
     * @param etaMillis l'heure d'arrivée en millisecondes
     * @return l'heure d'arrivée en format hh:mm:ss
     */
    private static String formatETA(long etaMillis) {
        long seconds = etaMillis / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
    
        return String.format("%02d:%02d:%02d", hours, minutes % 60, seconds % 60);
    }


}

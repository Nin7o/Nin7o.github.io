package config;

import java.io.*;
import java.util.*;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;

/**
 * Classe qui contient les informations sur le cluster : 
 * chemins vers les fichiers de configuration,
 * chemins vers les dossiers de travail,
 * va chercher les adresses et ports des noeuds dans nodes.txt
 * va chercher l'adresse du client
 */
public class Project {

	public static String CONFIGPATH = "/home/nin7o/Documents/Cours/hagidoop/config/";
	public static String NODEPATH = "/work/";
	public static String DATAPATH = "/home/nin7o/Documents/Cours/hagidoop/data/";
	public static String CLIENTPATH = "/home/nin7o/Documents/Cours/hagidoop/clientDir/";

	public static String nodeConfigFileName = "nodes.txt";

	public int CLIENT_PORT = 4000;
	public String CLIENT_ADDRESS;

	public List<Integer> ports = new ArrayList<>();
	public List<Integer> WorkerPorts = new ArrayList<>();
	public List<String> addresses = new ArrayList<>();

	public int nbNodes = 0;

	// analyse nodes.txt et le stocke dans les attributs
	public Project() {
		
		String nodePath = CONFIGPATH + nodeConfigFileName;
		File nodeFile = new File(nodePath);

		try {

			// get the client address
			try {
			    Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
			    while (interfaces.hasMoreElements()) {
			        NetworkInterface iface = interfaces.nextElement();
			        if (iface.isLoopback() || !iface.isUp() || iface.isVirtual() || iface.isPointToPoint())
			            continue;
				
			        Enumeration<InetAddress> addresses = iface.getInetAddresses();
			        while(addresses.hasMoreElements()) {
			            InetAddress addr = addresses.nextElement();
					
			            final String ip = addr.getHostAddress();
			            if(Inet4Address.class == addr.getClass()) {
							CLIENT_ADDRESS = ip;
							break;
						}
			        }
			    }
			} catch (SocketException e) {
			    throw new RuntimeException(e);
			}

			BufferedReader br = new BufferedReader(new FileReader(nodeFile));
			String line;
			int n = 0;

			while ((line = br.readLine()) != null) {
				String[] parts = line.split(" ");
				this.addresses.add(parts[0]);
				this.ports.add(Integer.parseInt(parts[1]));
				this.WorkerPorts.add(Integer.parseInt(parts[2]));
				n++;
			}

			this.nbNodes = n;
			br.close();

		} catch (Exception e) {
			System.out.println("Error while reading nodes.txt");
			System.exit(1);
		}

	}

}

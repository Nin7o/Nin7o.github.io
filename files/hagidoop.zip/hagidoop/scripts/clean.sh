#!/bin/bash
# Variables : 
login="ngauthie2"
hagidoop_dir="/home/nin7o/Documents/Cours/hagidoop/"
hagidoop_bin_dir="/home/nin7o/Documents/Cours/hagidoop/bin/"
hagidoop_config_file="/home/nin7o/Documents/Cours/hagidoop/config/nodes.txt"
hagidoop_src_dir="/home/nin7o/Documents/Cours/hagidoop/src/"

hagidoop_remote_bin_dir="/work/bin/"
hagidoop_remote_dir="/work/"

cd "$hagidoop_src_dir"

# Get the current directory
current_dir=$(pwd)

# Use grep to extract the desired directory
desired_dir=$(echo "$current_dir" | grep -oE '.*/hagidoop')

echo "working directory is $desired_dir"
echo ""
cd "$desired_dir"
cd src
cd config 


filename="Project.java"

# Check if the file exists
if [ ! -f "$filename" ]; then
    echo "Error: File $filename not found."
    exit 1
fi

# Iterate through each line in the file
while IFS= read -r line; do
    # Check if the line contains the string "NODEPATH"
    if [[ $line == *NODEPATH* ]]; then
        # Extract and clean up the path part of the line
        path=$(echo "$line" | awk -F= '{print $2}' | tr -d '[:space:];"')
    fi
done < "$filename"

# Check if the file exists
if [ ! -f "$hagidoop_config_file" ]; then
    echo "File not found: $hagidoop_config_file"
    exit 1
fi

# Read the file line by line and extract the port number
while read -r line; do
    # Use awk to extract values
    address=$(echo "$line" | awk '{print $1}')
    portHDFS=$(echo "$line" | awk '{print $2}')
    portWorker=$(echo "$line" | awk '{print $3}')

    # Check if both address and port are present
    if [ -n "$address" ] && [ -n "$portHDFS" ] && [ -n "$portWorker" ]; then
        #pkill hdfs and worker
        ssh $login@$address pkill -f "hdfs.HdfsServer" &
        ssh $login@$address pkill -f "daemon.WorkerImpl" &

        echo "killed all HdfsServer and Worker processes on $address"

        # Clean up the directory
        ssh $login@$address rm -rf $hagidoop_remote_dir/$portHDFS &
        ssh $login@$address rm -rf $hagidoop_remote_dir/bin/ &
        echo "Cleaned up the directory $hagidoop_remote_dir$portHDFS on $address"
    fi
done < "$hagidoop_config_file"

#!/bin/bash
# Variables : 
login="ngauthie2"
hagidoop_dir="/home/nin7o/Documents/Cours/hagidoop/"
hagidoop_bin_dir="/home/nin7o/Documents/Cours/hagidoop/bin/"
hagidoop_config_file="/home/nin7o/Documents/Cours/hagidoop/config/nodes.txt"
hagidoop_src_dir="/home/nin7o/Documents/Cours/hagidoop/src/"

hagidoop_remote_bin_dir="/work/bin/"
hagidoop_remote_dir="/work/"

cd "$hagidoop_src_dir"

javac -source 11 -target 11 -d ../bin application/*.java
javac -source 11 -target 11 -d ../bin mapReduce/*.java
javac -source 11 -target 11 -d ../bin config/*.java
javac -source 11 -target 11 -d ../bin daemon/*.java
javac -source 11 -target 11 -d ../bin hdfs/*.java
javac -source 11 -target 11 -d ../bin interfaces/*.java
javac -source 11 -target 11 -d ../bin io/*.java

cd "$hagidoop_dir"

mkdir -p hagidoopDir
mkdir -p clientDir

# Check if the file exists
if [ ! -f "$hagidoop_config_file" ]; then
    echo "File not found: $hagidoop_config_file"
    exit 1
fi

# Read the file line by line and extract the port number
while read -r line; do

    echo "$line"

    # Use awk to extract values
    address=$(echo "$line" | awk '{print $1}')
    portHDFS=$(echo "$line" | awk '{print $2}')
    portWorker=$(echo "$line" | awk '{print $3}')

    # Check if both address and port are present
    if [ -n "$address" ] && [ -n "$portHDFS" ] && [ -n "$portWorker" ]; then
        # scp needed files to the remote machine
        scp -r "$hagidoop_bin_dir" "$login@$address:$hagidoop_remote_dir"
        echo "file copied to $address"
        
        # Launch the HdfsServer and Worker processes
        ssh -f $login@$address "java -cp $hagidoop_remote_bin_dir hdfs.HdfsServer $portHDFS" &> /dev/null
        echo "launched an HdfsServer on address $address on port $portHDFS"
        ssh -f $login@$address "java -cp $hagidoop_remote_bin_dir daemon.WorkerImpl $address $portWorker" &> /dev/null
        echo "launched a Worker on address $address on port $portWorker"
    fi
done < "$hagidoop_config_file"

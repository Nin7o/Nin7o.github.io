package map;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class Matrix {
	
	String path;
	
	int rows;
	int columns;
	
	int[][] matrix;
	
	public Matrix(String path, int rows, int columns) {
	
		this.path = path;
		this.rows = rows;
		this.columns = columns;
		
		try {
			
			Scanner scanner = new Scanner(new BufferedReader(new FileReader(path)));
			
			this.matrix = new int[rows][columns];
			
			while (scanner.hasNextLine()) {
				for (int i=0; i<matrix.length; i++) {
		            String[] line = scanner.nextLine().trim().split(" ");
		            for (int j=0; j<line.length; j++) {
		               matrix[i][j] = Integer.parseInt(line[j]);
		            }
		         }
			}
			
			
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}
		
		System.out.println(matrix);
	}
	
	public int[][] getMatrix() {
		return matrix;
	}
	
}

package map;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;

import javax.imageio.ImageIO;
import gameWindow.GamePanel;

public class Map {
	
	GamePanel gp;
	public BufferedImage bg;
	int numeroMap;
	
	private static HashMap<Integer,Integer[]> coordonneesTeleportations= chargerCoordonneesTeleportations();
	
	public Map(GamePanel gp, int numeroMap) {
		this.numeroMap = numeroMap;
		this.gp = gp;
		getBgImage();
	}

	public void getBgImage() {
		
		try {
			
			bg = ImageIO.read(new File("map/Map" + numeroMap + ".png"));
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void draw(Graphics2D g2) {
		
		g2.drawImage(bg, 0, 0, GamePanel.maxScreenColumn*GamePanel.tileSize, GamePanel.maxScreenRow*GamePanel.tileSize, null);
	}
	
	public static HashMap<Integer,Integer[]> getCoordonneesTeleportations() {
		return coordonneesTeleportations;
	}
	
	public static HashMap<Integer,Integer[]> chargerCoordonneesTeleportations(){
		HashMap<Integer,Integer[]> coordTeleport = new HashMap<>();
		
		File fichierObjets = new File("map/coordonneesTeleportations.txt");
		Scanner scanner;
		try {
			scanner = new Scanner(fichierObjets);
			
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				String[] args = line.split(" ");
				if (!args[0].equals("%")) {
					int hash = Integer.parseInt(args[0]);
					Integer[] tab = new Integer[3];
						
					for (int i = 0; i < 3; i++) {
						tab[i] = Integer.parseInt(args[i+1]);
					}
		
					coordTeleport.put(hash, tab);
				}
				
			}
			
			scanner.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return coordTeleport;
	}
}

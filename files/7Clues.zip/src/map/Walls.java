package map;

import gameWindow.GamePanel;
import tiles.*;

public class Walls {
	
	GamePanel gp;
	public Tile[] tile;
	public int[][] matrix;
	public int numeroMap;
	private int nbMaxTeleportation = 10;
	
	public Walls(GamePanel gp, int numeroMap) {
		this.numeroMap = numeroMap;
		this.gp = gp;
		this.tile = new Tile[nbMaxTeleportation];
		getTileInteractions();
		Matrix matrice = new Matrix("map/Map" + numeroMap + "Interactions.txt",GamePanel.maxScreenRow,GamePanel.maxScreenColumn);
		this.matrix = matrice.getMatrix();
	}

	public void getTileInteractions() {
		
			/* Tiles pour les téléportations */
			for (int i = 2; i < nbMaxTeleportation; i++) {
				tile[i] = new Tile();
				tile[i].collision = false;
				tile[i].mapSwitch = true;
				tile[i].mapSwitchNumber = i;
			}

			/* Mur */
			tile[1] = new Tile();
			tile[1].collision = true;
			tile[1].mapSwitch = false;
			tile[1].mapSwitchNumber = -1;
			
			/* Sol */
			tile[0] = new Tile();
			tile[0].collision = false;
			tile[0].mapSwitch = false;
			tile[0].mapSwitchNumber = -1;
		
	}
}

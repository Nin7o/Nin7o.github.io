package exceptions;

import entite.Objet.NomObjet;

public class TailleMaxInventaireAtteinteException extends RuntimeException {
	
	public TailleMaxInventaireAtteinteException(NomObjet nom) {
		super("l'objet suivant n'a pas pu être ajouté car le sac était plein : " + nom.toString());
	}
	
}

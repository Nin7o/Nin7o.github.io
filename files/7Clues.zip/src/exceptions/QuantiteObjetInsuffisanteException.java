package exceptions;

import entite.Objet.NomObjet;

public class QuantiteObjetInsuffisanteException extends RuntimeException {
	
	public QuantiteObjetInsuffisanteException(NomObjet nom, int quantiteManquante) {
		super("il n'y a pas assez de" + nom.toString() + " : " + quantiteManquante + " manquant(s)");
	}
}

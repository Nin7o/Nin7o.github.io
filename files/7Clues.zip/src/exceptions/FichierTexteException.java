package exceptions;

public class FichierTexteException extends RuntimeException {
	public FichierTexteException(String message) {
		super(message);
	}
}

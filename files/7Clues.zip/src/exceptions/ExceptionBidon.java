package exceptions;

public class ExceptionBidon extends RuntimeException {
	
	public ExceptionBidon(String message) {
		super(message);
	}
}
package inputs;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.HashSet;
import java.util.Set;

import gameWindow.PausePanel;

public class OurKeyListener implements KeyListener{
	
	private Set<Integer> keyPressed = new HashSet<Integer>();
	private Set<Integer> keyTyped = new HashSet<Integer>();
	
	@Override
	public void keyTyped(KeyEvent e) {
		char key = e.getKeyChar();
		this.traitementInputTyped(key);		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int key = e.getKeyCode();
		this.traitementInputPressed(key);
	}

	@Override
	public void keyReleased(KeyEvent e) {
		int key = e.getKeyCode();
		this.traitementInputReleased(key);
	}
	
	/** Appelle l'action à réaliser en fonction de la touche du clavier appuyer.
	 * 
	 * @param key la touche appuyer
	 */
	private void traitementInputPressed(int key) {
		switch (key) {
			case KeyEvent.VK_D : // se déplacer vers l'est
				keyPressed.add(KeyEvent.VK_D);
				break;
			case KeyEvent.VK_Q: // se déplacer vers l'ouest
				keyPressed.add(KeyEvent.VK_Q);
				break;
			case KeyEvent.VK_Z: // se déplacer vers le nord
				keyPressed.add(KeyEvent.VK_Z);
				break;
			case KeyEvent.VK_S: // se déplacer vers le sud
				keyPressed.add(KeyEvent.VK_S);
				break;
			case KeyEvent.VK_A: // attaquer
				keyPressed.add(KeyEvent.VK_A);
				break;
			case KeyEvent.VK_E: // interagir
				keyPressed.add(KeyEvent.VK_E);
				break;
			case KeyEvent.VK_I: // ouvrir l'inventaire
				break;
			case KeyEvent.VK_O: // ouvrir le menu des quêtes
				break;
			case KeyEvent.VK_P: // mettre le jeu en pause
				
				break;
			case KeyEvent.VK_TAB: // afficher la map en grand
				break;
			case KeyEvent.VK_ESCAPE:
				keyPressed.add(KeyEvent.VK_ESCAPE);
				break;
			case KeyEvent.VK_ENTER:
				keyPressed.add(KeyEvent.VK_ENTER);
				break;
		}
	}
	
	private void traitementInputReleased(int key) {
		switch (key) {
			case KeyEvent.VK_D :
				keyPressed.remove(KeyEvent.VK_D);
				break;
			case KeyEvent.VK_Q:
				keyPressed.remove(KeyEvent.VK_Q);
				break;
			case KeyEvent.VK_Z:
				keyPressed.remove(KeyEvent.VK_Z);
				break;
			case KeyEvent.VK_S:
				keyPressed.remove(KeyEvent.VK_S);
				break;
			case KeyEvent.VK_A:
				keyPressed.remove(KeyEvent.VK_A);
				break;
			case KeyEvent.VK_E:
				keyPressed.remove(KeyEvent.VK_E);
				break;
			case KeyEvent.VK_M: // map
				break;
			case KeyEvent.VK_ESCAPE:
				keyPressed.remove(KeyEvent.VK_ESCAPE);
				break;
			case KeyEvent.VK_ENTER:
				keyPressed.remove(KeyEvent.VK_ENTER);
				break;
			case KeyEvent.VK_P:
				//if (keyTyped.contains(KeyEvent.VK_P)) {
				//	keyTyped.add(KeyEvent.VK_P);
				//} else {
				//	keyTyped.remove(KeyEvent.VK_P);
				//}
				//keyPressed.remove(KeyEvent.VK_P);
				System.out.println("pause");
				//PausePanel.menuPause(this);
				break;
		}
	}
	/**
	 * Penser à remettre la valeur à false après traitement
	 * @param key
	 */
	private void traitementInputTyped(char key) { // ne marche pas // finalement marche j'étais juste bête
		//System.out.print(key);
		switch (key) {
		case 'a':
			System.out.println("A");
			keyTyped.add(KeyEvent.VK_A);
			break;
		case 'c':
			System.out.println("C");
			keyTyped.add(KeyEvent.VK_C);
		case 'e':
			System.out.println("E");
			keyTyped.add(KeyEvent.VK_E);
			break;
		case 'p':
			System.out.println("P");
			keyTyped.add(KeyEvent.VK_P);
			//PausePanel.menuPause(this);
			break;
		case '\n':
			System.out.println("ENTER");
			keyTyped.add(KeyEvent.VK_ENTER);
			break;
		case 'i':
			System.out.println("I");
			keyTyped.add(KeyEvent.VK_I);
		case '&':
			System.out.println("chiffre");
			keyTyped.add(KeyEvent.VK_1);
		case 'é':
			System.out.println("chiffre");
			keyTyped.add(KeyEvent.VK_2);
		case '"':
			System.out.println("chiffre");
			keyTyped.add(KeyEvent.VK_3);
		case '\'':
			System.out.println("chiffre");
			keyTyped.add(KeyEvent.VK_4);
		case '(':
			System.out.println("chiffre");
			keyTyped.add(KeyEvent.VK_5);
			break;
		}
		
	}
	
	public boolean isKeyPressed(int key) {
		if (keyPressed.contains(key)) {
			return true;
		}
		return false;
	}
	/**
	 * verifie si la touche a été tapé ///et la supose traité ensuite (n'appartient plus à la liste)(finalement non)
	 * @param key
	 * @return
	 */
	public boolean isKeyTyped(int key) {
		if (keyTyped.contains(key)) {
			//keyTyped.remove(key);
			return true;
		}
		return false;
	}
	
	public void traiterTyped(int key) {
		keyTyped.remove(key);
	}

}

package gameWindow;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import entite.Joueur;
import entite.Objet;
import entite.Objet.NomObjet;
import gameWindow.Main.STATE;

public class SacPanel extends JPanel {
	
	final private JButton bRetour = new Bouton("Retour au jeu", new ActionQuitter());
	
	// Joueur
	private Joueur joueur;
	private Map<NomObjet,Objet> inventaire;
	private int nbLignesSac = 3;
	private int nbColonnesSac = 4;
	
	// Panel
	private JPanel blocCentral;
	private JPanel contenantCase;
	
	private JPanel[][] cases = new JPanel[nbLignesSac][nbColonnesSac];
	
	public SacPanel(Joueur joueur) {
		this.joueur = joueur;
		this.inventaire = joueur.getInventaire();
		
		// panel
		this.setLayout(new BorderLayout());
		this.setBackground(OurColor.beige);
		
		// bouton retour
		JPanel retour = new JPanel();
		retour.add(bRetour);
		retour.setBackground(OurColor.beige);
		this.add(retour,BorderLayout.SOUTH);
		
		// titre
		JLabel titre = new JLabel("Valise");
		titre.setFont(OurFont.titre);
		titre.setHorizontalAlignment(SwingConstants.CENTER);
		titre.setVerticalAlignment(SwingConstants.BOTTOM);
		titre.setBackground(Color.blue);
		this.add(titre,BorderLayout.NORTH);
		
		// bloc central
		blocCentral = new JPanel();
		blocCentral.setLayout(new BorderLayout());
		blocCentral.setBackground(OurColor.beige);
		
		// pour que les cases soient au bon endroit

		int largeurCote = (int) (Main.getFenetre().getWidth()*0.2);
		int hauteurCote = (int) (Main.getFenetre().getHeight());
		Component boiteEast = Box.createRigidArea(new Dimension(largeurCote,hauteurCote));
		Component boiteWest = Box.createRigidArea(new Dimension(largeurCote,hauteurCote));
		

		int largeurPasCote = (int) (Main.getFenetre().getWidth());
		int hauteurPasCote = (int) (Main.getFenetre().getHeight()*0.1);
		Component boiteNorth = Box.createRigidArea(new Dimension(largeurPasCote,hauteurPasCote));
		Component boiteSouth = Box.createRigidArea(new Dimension(largeurPasCote,hauteurPasCote));
		
		blocCentral.add(boiteWest,BorderLayout.WEST);
		blocCentral.add(boiteEast,BorderLayout.EAST);
		blocCentral.add(boiteNorth,BorderLayout.NORTH);
		blocCentral.add(boiteSouth,BorderLayout.SOUTH);
		
		// contenant des cases
		
		contenantCase = new JPanel();
		GridLayout contenantCaseLayout = new GridLayout(nbLignesSac,nbColonnesSac);
		contenantCaseLayout.setHgap(5);
		contenantCaseLayout.setVgap(5);
		contenantCase.setLayout(contenantCaseLayout);
		
		// cases
		int i = 0;
		int j = 0;
		for (Map.Entry<NomObjet,Objet> objet : inventaire.entrySet()) {
			this.cases[i][j] = new CasePanelPourSac(objet.getValue(), this.joueur);
			j++;
			if (j >= nbColonnesSac) {
				i++;
				j = 0;
			}
		}
		while (j < nbColonnesSac && i < nbLignesSac) {

			this.cases[i][j] = new CasePanelPourSac(null, null);
			j++;
			if (j >= nbColonnesSac) {
				i++;
				j = 0;
			}
		}
		
		for (i = 0; i < nbLignesSac; i++) {
			for (j = 0; j < nbColonnesSac; j++) {
				contenantCase.add(this.cases[i][j]);
			}
		}
		
		
		blocCentral.add(contenantCase);
		
		this.add(blocCentral, BorderLayout.CENTER);
		
	}
	
	// A voir si on garde cette méthode ou pas
	public void mettreAJour() {
		this.inventaire = this.joueur.getInventaire();
		
		this.contenantCase.removeAll();
		//this.blocCentral.remove(contenantCase);
		
		int i = 0;
		int j = 0;
		for (Map.Entry<NomObjet,Objet> objet : inventaire.entrySet()) {
			this.cases[i][j] = new CasePanelPourSac(objet.getValue(), null);
			j++;
			if (j >= nbColonnesSac) {
				i++;
				j = 0;
			}
		}
		while (j < nbColonnesSac && i < nbLignesSac) {
			this.cases[i][j] = new CasePanelPourSac(null, null);
			j++;
			if (j >= nbColonnesSac) {
				i++;
				j = 0;
			}
		}
		
		for (i = 0; i < nbLignesSac; i++) {
			for (j = 0; j < nbColonnesSac; j++) {
				contenantCase.add(this.cases[i][j]);
			}
		}
		
		//blocCentral.add(contenantCase);
		//this.add(blocCentral);
	}
	
	/**
	 * Au cas où l'on a besoin de changer la taille de l'inventaire
	 * @param nbLignes
	 * @param nbColonnes
	 */
	public void changerDimensionSac(int nbLignes, int nbColonnes) {
		this.nbColonnesSac = nbColonnes;
		this.nbLignesSac = nbLignes;
	}

	
	public class ActionQuitter implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Quitter le sac");
			Main.setState(STATE.GAME);
		}
	}
}

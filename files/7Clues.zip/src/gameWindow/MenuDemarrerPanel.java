package gameWindow;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import gameWindow.Main.STATE;

public class MenuDemarrerPanel extends JPanel {

	
	// Taille de la fenêtre
	final protected static int WIDTH = 1280;
	final protected static int HEIGHT = 800;
	
	// Boutons
	final private JButton bJouer = new Bouton("Nouvelle partie", new ActionNew());
	final private JButton bCharger = new Bouton("Charger une partie", new ActionCharger());
	final private JButton bOptions = new Bouton("Options", new ActionOptions());
	final private JButton bQuitter = new Bouton("Quitter", new ActionQuitter());
	
	// background
	private BufferedImage backgroundBuff;
	private Image backgroundImg;
	private int imgW;
	private int imgH;
	
	public MenuDemarrerPanel() {
		super();
		
		// Creation de boites pour la mise en forme
		Component boiteEast = Box.createRigidArea(new Dimension((int) (WIDTH/8),(int) (HEIGHT*0.1)));
		Component boiteWest = Box.createRigidArea(new Dimension((int) (WIDTH/2),(int) (HEIGHT*0.1)));
		Component boiteSouth = Box.createRigidArea(new Dimension((int) (WIDTH/4),(int) (HEIGHT*0.1)));
		Component boiteNorth= Box.createRigidArea(new Dimension((int) (WIDTH/4),(int) (HEIGHT*0.08)));
		
		
		// Le nom du jeu
		JLabel titre = new JLabel("7Clues");
		titre.setHorizontalAlignment(JLabel.CENTER);
		titre.setFont(OurFont.titre);
		JPanel pTitre = new JPanel();
		pTitre.add(titre);
		
		
		// Creation des panels
		JPanel buttons = new JPanel();
		JPanel pMenuCentre = new JPanel();
		
		// Definition des Layouts
		pTitre.setLayout(new GridLayout(1,1,0,(int) (HEIGHT*0.005)));
		
		GridLayout grilleButtons = new GridLayout(4,1);
		grilleButtons.setVgap((int) (HEIGHT*0.02)); // definit un espacement vertical entre les bouttons
		buttons.setLayout(grilleButtons);
		
		GridLayout grilleGlobale = new GridLayout(2,1);
		pMenuCentre.setLayout(grilleGlobale);
		
		this.setLayout(new BorderLayout());
		
		
		// image de fond
		try {
			backgroundBuff = ImageIO.read(new File("fond/backgroundMenu.jpg"));
			
			imgW = backgroundBuff.getWidth();
			imgH = backgroundBuff.getHeight();
			float facteur = (float) imgW/WIDTH + 2;	
			imgW = (int) (facteur*imgW);
			imgH = (int) (facteur*imgH);
			backgroundImg = backgroundBuff.getScaledInstance(imgW, imgH, Image.SCALE_DEFAULT);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
		pMenuCentre.setOpaque(false);
		buttons.setOpaque(false);
		pTitre.setOpaque(false);
		
		// Ajouter les boutons au panel rassemblant les boutons
		buttons.add(bJouer); 
		buttons.add(bCharger);
		buttons.add(bOptions);
		buttons.add(bQuitter);
		
		
		// Ajouter ses composants au panel rassemblant le titre et les boutons
		pMenuCentre.add(pTitre);
		pMenuCentre.add(buttons);
		
		
		// placement des composants sur le panel du menu
		this.add(pMenuCentre,BorderLayout.CENTER);
		this.add(boiteEast,BorderLayout.EAST);
		this.add(boiteWest,BorderLayout.WEST);
		this.add(boiteSouth,BorderLayout.SOUTH);
		this.add(boiteNorth,BorderLayout.NORTH);
		
		
		// coloration
		pTitre.setBackground(OurColor.beige);
		buttons.setBackground(OurColor.beige);
		pMenuCentre.setBackground(OurColor.beige);
		this.setBackground(OurColor.beige);
		
		
	}	
	 
	
	public class ActionNew implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Nouvelle partie");
			Main.setState(STATE.GAME,0);
		}
	}
	
	public class ActionCharger implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Charger");
			Main.setState(STATE.CHARGE);
		}
	}
	
	public class ActionOptions implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Options");
			Main.setState(STATE.OPTION);
		}
	}
	
	public class ActionQuitter implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Quitter");
			System.exit(0);
		}
	}
	
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(backgroundImg, WIDTH/2 - imgW/2, HEIGHT/2 - imgH/2, this);
	}
	
}

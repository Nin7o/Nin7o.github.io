package gameWindow;

import java.awt.Color;

public class OurColor extends Color {
	
	// Couleur
	public static final Color beige = new Color(229,226,193);
	public static final Color beigeFonce = new Color(219,216,183);
	public static final Color bleu2 = new Color(39,99,110);
	public static final Color bleugris = new Color(128,167,174);

	public static final Color rouge = new Color(255, 0, 100); 
	public static final Color vert = new Color(0, 255, 100); 
	public static final Color orange = new Color(255, 128, 0); 

	public OurColor(int r, int g, int b, int a) {
		super(r, g, b, a);
		// TODO Auto-generated constructor stub
	}

}

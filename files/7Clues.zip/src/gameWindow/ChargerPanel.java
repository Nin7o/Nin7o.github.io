package gameWindow;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import gameWindow.Main.STATE;
import loadsave.Sauvegarde;

public class ChargerPanel extends JPanel {
	
	final private JButton bQuitter = new Bouton("   X   ", new ActionQuitter());
	
	
	private int nbSauvegardes;
	
	public ChargerPanel() {
		
		// panel
		this.setLayout(new BorderLayout());
		this.setBackground(OurColor.beige);
		JLabel titre = new JLabel("Charger une partie");
		titre.setFont(OurFont.titre);
		titre.setHorizontalAlignment(SwingConstants.CENTER);
		titre.setVerticalAlignment(SwingConstants.BOTTOM);
		titre.setBackground(Color.blue);
		
		JPanel centre = new JPanel();
		centre.setBackground(OurColor.bleu2);
		this.nbSauvegardes = Sauvegarde.nbTotalSauvegardes();
		GridLayout layoutListeParties = new GridLayout((int) (this.nbSauvegardes/3),3);
		layoutListeParties.setVgap(15);
		centre.setLayout(layoutListeParties);
		
		/* Si il n'y a aucune sauvegarde déjà existante*/
		if (this.nbSauvegardes == 0) {
			JLabel texte = new JLabel("Aucune sauvegarde disponible");
			texte.setVerticalAlignment(SwingConstants.CENTER);
			texte.setHorizontalAlignment(SwingConstants.CENTER);
			centre.add(texte);
		}
		
		for (int i = 1; i <= this.nbSauvegardes; i++) {
			int numPartie = i;
			JPanel pBouton = new JPanel();
			JButton bChargerPartie = new Bouton("Sauvegarde n°" + numPartie, new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					Main.setState(STATE.GAME,numPartie);	
				}
				
			});
			pBouton.add(bChargerPartie);
			pBouton.setOpaque(false);
			centre.add(pBouton);
			
		}
		
		JPanel nord = new JPanel();
		nord.setBackground(OurColor.beige);
		nord.setLayout(new BorderLayout());
		nord.add(titre, BorderLayout.CENTER);
		nord.add(bQuitter, BorderLayout.LINE_END);	
		this.add(nord, BorderLayout.NORTH);
		this.add(centre, BorderLayout.CENTER);
	}
	
	
	public class ActionQuitter implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Quitter");
			Main.setState(STATE.MENU);
		}
	}
	
}

package gameWindow;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import entite.Joueur;
import entite.Objet;
import entite.Objet.NomObjet;

public class InventairePanel extends JPanel {
	
	private static final int NBOBJETENMAIN = 5;
	private Joueur joueur;
	private Map<NomObjet,Objet> inventaire;
	
	private JPanel orXp;
	private JLabel or;
	private JLabel xp;
	private JLabel hp;
	private JPanel listeObjetsTot;
	private JPanel listeObjets;
	private GridLayout listeObjetsLayout;
	
	public InventairePanel(GamePanel game) {
		
		joueur = game.getPlayer();
		inventaire = joueur.getInventaire();
		this.setLayout(new GridLayout(3,1));
		this.setBackground(Color.PINK);
		
		// Or et Xp possédé
		orXp = new JPanel();
		orXp.setLayout(new GridLayout(4,1));
			
			// Titre
			JLabel titreOrXp = new JLabel("Richesse");
			titreOrXp.setHorizontalAlignment(SwingConstants.CENTER);
			titreOrXp.setVerticalAlignment(SwingConstants.CENTER);
			orXp.add(titreOrXp);//,BorderLayout.NORTH);
			
			// Or
			or = new JLabel("Or : "+"\n" + joueur.getOr());
			or.setHorizontalAlignment(SwingConstants.CENTER);
			or.setVerticalAlignment(SwingConstants.CENTER);
			orXp.add(or);//,BorderLayout.CENTER);
			
			// Xp
			xp = new JLabel("Xp : "+"\n" + joueur.getXp());
			xp.setHorizontalAlignment(SwingConstants.CENTER);
			xp.setVerticalAlignment(SwingConstants.CENTER);
			orXp.add(xp);//,BorderLayout.SOUTH);
			
			// Hp
			hp = new JLabel("hp : "+"\n" + joueur.getHp() + "/" + joueur.getHpMax());
			hp.setHorizontalAlignment(SwingConstants.CENTER);
			hp.setVerticalAlignment(SwingConstants.CENTER);
			orXp.add(hp);//,BorderLayout.SOUTH);
		
		orXp.setBackground(Color.pink);
		this.add(orXp);
		
		// Objet possédé
		listeObjetsTot = new JPanel();
		listeObjetsTot.setLayout(new BorderLayout());
		
		
			// Titre
			JLabel titreListeObjets = new JLabel("Inventaire");
			titreListeObjets.setHorizontalAlignment(SwingConstants.CENTER);
			titreListeObjets.setVerticalAlignment(SwingConstants.CENTER);
			listeObjetsTot.add(titreListeObjets,BorderLayout.NORTH);
			
			// Objets
			listeObjets = new JPanel();
			listeObjetsLayout = new GridLayout(NBOBJETENMAIN,1);
			listeObjetsLayout.setVgap(3);
			listeObjets.setLayout(listeObjetsLayout);
			listeObjets.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			//listeObjets.setMinimumSize(new Dimension(128,128));
			
			
			for (Map.Entry<NomObjet, Objet> e : inventaire.entrySet()) {
				JLabel objetLabel = new CaseLabel(e.getValue(), this.joueur);
				
				//objetLabel.setIcon(e.getValue().getImage());
				//objetLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
				//objetLabel.setHorizontalAlignment(SwingConstants.CENTER);
				
				//objetLabel.setMinimumSize(new Dimension(128,128));
				listeObjets.add(objetLabel);
				
				System.out.println("normalement un objet ajouté dans affichage inventaire");
			}
			
			listeObjets.setBackground(Color.pink);
			
			for (int compteur = 0; compteur < 5 - inventaire.size(); compteur++) {
				JLabel objetVideLabel = new CaseLabel(null, this.joueur);
				//objetVideLabel.setSize(32, 32);
				//objetVideLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
				listeObjets.add(objetVideLabel);
			}
			
			listeObjetsTot.add(listeObjets,BorderLayout.CENTER);
			
			
			// pour la mise en forme 
			Component boiteEast = Box.createRigidArea(new Dimension(32,10));
			boiteEast.setBackground(Color.cyan);
			Component boiteWest = Box.createRigidArea(new Dimension(32,10));
			boiteWest.setBackground(Color.gray);
			Component boiteSouth = Box.createRigidArea(new Dimension(10,10));
			boiteSouth.setBackground(Color.cyan);
			Component boiteNorth = Box.createRigidArea(new Dimension(10,10));
			boiteNorth.setBackground(Color.gray);
			listeObjetsTot.add(boiteWest, BorderLayout.WEST);
			listeObjetsTot.add(boiteEast, BorderLayout.EAST);
			//listeObjetsTot.add(boiteNorth, BorderLayout.NORTH);
			listeObjetsTot.add(boiteSouth, BorderLayout.SOUTH);
			
			this.add(listeObjetsTot);
			//this.setMinimumSize(new Dimension(128,128));
			//System.out.println(this.isMinimumSizeSet());
	}
	
	public void mettreAJourOrXp() {
		// Or
		this.or.setText("Or : "+"\n" + joueur.getOr());
					
		// Xp
		this.xp.setText("Xp : "+"\n" + joueur.getXp());
		
		// Hp
		this.hp.setText("Hp : "+"\n" + joueur.getHp() + "/" + joueur.getHpMax());
		
	}
	
	public void mettreAJourListeObjets() {
		this.inventaire = joueur.getInventaire();
	
		this.listeObjets.removeAll();
		this.listeObjetsTot.remove(listeObjets);
		int nbObjet = 0;
		
		for (Map.Entry<NomObjet, Objet> e : inventaire.entrySet()) {
			if (nbObjet < 5) {
				JLabel objetLabel = new CaseLabel(e.getValue(), this.joueur);
				//objetLabel.setText(" x" + e.getValue().getQuantite());
				
				//objetLabel.setIcon(e.getValue().getImage());
				//objetLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
				//objetLabel.setHorizontalAlignment(SwingConstants.CENTER);
				//objetLabel.setMinimumSize(new Dimension(128,128));
				listeObjets.add(objetLabel);
				
				System.out.println("objet n°" + nbObjet + " ajouté sur " + inventaire.size());
			}
			nbObjet++;
		}
		
		for (int compteur = 0; compteur < 5 - inventaire.size(); compteur++) {
			JLabel objetVideLabel = new CaseLabel(null, this.joueur);
			////objetVideLabel.setSize(32, 32);
			//objetVideLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
			listeObjets.add(objetVideLabel);
		}
		listeObjetsTot.add(listeObjets);
		this.add(listeObjetsTot);
				
	}
}

package gameWindow;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import gameWindow.Main.STATE;

public class MortPanel extends JPanel {
	
	final private JButton bRetourMenu = new Bouton(" Retour au menu principal ", new ActionRetourMenu());
	
	public MortPanel() {
		this.setLayout(new BorderLayout());
		JLabel txt = new JLabel("Vous êtes mort...");
		txt.setHorizontalAlignment(SwingConstants.CENTER);
		txt.setFont(OurFont.titre);
		this.add(txt,BorderLayout.NORTH);
		JLabel image = new JLabel();
		image.setHorizontalAlignment(SwingConstants.CENTER);
		Icon icon = new ImageIcon("images/skull.png");
		image.setIcon(icon);
		JPanel bouton = new JPanel();
		bouton.add(bRetourMenu);
		this.add(image,BorderLayout.CENTER);
		this.add(bouton,BorderLayout.SOUTH);
		System.out.println("mort");
	}
	
	public class ActionRetourMenu implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Retour menu");
			Main.setState(STATE.MENU);
		}
	}
}

package gameWindow;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;

import gameWindow.Main.STATE;
import slider.SliderSonore;
import sound.Son.TYPESON;

public class OptionsPanel extends JPanel {
	
	
	final private JButton bQuitter = new Bouton("   X   ", new ActionQuitter());
	//final private JButton bClear = new Bouton("Réinitialiser", new ActionClear());
	
	//private static String name = "Ecrivez votre nom";
	
	private static Color couleurSon = OurColor.bleugris;
	
	public OptionsPanel() {
		
		// panel
		this.setLayout(new BorderLayout());
		this.setBackground(OurColor.beige);
		JLabel titre = new JLabel("Options");
		titre.setFont(OurFont.titre);
		//titre.setHorizontalTextPosition(JLabel.CENTER);
		//titre.setAlignmentX(CENTER_ALIGNMENT);
		titre.setHorizontalAlignment(SwingConstants.CENTER);
		titre.setVerticalAlignment(SwingConstants.BOTTOM);
		titre.setBackground(Color.blue);
		
		JPanel gauche = new JPanel();
		JPanel droite = new JPanel();
		droite.setBackground(OurColor.bleu2);
		gauche.setBackground(couleurSon);
		JPanel toucheDefaut = new JPanel();
		JPanel profilJoueur = new JPanel();
		
		// Paramètres sonores
		JPanel blockParamSonore = new JPanel();
		blockParamSonore.setLayout(new BorderLayout());
		JPanel paramSonore = new JPanel();
		paramSonore.setLayout(new GridLayout(3,2));
		JPanel paramSonoreSlider = new JPanel();
		JPanel paramSonoreSliderTxt = new JPanel();
		paramSonoreSlider.setLayout(new BoxLayout(paramSonoreSlider, BoxLayout.Y_AXIS));
		paramSonoreSliderTxt.setLayout(new BoxLayout(paramSonoreSliderTxt, BoxLayout.Y_AXIS));
		JLabel paramSonoreTxt = new JLabel("Paramètres Sonores");
		paramSonoreTxt.setHorizontalAlignment(JLabel.CENTER);
		paramSonoreTxt.setVerticalAlignment(JLabel.NORTH);
		paramSonoreTxt.setFont(OurFont.sousTitre);
		blockParamSonore.add(paramSonoreTxt,BorderLayout.NORTH);
		
		Dimension dim = new Dimension(120,37);
		int maxPas = 3;
		int minPas = 1;
		int min = 0;
		int max = 10;
		int initVal = 5;
		SliderSonore musiqueFondSlider = new SliderSonore(min, max, dim, minPas, maxPas, initVal,couleurSon,Main.getMusiqueFond(),TYPESON.BACKGROUND);
		SliderSonore bruitageSlider = new SliderSonore(min, max, dim, minPas, maxPas, initVal,couleurSon,Main.getMusiqueFond(),TYPESON.BRUITAGE);
		SliderSonore sonGlobalSlider = new SliderSonore(min, max, dim, minPas, maxPas, initVal,couleurSon,Main.getMusiqueFond(),TYPESON.GLOBAL);
		
		//paramSonoreSlider.add(musiqueFondSlider.getPanel());
		//paramSonoreSlider.add(bruitageSlider.getPanel());
		//paramSonoreSlider.add(sonGlobalSlider.getPanel());		
		
		JLabel musiqueFondSliderTxt = new JLabel("Musique de fond : ");
		JLabel bruitageSliderTxt = new JLabel("Bruitages : ");
		JLabel sonGlobalSliderTxt = new JLabel("Son global : ");
		paramSonore.add(musiqueFondSliderTxt);
		paramSonore.add(musiqueFondSlider.getPanel());
		paramSonore.add(bruitageSliderTxt);
		paramSonore.add(bruitageSlider.getPanel());
		paramSonore.add(sonGlobalSliderTxt);
		paramSonore.add(sonGlobalSlider.getPanel());
		paramSonore.setOpaque(false);
		
		//paramSonoreSliderTxt.add(musiqueFondSliderTxt);
		//paramSonoreSliderTxt.add(bruitageSliderTxt);
		//paramSonoreSliderTxt.add(sonGlobalSliderTxt);
		Border bordureBlock = BorderFactory.createLoweredBevelBorder();
		
		Border bordureTitreSonBlock = BorderFactory.createTitledBorder(bordureBlock, "Votre profil", TitledBorder.LEFT, TitledBorder.TOP, OurFont.sousTitre, Color.black);
		gauche.setBorder(bordureTitreSonBlock);
		blockParamSonore.add(paramSonore, BorderLayout.CENTER);
		blockParamSonore.setBackground(couleurSon);
		//blockParamSonore.add(paramSonoreSliderTxt,BorderLayout.WEST);
		//blockParamSonore.add(paramSonoreSlider,BorderLayout.CENTER);
		gauche.add(blockParamSonore);
		
		droite.setLayout(new BorderLayout());
		Border bordureTitreAffBlock = BorderFactory.createTitledBorder(bordureBlock, "Affichage", TitledBorder.LEFT, TitledBorder.TOP, OurFont.sousTitre, Color.black);
		droite.setBorder(bordureTitreAffBlock);
		
		//JPanel panelNomJoueur = new JPanel();
		//JTextField nomJoueur = new JTextField(25);
		//nomJoueur.setText(name);
		//panelNomJoueur.add(nomJoueur);
		//panelNomJoueur.setSize(WIDTH/3, 10);
		//panelNomJoueur.setOpaque(false);
		//droite.add(panelNomJoueur);
		
		//bQuitter.setSize(bQuitter.getWidth(), bQuitter.getWidth());
		
		JPanel nord = new JPanel();
		nord.setBackground(OurColor.beige);
		nord.setLayout(new BorderLayout());
		nord.add(titre, BorderLayout.CENTER);
		nord.add(bQuitter, BorderLayout.LINE_END);	
		this.add(nord, BorderLayout.NORTH);
		this.add(gauche, BorderLayout.WEST);
		this.add(droite, BorderLayout.EAST);
		//JTextField nomJoueur = new JTextField(25);

		
	}
	
	public class ActionQuitter implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Quitter");
			Main.setState(STATE.MENU);
		}
	}
	
	public class ActionClear implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Réinitialiser");
		}
	}
	

}

package gameWindow;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;

import sound.Son;

public class Main {
	
	public enum STATE{
		MENU,
		GAME,
		OPTION,
		CHARGE,
		PAUSE,
		SAC,
		MORT,
		GAGNE,
		DIALOGUE
	};
	
	public static STATE state;//je l'ai passé en public pr tests
	
	// Taille de la fenêtre
	final private static int WIDTH = 1280;
	final private static int HEIGHT = 800;
		
	private static JFrame window = new JFrame();
	
	private static Son musique_de_fond = new Son("musique/musique_de_fond.wav",true);
	private static int bruitageVolume = 75;
	
	static MenuDemarrerPanel menu = new MenuDemarrerPanel();
	static GamePanel game;
	static ChargerPanel charge;
	static OptionsPanel option = new OptionsPanel();
	static PausePanel pause;
	static MortPanel mort = new MortPanel();
	static GagnerPanel gagne = new GagnerPanel();
	static Dialogue_Box dialogue;
	static InventairePanel inventaire;
	static JPanel jeuEnsemble = new JPanel();
	static SacPanel sac;
	
	public static Son getMusiqueFond() {
		return musique_de_fond;
	}
	
	
	public static int getVolumeBruitage() {
		return bruitageVolume;
	}
	
	public static STATE getState() {
		return state;
	}
	
	public static JFrame getFenetre() {
		return window;
	}
	
	public static void setState(STATE vstate) {
		state = vstate;
		window.getContentPane().removeAll();
		//charge.setEnabled(false);
		//option.setEnabled(false);
		//menu.setEnabled(false);
		//dialogue.setEnabled(false);//pas sur
		
		/*if (game != null) {
			jeuEnsemble.setEnabled(false);
			mort.setEnabled(false);
			gagne.setEnabled(false);
			game.setEnabled(false);
		}*//*
		if (pause != null) {
			pause.setEnabled(false);
		}
		if (sac != null) {
			sac.setEnabled(false);
		}*/
		window.repaint();
		window.revalidate();
		switch (state) {
		case MENU:
			System.out.println("menu");
			//game = null;
			menu.setEnabled(true);
			window.getContentPane().add(menu);
			charge = new ChargerPanel(); // pour que si une nouvelle 
			// sauvegarde a été créé depuis le lancement du jeu elle 
			// soit bien disponible dans ce menu
			window.getContentPane().remove(jeuEnsemble);
			break;
		case GAME:
			System.out.println("game");
			game.pauseTermine();
			game.regarderSacTermine();
			game.setEnabled(true);
			jeuEnsemble.removeAll();
			jeuEnsemble.setLayout(new BorderLayout());
			jeuEnsemble.add(game,BorderLayout.EAST);
			jeuEnsemble.add(inventaire,BorderLayout.CENTER);
			jeuEnsemble.setEnabled(true);
			window.getContentPane().add(jeuEnsemble);
			//game.startGameThread();
			game.requestFocus();

			//window.pack();
			break;
		case PAUSE:
			window.getContentPane().add(pause);
			break;
		case SAC:
			sac = new SacPanel(game.getPlayer());
			window.getContentPane().add(sac);
			break;
		case OPTION:
			option.setEnabled(true);
			window.getContentPane().add(option);
			break;
		case CHARGE:
			System.out.println("charger");
			charge.setEnabled(true);
			window.getContentPane().add(charge);
			break;
		case MORT:
			System.out.println("mort");
			mort.setEnabled(true);
			//window.getContentPane().remove(game);
			//window.getContentPane().remove(jeuEnsemble);
			//System.out.println("nb composant" +window.getContentPane().getComponentCount());
			window.getContentPane().add(mort);

			//System.out.println("nb composant" +window.getContentPane().getComponentCount());
			break;
		case GAGNE:
			System.out.println("gagné");
			gagne.setEnabled(true);
			window.getContentPane().add(gagne);
			break;
		case DIALOGUE:
			System.out.println("dialogue");
			dialogue.setEnabled(true);
			window.getContentPane().add(dialogue);
			break;
		}
		window.setVisible(true);
	}
	
	public static void setState(STATE vstate, int numSauvegarde) {
		game = new GamePanel(numSauvegarde);
		
		inventaire = new InventairePanel(game);
		inventaire.setFocusable(false);
		pause = new PausePanel(game.getSauvegarde(), game.getKeyListener());
		sac = new SacPanel(game.getPlayer());
		setState(vstate);
	}
	
	public static void setVolumeBruitage(int vol) {
		bruitageVolume = vol;
	}
	
	public static void mettreAJourOrXp() {
		inventaire.mettreAJourOrXp();
		game.requestFocus();
		window.repaint();
		window.revalidate();
	}
	
	public static void mettreAJourListeObjets() {
		inventaire.mettreAJourListeObjets();
		game.requestFocus();
		window.repaint();
		window.revalidate();
	}
	
	

	public static void main(String[] args) {
		// mise en place de la fenêtre
		Image icon = Toolkit.getDefaultToolkit().getImage("logos/7clues.jpg");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setResizable(false);
		window.setTitle("7Clues");
		window.setIconImage(icon);
		window.setSize(WIDTH, HEIGHT);
		window.setLocationRelativeTo(null);
		// Démarrage du jeu
		state = STATE.MENU;
		Main.setState(state);
			
	}
}

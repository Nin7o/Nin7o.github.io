package gameWindow;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import gameWindow.Main.STATE;
import inputs.OurKeyListener;
import loadsave.Sauvegarde;

public class PausePanel extends JPanel {
	
	// Taille de la fenêtre
		final protected static int WIDTH = 1280;
		final protected static int HEIGHT = 800;
		
		final protected static Color couleurFond = OurColor.beige;
		
	

	private Sauvegarde sauvegarde;
	final private JButton bRetour = new Bouton("Retour au jeu", new ActionRetour());
	final private JButton bSauvegarder = new Bouton("Sauvegarder", new ActionSauvegarder());
	final private JButton bSauvegarderEtQuitter = new Bouton("Sauvegarder et Quitter", new ActionQuitter());
	
	public PausePanel(Sauvegarde sauvegarde, OurKeyListener keyH) {
		
		this.sauvegarde = sauvegarde;
		
		// panel
		this.setLayout(new BorderLayout());
		this.setBackground(OurColor.beige);
		JLabel titre = new JLabel("Pause");
		titre.setFont(OurFont.titre);
		titre.setHorizontalAlignment(SwingConstants.CENTER);
		titre.setVerticalAlignment(SwingConstants.BOTTOM);
		titre.setBackground(Color.blue);
		
		JPanel centre = new JPanel();
		centre.setBackground(OurColor.bleu2);
		centre.add(bRetour);
		centre.add(bSauvegarder);
		centre.add(bSauvegarderEtQuitter);
		
		JPanel nord = new JPanel();
		nord.setBackground(couleurFond);
		nord.setLayout(new BorderLayout());
		nord.add(titre, BorderLayout.CENTER);
		this.add(nord, BorderLayout.NORTH);
		this.add(centre, BorderLayout.CENTER);
		
		//this.setLocation(300 + (int) WIDTH/4, 100 + (int) HEIGHT/10);
		//this.setSize((int) WIDTH/2,(int) HEIGHT*9/10);
	}
	
	public class ActionRetour implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Retour au jeu");
			Main.setState(STATE.GAME);
		}
	}
	
	public class ActionQuitter implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Quitter");
			sauvegarde.sauvegarder();
			Main.setState(STATE.MENU);
		}
	}
	
	public class ActionSauvegarder implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Sauvegarder");
			sauvegarde.sauvegarder();
			Main.setState(STATE.GAME);
		}
	}

}

package gameWindow;

import java.awt.BorderLayout;
import java.awt.Font;
import javax.swing.SwingConstants;

import entite.Joueur;
import entite.Objet;

import javax.swing.JPanel;
import javax.swing.JLabel;

public class CasePanelPourSac extends JPanel {
	public CasePanelPourSac (Objet objet, Joueur joueur) {
		super();
		this.setLayout(new BorderLayout());
		CaseLabel imageLabel = new CaseLabel(objet, joueur);
		
		this.add(imageLabel,BorderLayout.CENTER);
		if (objet != null) {
			JLabel texteLabel = new JLabel();
			
			// nom de l'objet et quantité
			texteLabel.setText(objet.getNom().toString() + " x" + objet.getQuantite());
			texteLabel.setVerticalTextPosition(SwingConstants.BOTTOM);
			texteLabel.setHorizontalTextPosition(SwingConstants.CENTER);
			
			// police du texte
			Font font = new Font(Font.SERIF,Font.BOLD,12);
			texteLabel.setFont(font);
			
			// position JLabel
			texteLabel.setHorizontalAlignment(SwingConstants.CENTER);
			texteLabel.setBackground(OurColor.beigeFonce);
			texteLabel.setOpaque(true);
			
			this.add(texteLabel,BorderLayout.AFTER_LAST_LINE);
		}
		
		
	}
}

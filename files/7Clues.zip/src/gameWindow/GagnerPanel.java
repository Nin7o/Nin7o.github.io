package gameWindow;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import gameWindow.Main.STATE;

public class GagnerPanel extends JPanel {
	final private JButton bRetourMenu = new Bouton(" Retour au menu principal ", new ActionRetourMenu());
	
	public GagnerPanel() {
		this.setLayout(new BorderLayout());
		JPanel textePanel = new JPanel();
		textePanel.setLayout(new BorderLayout());
		JLabel titre = new JLabel("Vous avez gagné ! Bravo !");
		titre.setFont(OurFont.titre);
		titre.setHorizontalAlignment(SwingConstants.CENTER);
		textePanel.add(titre,BorderLayout.NORTH);
		JLabel texte = new JLabel("Vous venez de trouver l'arme du crime, votre enquête est donc terminé !");
		texte.setFont(OurFont.sousTitre);
		texte.setHorizontalAlignment(SwingConstants.CENTER);
		textePanel.add(texte,BorderLayout.SOUTH);
		
		this.add(textePanel,BorderLayout.NORTH);
		
		JLabel image = new JLabel();
		image.setHorizontalAlignment(SwingConstants.CENTER);
		Icon icon = new ImageIcon("images/feu_artifice.png");
		image.setIcon(icon);
		JPanel bouton = new JPanel();
		bouton.add(bRetourMenu);
		this.add(image,BorderLayout.CENTER);
		this.add(bouton,BorderLayout.SOUTH);
		System.out.println("mort");
	}
	
	public class ActionRetourMenu implements ActionListener {
		public void actionPerformed(ActionEvent evt) {
			System.out.println("Retour menu");
			Main.setState(STATE.MENU);
		}
	}
}

package gameWindow;

import java.awt.Font;

public class OurFont extends Font {
	
	public static final Font titre = new Font("arial",Font.BOLD,50);
	public static final Font sousTitre = new Font("arial",Font.BOLD,30);
	//public static final Font classique = new Font()
	
	public OurFont(String name, int style, int size) {
		super(name, style, size);
		// TODO Auto-generated constructor stub
	}

}

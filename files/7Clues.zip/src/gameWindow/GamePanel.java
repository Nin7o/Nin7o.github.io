package gameWindow;

import entite.*;
import gameWindow.Main.STATE;
import inputs.*;
import loadsave.Sauvegarde;
import map.*;

import java.io.*;
import java.util.List;
import java.util.Scanner;

import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;


public class GamePanel extends JPanel implements Runnable {

	private static final long serialVersionUID = 1L;

	// Tile size
	static final int originalTileSize = 16; // SizexSize
	static final int scale = 3;
	public static final int tileSize = originalTileSize * scale;

	// TileMap size
	public static final int maxScreenColumn = 24;//16;
	public static final int maxScreenRow = 16;//12;

	// Screen size
	private final int screenWidth = tileSize * maxScreenColumn;
	private final int screenHeight = tileSize * maxScreenRow;



	// KeyHandler
	private OurKeyListener keyH = new OurKeyListener();

	// Clock
	private Thread gameThread;

	// FPS
	private final int FPS = 55;

	//public Joueur player = new Joueur(playerX, playerY, playerMap, playerName, playerSpeed, this, keyH);
	private Joueur player;
		
	
	//::= loadsave.Sauvegarde.chargerJoueur(2,this,keyH);
	
	public Collider playerCollider = new Collider(this);
	

	// carte
	
	//////////////// Ici je pense qu'il faudrait init tte les maps au debut comme ça ça scanne tout au lancement
	//////////////// et ensuite on peut switch entre les maps
	
	public final int nbTotalMaps = 3;
	public Map [] listeMaps = new Map[nbTotalMaps];
	public Walls [] listeWalls = new Walls[nbTotalMaps];
	

	
	private int currentMap = 0; // Initialisé à la map du spawn
	
	// Monstres
	private File fichierMonstres = new File("entitesInitiales/Monstres.txt");
	private String[][][] listeStringEntites = Sauvegarde.charger(fichierMonstres);
	private List<Entite>[] listeEntites = Entite.creation(listeStringEntites,this);
	
	// Objets
	private List<Entite>[] listeObjets;
	
	
	private int numSauvegarde;
	private Sauvegarde sauvegarde;

	private Boolean bpause = false;
	private Boolean bsac = false;
	private Boolean bdialogue = false;
	
	private PNJ pnjParlant;
	
	//Booléen qui sert a stopper ou non les update (pour les dialogues avec le joueur)
	private Boolean freeze = false;
	
	// Affichage xp/or possédé
	//private JLabel possede = new JLabel("pas encore initialisé");
	
	public GamePanel(int numSauvegarde) {
		
		
		this.initialiserMaps();
	
		this.setLayout(new BorderLayout());
		
		this.numSauvegarde = numSauvegarde;
		player = loadsave.Sauvegarde.chargerJoueur(numSauvegarde,this,keyH);
		listeObjets = Sauvegarde.chargerObjets(this,numSauvegarde);
		this.currentMap = player.getCurrentMap();
		
		if (numSauvegarde == 0) {
			File fichierNbSauvegardes = new File("sauvegardes/nbSauvegardes");
			try (Scanner scanner = new Scanner(fichierNbSauvegardes)) {
				this.numSauvegarde = Integer.parseInt(scanner.nextLine()) + 1;
				PrintWriter fichierNBSauvegardesEcriture = new PrintWriter("sauvegardes/nbSauvegardes");
				fichierNBSauvegardesEcriture.println(this.numSauvegarde);
				fichierNBSauvegardesEcriture.close();
				
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		this.sauvegarde = new Sauvegarde(this.numSauvegarde,player, this);
		
		this.setPreferredSize(new Dimension(screenWidth, screenHeight));
		this.setBackground(Color.pink);
		this.setDoubleBuffered(true);
		this.addKeyListener(keyH);
		this.setFocusable(true);
		this.startGameThread();

	}
	

	public static int getTileSize() {
		return tileSize;
	}

	public void startGameThread() {

		gameThread = new Thread(this);
		gameThread.start();
	}
	
	public void pauseTermine() {
		this.bpause = false;
	}
	
	
	public void regarderSacTermine() {
		this.bsac = false;
	}
	
	/*
	 * Mettre le jeu en Pause
	 */
	public void stopperLeJeu() {
		this.freeze = true;
	}
	
	public void activerDialogue(PNJ pnj) {
		this.bdialogue = true;
		this.pnjParlant = pnj;
	}
	
	public boolean isDialogue() {
		return this.bdialogue;
	}

	@Override
	public void run() {

		double drawInterval = 1000000000 / FPS;
		double delta = 0;
		long lastTime = System.nanoTime();
		long currentTime;

		long timer = 0;
		int drawCount = 0;

		while (gameThread != null) {
			
			
			
			//System.out.println(bpause);
			// Pause
			if (keyH.isKeyTyped(KeyEvent.VK_P)) {
				bpause = !bpause;
				if (bpause) {
					System.out.println("pauuuuuse");
					/*if (first) {
						this.player.addObjet(NomObjet.BOUCLIER, 1);
						first = false;
						second = true;
					} else if (second) {
						this.player.addObjet(NomObjet.ECHELLE, 1);
						second = false;
					}*/
					

					this.getPlayer().addRichesse(1, 1);
					Main.setState(STATE.PAUSE);
				} else {
					bpause = false;
					System.out.println("gaaaaaaame");
					Main.setState(STATE.GAME);
					
				}
				keyH.traiterTyped(KeyEvent.VK_P);
				
			}
			
			if (keyH.isKeyTyped(KeyEvent.VK_I)) {
				bsac = !bsac;
				if (bsac) {
					System.out.println("inventaaaaaaaire");
					/**if (first) {
						this.player.removeObjet(NomObjet.EPEE, 1);
						first = false;
						second = true;
					} else if (second) {
						this.player.addObjet(NomObjet.ECHELLE, 1);
						second = false;
					}*/
					
					Main.setState(STATE.SAC);
				} else {
					bsac = false;
					System.out.println("gaaaaaaame");
					Main.setState(STATE.GAME);
					
				}
				keyH.traiterTyped(KeyEvent.VK_I);
				
			}
			
			if (freeze) {
				if (keyH.isKeyTyped(KeyEvent.VK_ENTER)) {
					keyH.traiterTyped(KeyEvent.VK_ENTER);
					freeze = false;
					this.bdialogue = false;
					this.pnjParlant.desactiverDialogueActif();
					
				}
			}
			
			if (!bpause && !bsac && !freeze) {
				currentTime = System.nanoTime();

				delta += (currentTime - lastTime) / drawInterval;

				timer += (currentTime - lastTime);

				lastTime = currentTime;

				if (delta >= 10) {

					repaint();

					delta--;

					drawCount++;
					
					

				}

				if (timer >= 1000000000) {
					timer = 0;
					drawCount = 0;

				}		
			}
				

			//player.sauvegarderJoueur(this.numSauvegarde);

			
		}

	}
	public List<Entite> getListeEntites(int map){
		return listeEntites[map];
	}
	
	public List<Entite> getListeObjets(int map){
		return listeObjets[map];
	}
	
	public void removeListeObjets(int map, Entite entite) {

		System.out.println("taille : " + this.listeObjets[map].size());
		
		this.listeObjets[map].remove(entite);
		System.out.println("removelisteobjet");
		System.out.println("taille : " + this.listeObjets[map].size());
	}
	
	public void addListeObjets(int map, Entite entite) {
		System.out.println(this.listeObjets[map].size());
		this.listeObjets[map].add(entite);
		System.out.println("addlisteObjet");

		System.out.println(this.listeObjets[map].size());
	}
	
	public void removeListeEntites(int map, Entite entite) {
		//System.out.println(this.listeEntites[map].remove(entite));
		this.listeEntites[map].remove(entite);
	}
	
	public int getNbMap() {
		return this.nbTotalMaps;
	}

	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) g;
		
		if (!freeze) {
			//System.out.println("curentmap :" + this.currentMap);
			listeMaps[currentMap].draw(g2);
			
			for (Entite objet : listeObjets[this.currentMap]) {
				objet.draw(g2);
			}
			
			player.update();
			player.draw(g2);
			
			for (Entite entite : listeEntites[this.currentMap]) {
				entite.update();
				entite.draw(g2);
			}
			
		}
	
		g2.dispose();

	}

	

	public Joueur getPlayer() {
		return this.player;
	}
	
	public int getNumSauvegarde() {
		return this.numSauvegarde;
	}
	
	public Sauvegarde getSauvegarde() {
		return this.sauvegarde;
	}
	
	public OurKeyListener getKeyListener() {
		return this.keyH;
	}
	
	public Map getCurrentMap() {
		return listeMaps[currentMap];
	}
	
	public Walls getCurrentWalls() {
		return listeWalls[currentMap];
	}
	
	public void setCurrentMap(int nbMap) {
		this.currentMap = nbMap;
	}
	
	
	private void initialiserMaps() {
	
		this.listeMaps[0] = new Map(this, 0);
		this.listeWalls[0] =  new Walls(this, 0);
		
		this.listeMaps[1] = new Map(this, 1);
		this.listeWalls[1] = new Walls(this, 1);
		
		this.listeMaps[2] = new Map(this, 2);
		this.listeWalls[2] = new Walls(this,2);
	}

	
}

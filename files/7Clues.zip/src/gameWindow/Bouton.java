package gameWindow;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;

public class Bouton extends JButton {
	
	final private static Color COULEURBTN = Color.GRAY; // couleur par défaut pour les boutons
	final private static Font FONTBTN = new Font("arial",Font.ITALIC,20); // font par défaut pour les boutons
	
	public Bouton(String name, ActionListener action, Color couleurBouton, Font fntBouton) {
		super(name);
		this.setBackground(couleurBouton);
		this.setFont(fntBouton);
		this.setBorder(BorderFactory.createRaisedBevelBorder()); // ressemble aux boutons de minecraft
		this.addActionListener(action);
	}
	
	public Bouton(String name, ActionListener action) {
		this(name, action, COULEURBTN, FONTBTN);
	}

}

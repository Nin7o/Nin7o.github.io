package gameWindow;

import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;

import entite.Joueur;
import entite.Objet;

public class CaseLabel extends JLabel {
	
	public CaseLabel() {
		super();
		this.setOpaque(true);
		this.setBackground(OurColor.beige);
		this.setHorizontalAlignment(SwingConstants.CENTER);
		this.setVerticalAlignment(SwingConstants.CENTER);
		
		// bordure 
		Border bordure = BorderFactory.createLoweredBevelBorder();
		this.setBorder(bordure);
		
	}
	
	/**
	 * mettre null à la place de objet si case vide
	 * @param objet
	 * @param joueur TODO
	 */
	public CaseLabel(Objet objet, Joueur joueur) {
		this();
		
		if (objet == null) {
			// specifique au case vide
			this.setText("Vide");
		} else {
			
			// icone
			this.setIcon(objet.getImage());
			this.setText(" x" + objet.getQuantite());
			this.setVerticalTextPosition(SwingConstants.BOTTOM);
			
			
			// interraction
			this.addMouseListener(new MouseListener() {

				@Override
				public void mouseClicked(MouseEvent e) {
					// TODO Auto-generated method stub
					System.out.println("cliquer");
					joueur.changerObjetEnMain(objet);
					
					// Si dans petit inventaire de gauche -> la sélectionner dans la main
					
				}

				@Override
				public void mousePressed(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}

				@Override
				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
			});
			
			if (joueur.getObjetEnMain()!=null && joueur.getObjetEnMain().getNom() == objet.getNom()) {
				// bordure rouge
				Border bordure = BorderFactory.createLineBorder(Color.red,5,true);
				this.setBorder(bordure);
			}
		}
		
		
		
	}
}

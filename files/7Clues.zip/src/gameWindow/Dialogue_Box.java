package gameWindow;

import java.awt.Graphics2D;

import javax.swing.JPanel;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;

public class Dialogue_Box extends JPanel {

	private static final long serialVersionUID = 1L;
	// Taille de la fenêtre
	final protected static int WIDTH = 1280;
	final protected static int HEIGHT = 800;
	
	private String message;
	//private String currentMessage;
	
	/* Pour le cadre derrière le dialogue */
	private int x;
	private int y;
	private int width;
	private int height;
	
	/* Pour le texte dans le cadre */
	private final int ytextinit;
	private final int xtext;
	private int ytext;
	
	
	/**public Dialogue_Box(String[] messages, int numMessage) {
		
		this.messages = messages;
		this.x = GamePanel.tileSize*2;
		this.y = GamePanel.tileSize/2;
		this.ytextinit = this.y + GamePanel.tileSize*4/5;
		this.xtext = this.x + GamePanel.tileSize/2;
		this.ytext = this.y + GamePanel.tileSize*4/5;
		this.width = OurPanel.WIDTH - (GamePanel.tileSize*8);
		this.height = GamePanel.tileSize*3;
		
	}*/
	
	public Dialogue_Box(String message) {
		this.message = message;
		this.x = GamePanel.tileSize*2;
		this.y = GamePanel.tileSize/2;
		this.ytextinit = this.y + GamePanel.tileSize*4/5;
		this.xtext = this.x + GamePanel.tileSize/2;
		this.ytext = this.y + GamePanel.tileSize*4/5;
		this.width = WIDTH - (GamePanel.tileSize*8);
		this.height = GamePanel.tileSize*3;
	}
	
	public void setTexte(String message) {
		this.message = message;
	}
	
	public void draw(Graphics2D g2) {
		this.ytext = this.ytextinit;
		
		drawSubWindow(x, y, width, height, g2);
		g2.setFont(g2.getFont().deriveFont(Font.PLAIN, 28F));
		
		for (String line : this.message.split("%")) {
			g2.drawString(line, xtext, ytext);
			ytext += 40;
		}
		
	}
	
	
	public void drawSubWindow(int x, int y, int width, int height, Graphics2D g2) {
		
		System.out.printf("in sub window \n");
		Color c = new Color(0,0,0,210);
		g2.setColor(c);
		g2.fillRoundRect(x, y, width, height, 35, 35);

		g2.setColor(Color.white);
		g2.setStroke(new BasicStroke(5));
		g2.drawRoundRect(x+5, y+5, width-10, height-10, 25, 25);

		
	}

}

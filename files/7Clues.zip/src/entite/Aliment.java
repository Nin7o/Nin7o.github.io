package entite;
import gameWindow.GamePanel;

public class Aliment extends Objet {
	
	public enum TypeAliment{
		 GATEAU(10),
		 SALADE(1), 
		 TOMATE(4),
		 PIZZA(60),
		 PAIN(50),
		 POTIONMYSTERE(-20),
		 DONUTS(20),
		 POTIONMYSTEREBLEU(0,2);
			

		  private final int calories;
		  private final int puissance;

		  private TypeAliment(int calories) {
		    this(calories,0);
		  }
		  
		  private TypeAliment(int calories, int puissance) {
			    this.calories = calories;
			    this.puissance = puissance;
			  }

		  public int getCalories() {
		    return this.calories;
		  }
		  
		  public int getPuissance() {
			  return this.puissance;
		  }
	}
	
	private TypeAliment typeAliment;
	
	public Aliment(NomObjet nom, int nb, String lienImage, GamePanel gp) {
		super(nom, TypeObjet.ALIMENT, nb, lienImage,gp);
		this.typeAliment = TypeAliment.valueOf(nom.toString());
	}
	
	public Aliment(String nom, int nb) {
		super(nom,TypeObjet.ALIMENT,nb);
		this.typeAliment = TypeAliment.valueOf(nom);
	}
	
	public Aliment(NomObjet nom, int nb) {
		super(nom,TypeObjet.ALIMENT,nb);
		this.typeAliment = TypeAliment.valueOf(nom.toString());
	}
	
	public Aliment(NomObjet nom, int nb, String lienImage, int x, int y, int numMap, boolean estInvisible, boolean estSupprimable, GamePanel gp) {
		super(nom, TypeObjet.ALIMENT, nb, lienImage, x, y, numMap, estInvisible, estSupprimable,gp);
		this.typeAliment = TypeAliment.valueOf(nom.toString());
	}
	
	@Override
	public void utiliser(Joueur joueur) {
		super.utiliser(joueur);
		joueur.gagnerPV(this.typeAliment.calories);
		joueur.addPuissance(this.typeAliment.puissance,this.typeAliment.puissance,this.typeAliment.puissance);
		joueur.removeObjet(this.getNom(), 1);
	}

}
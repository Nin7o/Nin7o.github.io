package entite;

import gameWindow.GamePanel;

public class Rat extends MonstreAvecAttaqueContact {
	

	public Rat(int x, int y, int numeroMap, String nom, int speed, int hp, int hpMax, GamePanel gp) {
		super(x, y, numeroMap, nom, speed, hp, hpMax, gp);
	}
	
	@Override
	protected void definitivementMort() {
		
		if (!this.don) {
			super.definitivementMort();
			this.gp.getPlayer().augmenterNbRatsMorts();
		}
		
	}
	

	@Override
	public String getClasse() {
		return "Rat";
	}
	

}

package entite;
import java.io.File;
import java.util.Random;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import gameWindow.GamePanel;
import sound.Son;

public class Fleche extends EntiteMobile {
	private float directionx;
	private float directiony;
	private int xCible;
	private int yCible;
	private Boolean explosion;
	protected int compteurExplosion;
	//protected Son explo = new Son("musique/fireball.wav"); //bruitage
	Random random = new Random(x * y);

	public Fleche(int x, int y, int numeroMap, String nom, int speed, int hp, GamePanel gp) {
		super(x, y, numeroMap, nom, speed, gp, "musique/player_dead.wav");
		this.xCible = gp.getPlayer().getX();
		this.yCible = gp.getPlayer().getY();
		this.directionx = (xCible - x);
		this.directiony = (yCible - y);
		float ratio = 8 / (Math.abs(directionx) + Math.abs(directiony));
		directionx = directionx * ratio;
		directiony = directiony * ratio;
		explosion = false;
	}

	public void deplacement() {
		collisionON = false;
		gp.playerCollider.checkCollision(this);
		if (!collisionON) {
			this.x = this.x + (int) directionx;
			this.y = this.y + (int) directiony;
			if (Math.abs(x - gp.getPlayer().getX()) < 100  && Math.abs(y - gp.getPlayer().getY()) < 100
					&& compteurExplosion == 0) {
				explosion = true;
				
				//explo.setVolume(2);
				//explo.activerSon();
				gp.getPlayer().takeDamage(10);
				//int speedBase = gp.getPlayer().speed;
				//gp.getPlayer().setSpeed((int) directionx * 10);
				//gp.getPlayer().deplacerDroite();
				//gp.getPlayer().setSpeed((int) directiony * 10);
				//gp.getPlayer().deplacerBas();
				//gp.getPlayer().setSpeed(speedBase);
			}
		}
		else if (compteurExplosion < 1){
			//Son explo = new Son("musique/fireball_2.wav", !explosion);
			//this.explo.activerSon();
			explosion = true;
			
		}
	}

	@Override
	public BufferedImage getTexture() {
		if (!explosion) {
			try {
				return ImageIO.read(new File("playerSprite/fireball.png"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			compteurExplosion++;
			try {
				return ImageIO.read(new File("playerSprite/Explosion/" + Math.round(compteurExplosion / 10) + ".png"));
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public void update() {
		this.deplacement();
	}

	@Override
	public String getClasse() {
		return "Joueur";
	}

	@Override
	public void interaction() {
		// TODO Auto-generated method stub
		
	}

}

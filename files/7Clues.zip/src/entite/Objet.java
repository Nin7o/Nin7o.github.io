package entite;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import gameWindow.GamePanel;

public class Objet extends EntiteImmobile {
	
	public enum NomObjet {
		ECHELLE,
		TORCHE,
		LOUPE,
		EPEE,
		BOUCLIER,
		CLEMAISON,
		COFFRE,
		GATEAU,
		SALADE,
		PIZZA,
		DONUTS,
		TOMATE,
		PAIN,
		ARMEDUCRIME,
		POTIONMYSTERE,
		POTIONMYSTEREBLEU,
		CLEMAGIQUE
	}
	
	public enum TypeObjet {
		ARME,
		POTION,
		OUTILS,
		CLE,
		COFFRE,
		ALIMENT,
		ENQUETE
	}
	
	private int quantite;
	private NomObjet nomObjet;
	private ImageIcon image;
	private BufferedImage imageBuff;
	private Boolean estInvisible;
	private TypeObjet type;
	private List<Objet> objetsContenus;
	
	public Objet(NomObjet nom, TypeObjet type, int nb, String lienImage, GamePanel gp) {
		super(nom.name(),gp,false);
		this.objetsContenus = new ArrayList<Objet>();
		this.quantite = nb;
		this.type = type;
		this.nomObjet = nom;
		this.estInvisible = false;
		this.estSupprimable = true;
		try {
			System.out.println(lienImage);
			this.imageBuff = ImageIO.read(new File(lienImage));
			float scale = (float) 32/this.imageBuff.getHeight();
			int width = (int) (scale*this.imageBuff.getWidth());
			int height = (int) (scale*this.imageBuff.getHeight());
			this.image = new ImageIcon(this.imageBuff.getScaledInstance(width, height, Image.SCALE_DEFAULT));
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/*
	 * Constructeur pour les objets qui seront placés sur la map en position x et y
	 */
	public Objet(NomObjet nom, TypeObjet type, int nb, String lienImage, int x, int y, int numMap, boolean estInvisible, boolean estSupprimable, GamePanel gp) {
		this(nom,type,nb,lienImage,gp);
		this.x = x;
		this.y = y;
		this.numeroMap = numMap;
		this.estInvisible = estInvisible;
		this.estSupprimable = estSupprimable;
	}
	
	/*
	 * Constructeur pour les objets de l'inventaire
	 */
	public Objet(NomObjet nom, TypeObjet type, int nb) {
		this(nom, type, nb, "images/"+ nom.toString().toLowerCase() +".png",null);
		//System.out.println("Objet ajouté à l'inventaire : " + this.quantite + " " + this.nomObjet.name());
	}
	
	public Objet(String nom, TypeObjet type, int nb) {
		this(NomObjet.valueOf(nom), type, nb, "images/"+ nom.toLowerCase() +".png",null);
		//System.out.println("Objet ajouté à l'inventaire : " + this.quantite + " " + this.nomObjet.name());
	}
	
	@Override
	public String ligneASauvegarder() {
		String ligne = this.nom + " " + this.type.toString() + " " + this.quantite + " " + this.x + " "+ this.y + " " + this.numeroMap + " " + this.estInvisible + " " + this.estSupprimable;
		for (Entite objet :this.objetsContenus) {
			System.out.println(objet.nom);
			ligne = ligne + ":" + objet.ligneASauvegarder();
		}
		return (ligne);
	}
	
	public void interaction() {
		if (!this.wasInteractedWith) {
			super.interaction();
			
			if (this.estSupprimable) {
				
				this.gp.getPlayer().addObjet(this);
				
				
				this.gp.removeListeObjets(this.numeroMap, this);
			} else {
				if (this.type.equals(TypeObjet.COFFRE)) {
					
					for (Objet obj : this.objetsContenus) {
						this.gp.getPlayer().addObjet(obj);
					}
				}
				try {
					this.imageBuff = ImageIO.read(new File("images/"+ this.nom.toLowerCase() +"1.png"));
					this.wasInteractedWith = true;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
		}
		
	}
	
	public void draw(Graphics2D g2) {
		if (!this.estInvisible) {
			g2.drawImage(this.imageBuff, this.x, this.y, GamePanel.getTileSize(), GamePanel.getTileSize(), null);
		}
		
	}
	/* Permet d'utiliser l'objet (touche C), override dans class Aliment*/
	public void utiliser(Joueur joueur) {
		
	}
	
	/* Obtenir l'image correspondant à l'objet */
	public ImageIcon getImage() {
		return this.image;
	}
	
	public NomObjet getNom() {
		return this.nomObjet;
	}
	
	public TypeObjet getType() {
		return this.type;
	}
	
	/* Obtenir la quantité de l'objet disponible*/
	public int getQuantite() {
		return this.quantite;
	}
	
	
	/**
	 * Augmente d'un la quantité correspondante à l'objet
	 */
	public void augmenterQuantite() {
		this.quantite++;
	}
	
	/**
	 * Augmente de la valeur de nb la quantité correspondante à l'objet
	 * @param nb
	 */
	public void augmenterQuantite(int nb) {
		this.quantite += nb;
	}
	
	/**
	 * Diminue de la valeur de nb la quantité correspondante à l'objet
	 * @param nb
	 */
	public void diminuerQuantite(int nb){
		this.quantite -= nb;
	}
	
	/* Ajouter un objet dans l'autre (ex : coffre) */
	public void ajouterDedans(Objet objet) {
		this.objetsContenus.add(objet);
	}
	
	public static Objet creerObjet(NomObjet nom, TypeObjet type, int quantite) {
		switch (type) {
		case ALIMENT :
			return new Aliment(nom, quantite);
		case ARME :
			return new Arme(nom,quantite);
		default :
			return new Objet(nom, type, quantite);
		}
	}
	
	public static Objet creerObjet(String nom, TypeObjet type, int quantite) {
		return creerObjet(NomObjet.valueOf(nom), type, quantite);
	}
}

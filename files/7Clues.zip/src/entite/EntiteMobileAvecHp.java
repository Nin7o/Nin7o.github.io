package entite;

import java.awt.Color;
import java.awt.Graphics2D;

import gameWindow.GamePanel;
import gameWindow.OurColor;

abstract class EntiteMobileAvecHp extends EntiteMobile {

	protected int hp;
	protected int hpMax;
	protected int nombreAnimeAttaque;
	protected int ptAtt;
	protected int ptDef;

	public EntiteMobileAvecHp(int x, int y, int numeroMap, String nom, int vspeed, int hp, int hpMax, GamePanel gp,
			String vNomFichierSonMort, int vPtAtt, int vPtDef) {
		super(x, y, numeroMap, nom, vspeed, gp, vNomFichierSonMort);
		this.hpMax = hpMax;
		this.hp = hp;
		this.hpOrNot = true;
		this.ptAtt = vPtAtt;
		this.ptDef = vPtDef;
	}
	
	public EntiteMobileAvecHp(int x, int y, int numeroMap, String nom, int vspeed, int hp, int hpMax, GamePanel gp,
			String vNomFichierSonMort, int vPtAtt, int vPtDef, boolean armeChoisissable) {
		this(x, y, numeroMap, nom, vspeed, hp, hpMax, gp, vNomFichierSonMort, vPtAtt, vPtDef);
		this.armeChoisissable = armeChoisissable;
	}
	@Override
	/**
	 * Permet de dessiner les entités avec leur barre d'hp
	 */
	public void draw(Graphics2D g2) {
		double ratio = (hp * GamePanel.tileSize / hpMax);
		super.draw(g2);
		if (hp != hpMax && !this.isMort) {
			g2.setColor(new Color(0, 0, 0));
			g2.fillRect(x - 1, y - 21, GamePanel.tileSize + 2, 10);
			// lorsque l'entité à peu de hp, la couleur de la barre de vie est rouge, 
			// lorsquelle en a un peu plus, elle est orange
			// et lorsque elle a presque tout ses hp, elle est verte
			if (((float) hp)/hpMax > 0.7) {
				g2.setColor(OurColor.vert);
			} else if (0.3 < ((float) hp)/hpMax && ((float) hp)/hpMax < 0.7) {
				g2.setColor(OurColor.orange);
			} else {
				g2.setColor(OurColor.rouge);
			}
			if (ratio >= 0) {
				g2.fillRect(x, y - 20, (int) ratio, 8);
			}
		}
	}
	
	/**
	 * Déduit "damage" aux hp de l'objet
	 * @param damage
	 */
	public void takeDamage(int damage) {
		if (damage - this.ptDef > 0) {
			this.hp = this.hp - (damage - this.ptDef);
		}
		this.update();
		
		//System.out.println("hp, hpmax : " + this.hp + " " + this.hpMax);
		//System.out.println(this.isMort);
	}
	
	
	@Override
	public void update() {
		if (hp <= 0) {
			this.mourir();
		}
	}
	protected void attaquerPlayer() {
		if (!this.isMort && !gp.getPlayer().estMort()) {
			if (compteurAnimeAttaque == nombreImageAnimeAttaque && stunned == 0) {
				if ((orientation == "sud" && gp.getPlayer().getY() > y && gp.getPlayer().getY() - y < 50 && Math.abs(gp.getPlayer().getX() - x) < 50)
					   || (orientation == "nord" && gp.getPlayer().getY() < y && y - gp.getPlayer().getY() < 50 && Math.abs(gp.getPlayer().getX() - x) < 50)
					   || (orientation == "est" && gp.getPlayer().getX() > x && gp.getPlayer().getX() - x < 50 && Math.abs(gp.getPlayer().getY() - y) < 50)
					   || (orientation == "ouest" && gp.getPlayer().getX() < x && x - gp.getPlayer().getX() < 50 && Math.abs(gp.getPlayer().getY() - y) < 50)) {
					gp.getPlayer().takeDamage(ptAtt);
					this.isAttaquing = true;
					this.isMoving = false;
					hit();
			}
		} 
	}
}
}
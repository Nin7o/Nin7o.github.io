package entite;

import java.util.ArrayList;
import java.util.List;

import gameWindow.*;

public class Interaction {
	
	GamePanel gp;
	
	int offset = GamePanel.tileSize/2;
	
	public Interaction(GamePanel gp) {
		this.gp = gp;
	}
	
	public List<Entite> detectEntity(Entite player, String orientation, int distance, int map) {
		List<Entite> toutesLesEntitesMap = new ArrayList<Entite>();
		System.out.println(map);
		List<Entite> listeMonstres = gp.getListeEntites(map);
		List<Entite> listeObjets = gp.getListeObjets(map);
		toutesLesEntitesMap.addAll(listeMonstres);
		toutesLesEntitesMap.addAll(listeObjets);
		
		List<Entite> entitesPortees = new ArrayList<Entite>();
		
		int x1 = player.getX() + offset;
		int y1 = player.getY() + offset;
		
		for (Entite entite : toutesLesEntitesMap) {
			
			int xe = entite.getX() + offset - x1;
			int ye = entite.getY() + offset - y1;
			
			switch(orientation) {
			case "nord":
				if (ye <= xe && ye <= 0) {
					if (this.distance(entite, player) <= distance) {
						entitesPortees.add(entite);
					}
				}
				break;
			case "sud":
				if (ye >= xe && ye >= 0) {
					if (this.distance(entite, player) <= distance) {
						entitesPortees.add(entite);
					}
				}
				break;
			case "est":
				if (xe >= ye && xe >= 0) {
					if (this.distance(entite, player) <= distance) {
						entitesPortees.add(entite);
					}
				}
				break;
			case "ouest":
				if (xe <= ye && xe <= 0) {
					if (this.distance(entite, player) <= distance) {
						entitesPortees.add(entite);
					}
				}
				break;
			default:
				System.out.println("We have pb houston");
			}
		}
		return entitesPortees;
	}
	
	private int distance(Entite E1, Entite E2) {
		
		int x1 = E1.getX() + offset;
		int y1 = E1.getY() + offset;
		
		int x2 = E2.getX() + offset;
		int y2 = E2.getY() + offset;
		
		int dist =(int) Math.sqrt(Math.pow((x1 - x2), 2) + Math.pow((y1 - y2), 2));
		
		return dist;
	}
}

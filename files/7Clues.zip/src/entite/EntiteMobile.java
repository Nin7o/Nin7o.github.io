package entite;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.imageio.ImageIO;

import gameWindow.GamePanel;
import sound.Son;

abstract class EntiteMobile extends Entite {
	protected static final int ANIM_SWITCH = 10;
	protected int speed;
	protected int spritNum;
	protected int animCounter;
	protected String orientation;
	protected boolean isMoving;
	protected boolean isMort;
	protected boolean isAttaquing;
	protected boolean onOffSonMort;
	protected int nombreImageAnimeMort;
	protected int nombreImageAnimeDeplacement;
	protected String nomFichierSonMort;
	protected int nombreImageAnimeAttaque;
	protected int compteurAnimeAttaque;
	protected int stunned;
	//protected Son son_attaque = new Son("musique/sword.wav"); // bruitage attaque
	protected boolean armeChoisissable;

	public EntiteMobile(int x, int y, int numeroMap, String nom, int vspeed, GamePanel gp, String vNomFichierSonMort) {
		super(x, y, numeroMap, nom, gp);
		this.speed = vspeed;
		this.spritNum = 1;
		this.animCounter = 0;
		this.setOrientation("nord");
		this.isMoving = false;
		this.isMort = false;
		this.isAttaquing = false;
		this.nombreImageAnimeMort = 100;
		this.nombreImageAnimeDeplacement = 2;
		this.nombreImageAnimeAttaque = 35;
		this.compteurAnimeAttaque = this.nombreImageAnimeAttaque;
		//this.nomFichierSonMort = vNomFichierSonMort;
		this.onOffSonMort = false;
		this.stunned = 0;
		this.armeChoisissable = false;
	}
	
	public EntiteMobile(int x, int y, int numeroMap, String nom, int vspeed, GamePanel gp, String vNomFichierSonMort, boolean armeChoisissable) {
		this(x, y, numeroMap, nom, vspeed, gp, vNomFichierSonMort);
		this.armeChoisissable = armeChoisissable;
	}

	/**
	 * Transforme le joueur en chaine de caractères
	 * 
	 * @return chaine de character avec les coordonnées de l'entité mobile
	 */
	public String toString() {
		return "" + this.nom + ": (" + x + "," + y + ")";
	}
	
	public void stun(int duree) {
		this.stunned = duree;
	}

	public void setOrientation(String ori) {
		this.orientation = ori;
	}
	
	/*
	 * Pour déplacer l'entite mobile au bon endroit quand téléportation
	 */
	public void setCoordonnees(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	
	// Ces méthodes permettent le déplacement du personnage d'une unité dans la
	// direction demander

	public void deplacerGauche(boolean repoussage) {
		if (stunned != 0 && !repoussage) {
			stunned -= 1;
		}
		else {
		this.setOrientation("ouest");
		gp.playerCollider.checkCollision(this);
		if (!collisionON && super.x > 0) {
			super.x = super.x - this.speed;
			this.setOrientation("ouest");
		} else {
			setOrientation("est");
		}
		collisionON = false;
		}
	}

	public void deplacerDroite(boolean repoussage) {
		if (stunned != 0 && !repoussage) {
			stunned -= 1;
		}
		else {
		this.setOrientation("est");
		gp.playerCollider.checkCollision(this);
		if (!collisionON && super.x < (gameWindow.GamePanel.maxScreenColumn - 1) * gameWindow.GamePanel.tileSize) {
			super.x = super.x + this.speed;
			this.setOrientation("est");
		} else {
			setOrientation("ouest");
		}
		collisionON = false;
		}
	}

	public void deplacerBas(boolean repoussage) {
		if (stunned != 0) {
			stunned -= 1;
		}
		else {
		this.setOrientation("sud");
		gp.playerCollider.checkCollision(this);
		if (!collisionON && super.y < (gameWindow.GamePanel.maxScreenRow - 1) * gameWindow.GamePanel.tileSize) {
			super.y = super.y + this.speed;
			this.setOrientation("sud");
		} else {
			setOrientation("nord");
		}
		collisionON = false;
		}
	}

	public void deplacerHaut(boolean repoussage) {
		if (stunned != 0 && !repoussage) {
			stunned -= 1;
		}
		else {
		this.setOrientation("nord");
		gp.playerCollider.checkCollision(this);
		if (!collisionON && super.y > 0) {
			super.y = super.y - this.speed;
			this.setOrientation("nord");
		} else {
			setOrientation("sud");
		}
		collisionON = false;
		}
	}

	// anime l'entité mobile
	public void animer() {
		animCounter++;
		if (animCounter > ANIM_SWITCH) {
			if (spritNum < nombreImageAnimeDeplacement && stunned == 0) {
				spritNum++;
			} else {
				spritNum = 1;
			}
			animCounter = 0;
		}
	}

	@Override
	public BufferedImage getTexture() {
		Map<String, String> orientations = new HashMap<>();
		orientations.put("nord", "Up");
		orientations.put("est", "Right");
		orientations.put("sud", "Down");
		orientations.put("ouest", "Left");

		try {
			if (!isMoving && !isMort) {
				return ImageIO.read(new File(
						"playerSprite/" + this.getClasse() + "/standing" + orientations.get(orientation) + ".png"));

			} else if (isMort) {
				
				if (nombreImageAnimeMort <= 0) {
					this.definitivementMort();
					return ImageIO.read(new File("playerSprite/" + this.getClasse() + "/Mort/"
							+ Math.round(nombreImageAnimeMort / 10) + ".png"));
				} else {
					nombreImageAnimeMort--;
					return ImageIO.read(new File("playerSprite/" + this.getClasse() + "/Mort/"
							+ Math.round(nombreImageAnimeMort / 10) + ".png"));
				}
				

			} else {

				return ImageIO.read(new File("playerSprite/" + this.getClasse() + "/moving"
						+ orientations.get(orientation) + spritNum + ".png"));

			}
		} catch (IOException e) {
			System.out.print("Si tu lis ça c'est que le path des files est en absolu enlève le / du début");
			e.printStackTrace();
		}
		return null;
	}

	public void mourir() {
		this.isMort = true;
		if (onOffSonMort == false) {
			// ligne suivante à décommenter qd problème son sera régler
			//Son son_mort = new Son(this.nomFichierSonMort);
			//son_mort.activerSon();
		}
		this.onOffSonMort = true;
	}
	
	private void definitivementMort() {
		
	}

	public void hit() {
		compteurAnimeAttaque--;
		if (compteurAnimeAttaque < 0 || this.isMort) {
			compteurAnimeAttaque = nombreImageAnimeAttaque;
			isAttaquing = false;
		}
	}

	@Override
	/**
	 * Ajout de l'attaque dans le draw
	 */
	public void draw(Graphics2D g2) {
		super.draw(g2);
		try {
		if (stunned != 0) {
			this.deplacerVersOrientation(orientation,false);
			g2.drawImage(ImageIO.read (new File("playerSprite/stun.png")), this.getX(), this.getY()-60 + 30, GamePanel.getTileSize(), GamePanel.getTileSize(), null);
		}
		if (isAttaquing && !this.isMort && !this.armeChoisissable) {
			if (this.compteurAnimeAttaque == this.nombreImageAnimeAttaque - 2) {
				// ligne suivante à décommenter quand le son marchera
				//son_attaque = new Son("musique/sword.wav");
				//son_attaque.activerSon();
			}

				BufferedImage sprite = ImageIO.read(new File("playerSprite/" + this.getClasse() + "/Attaquing/"
						+ orientation + Math.round(compteurAnimeAttaque / 10) + ".png"));
				switch (orientation) {
				case "sud":
					g2.drawImage(sprite, this.getX(), this.getY() + 30, GamePanel.getTileSize(), GamePanel.getTileSize(), null);
					break;
				case "nord":
					g2.drawImage(sprite, this.getX(), this.getY() - 25, GamePanel.getTileSize(), GamePanel.getTileSize(), null);
					break;
				case "est":
					g2.drawImage(sprite, this.getX() + 35, this.getY(), GamePanel.getTileSize(), GamePanel.getTileSize(), null);
					break;
				case "ouest":
					g2.drawImage(sprite, this.getX() - 35, this.getY(), GamePanel.getTileSize(), GamePanel.getTileSize(), null);
					break;
				}
		} 
		if (this.isMort){
			//this.son_attaque.desactiverSon();
		}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	/**
	 * Permet de déplacer l'entité en gardant la direction indiqué par l'orientation
	 * si la valeur pour l'orientation n'est pas valide, mets isMoving à false
	 * @param orientation
	 */
	protected void deplacerVersOrientation(String orientation, boolean repoussage) {
		switch (orientation) {
			case "ouest":
				deplacerGauche(repoussage);
				break;
			case "est":
				deplacerDroite(repoussage);
				break;
			case "sud":
				deplacerBas(repoussage);
				break;
			case "nord":
				deplacerHaut(repoussage);
			default:
				isMoving = false;
				//throw new ExceptionBidon("l'orientation n'est pas valide");
		}
	}
	
	public boolean estMort() {
		return this.isMort;
	}
	

	public abstract String getClasse();
}

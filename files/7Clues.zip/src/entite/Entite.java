package entite;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import exceptions.FichierTexteException;
import gameWindow.GamePanel;

// Cette classe corresponds à toutes les entités qui vont être placées sur la map, 
// que ce soit le joueur, les pnj, les monstres ou les objets. 
// Ils ont donc tous des coordonnées x et y ainsi qu'un nom

public abstract class Entite {

	protected int x;
	protected int y;
	protected String nom;
	protected int numeroMap;
	protected GamePanel gp;
	protected boolean hpOrNot; // franchement si ça ça sert c'est du foutage de geule...
	protected boolean collisionON;
	protected boolean estSupprimable;
	protected boolean traversable;


	public abstract BufferedImage getTexture();
	
	public abstract void update();
	
	public abstract void interaction();

	public Entite(int vx, int vy, int numeroMap, String vNom, GamePanel gp) {
		this.x = vx;
		this.y = vy;
		this.nom = vNom;
		this.numeroMap = numeroMap;
		this.gp = gp;
		this.estSupprimable = false;
		this.traversable = false;
	}
	
	public Entite(int vx, int vy, int numeroMap, String vNom, GamePanel gp, boolean estSupprimable) {
		this(vx,vy,numeroMap,vNom,gp);
		this.estSupprimable = estSupprimable;
		this.traversable = false;
	}
	
	public Entite(String vNom, GamePanel gp) {
		this(0,0,0,vNom,gp);
	}
	
	public Entite(String vNom, GamePanel gp, boolean estSupprimable) {
		this(vNom,gp);
		this.estSupprimable = estSupprimable;
	}
	
	public void draw(Graphics2D g2) {
		BufferedImage sprite = this.getTexture();
		g2.drawImage(sprite, this.getX(), this.getY(), GamePanel.getTileSize(), GamePanel.getTileSize(), null);
	}

	public int getX() {
		return this.x;
	}

	public int getY() {
		return this.y;
	}
	
	public String getClasse() {
		return "Entite";
	}
	
	public void setNumMap(int numMap) {
		this.numeroMap = numMap;
	}
	
	/**
	 * 
	 * @param liste
	 * @return une liste contenant toutes les entitées
	 */
	public static List<Entite>[] creation(String[][][] liste, GamePanel gp) {
		List<Entite>[] toutesEntites = new ArrayList[liste.length];
		
		String[] entite;
		
		for (int i = 0; i < liste.length; i++) {
			toutesEntites[i] = new ArrayList<Entite>();
			for (int j = 0; j < liste[i].length; j++) {
				entite = liste[i][j];
				if (entite[0] != null) {
					toutesEntites[i].add(creerUneEntiteFromString(entite, gp));
				}
			}
		}
		return toutesEntites;
	}
	
	public String ligneASauvegarder() {
		return "";
	}
	
	/**
	 * Permet de créer une entité (Zombie, Archer ou Loup) en fournissant dans 
	 * un String[] les informations nécessaires à sa création 
	 * en format String.
	 * @param carac (x,y,numMap,nom,speed,hp)
	 * @return l'entite créé
	 */
	public static Entite creerUneEntiteFromString(String[] carac, GamePanel gp) {
		// Conversion des caractéristiques du monstre en entier
		int x = Integer.parseInt(carac[1]);
		int y = Integer.parseInt(carac[2]);
		int numMap = Integer.parseInt(carac[3]);
		int speed = Integer.parseInt(carac[5]);
		int hp = Integer.parseInt(carac[6]);
		int hpMax = Integer.parseInt(carac[7]);
		boolean interactedWith = Boolean.valueOf(carac[9]);
		int nbrDialogues = Integer.parseInt(carac[10]);
		
		// Identification et création de la créature
		switch (carac[0]) {
		case "Zombie":
			return new MonstreAvecAttaqueContact(x,y, numMap, carac[4], speed, hp, hpMax, gp);
		case "Rat":
			return new Rat(x,y, numMap, carac[4], speed, hp, hpMax, gp);
		case "Archer":
			return new MonstreAvecAttaqueADistance(x,y, numMap, carac[4], speed, hp, hpMax, gp, Integer.parseInt(carac[7]));
		case "Fantome":
			return new Fantome(x,y, numMap, carac[4], speed, hp, hpMax, gp);
		case "Environment":
			return new EntiteImmobile(x, y, numMap, carac[4], gp, carac[8], interactedWith);
		case "PNJ":
			String[] diag = new String[nbrDialogues];
			for (int j = 0; j < nbrDialogues; j++) {
				diag[j] = carac[j+11];
			}
			
			return new PNJ(x, y, numMap, carac[8], carac[4], speed, gp, nbrDialogues, diag);//nomFichierSonMort null ..comprends pas pk totues les entites mobiles peuvent mourir
			
		default:
			throw new FichierTexteException("l'initialisation des monstres a échoué, un des noms n'a pas été détecté");
		}
	}
}

package entite;

import gameWindow.GamePanel;

public class MonstreAvecAttaqueContact extends Monstre {
	
	private static final int PT_ATT_INIT = 5;
	private static final int PT_DEF_INIT = 5;

	public MonstreAvecAttaqueContact(int x, int y, int numeroMap, String nom, int speed, int hp, int hpMax, GamePanel gp) {
		super(x, y, numeroMap, nom, speed, hp, hpMax, gp, "musique/player_dead.wav", PT_ATT_INIT, PT_DEF_INIT);
		super.nombreImageAnimeMort = 199;
		//super.nombreImageAnimeAttaque = 99;
		//compteurAnimeAttaque = 99;

	}


	@Override
	public void update() {
		super.update();
		
		if (!this.isMort && stunned == 0) {
			this.deplacementAleatoire(6, 300);
			if (isAttaquing) {
				hit();
			}
			this.attaquerPlayer();
		}
		this.animer();
		
	}

	@Override
	public String getClasse() {
		return "Zombie";
	}

}
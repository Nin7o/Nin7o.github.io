package entite;
import java.util.Random;
import gameWindow.GamePanel;

abstract class Monstre extends EntiteMobileAvecHp{
	
	protected Random random = new Random(x * y);
	protected int valeurXp = 5;
	protected int valeurOr = 5;
	protected boolean don = false;

	public Monstre(int x, int y, int numeroMap, String nom, int vspeed,int hp, int hpMax, GamePanel gp, String vNomFichierSonMort, int vPtAtt, int vPtDef) {
		super(x, y, numeroMap, nom, vspeed, hp, hpMax, gp, vNomFichierSonMort, vPtAtt, vPtDef);
	}
	
	
	/**
	 * Permet de provoquer le déplacement du personnage en fonction de certain pourcentage, met à jour l'attribut isMoving
	 * @param chanceImmobile nombre de chance que l'entité soit immobile, doit être un entier
	 * @param chanceTotal nombre de chance total
	 */
	public void deplacementAleatoire(int chanceImmobile, int chanceTotal) {
		
		isMoving = true;
		
		int dep = random.nextInt(chanceTotal);
		
		if (dep > 4 + chanceImmobile) {
			this.deplacerVersOrientation(orientation,false);
			
		} else if (dep < 4) {
			
			switch (dep) {
				case 0:
					deplacerBas(false);
					break;
				case 1:
					deplacerHaut(false);
					break;
				case 2:
					deplacerDroite(false);
					break;
				case 3:
					deplacerGauche(false);
					break;
				}
			
		} else {
			isMoving = false;
			this.resterImmobile();
		}
	}
	

	
	protected void resterImmobile() {
		
	}
	
	/*
	 * Lorsque le monstre meurt, il rapporte des pièces et de l'xp au joueur
	 */
	protected void definitivementMort() {
		if (!don) {
			gp.getPlayer().addRichesse(this.valeurOr, this.valeurXp);
			don = true;

			this.gp.removeListeEntites(numeroMap, this); // Pour supprimer monstre quand il meurt mais ne marche pas
		}
	}

	@Override
	public void takeDamage(int damage) {
		super.takeDamage(damage);
		if (this.isMort && !don) {
			
			this.definitivementMort();
		}
	}
	
	@Override
	public void interaction() {
		// TODO Auto-generated method stub
		
	}
	
	public abstract String getClasse();
}

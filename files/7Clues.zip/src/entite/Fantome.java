package entite;

import gameWindow.GamePanel;

public class Fantome extends Monstre {
	
	private static final int PT_ATT_INIT = 2;
	private static final int PT_DEF_INIT = 2;
	
	public Fantome(int x, int y, int numeroMap, String nom, int speed, int hp, int hpMax, GamePanel gp) {
		super(x, y, numeroMap, nom, speed, hp, hpMax, gp, "musique/player_dead.wav", PT_ATT_INIT, PT_DEF_INIT);
		super.nombreImageAnimeMort = 199;
		super.nombreImageAnimeDeplacement = 2;
	}
	
	/**
	 * Permet au loup de se déplacer, il a plus de chance que les autres entités d'être maintenu au même endroit.
	 */
	private void deplacementVersJoueur() {
	    double distance = Math.sqrt(Math.pow(gp.getPlayer().getX() - x, 2) + Math.pow(gp.getPlayer().getY() - y, 2));
	    if (distance > 5) {
	    	double dx = (gp.getPlayer().getX() - x) / distance;
	    	double dy = (gp.getPlayer().getY() - y) / distance;
	    	x += dx * speed;
	    	y += dy * speed;
	    }
	    if (x - gp.getPlayer().getX() < 0) {
	    	setOrientation("est");
	    }
	    else {
	    	setOrientation("ouest");
	    }
	    if (Math.abs(y - gp.getPlayer().getY()) > Math.abs(x - gp.getPlayer().getX())){
		    if (y - gp.getPlayer().getY() < 0) {
		    	setOrientation("sud");
		    }
		    else {
		    	setOrientation("nord");
		    }
	    }
	}

	@Override
	public void update() {

		super.update();
		if (!this.isMort) {
			this.deplacementVersJoueur();
			if (isAttaquing) {
				hit();
			}
			this.attaquerPlayer();
		}
		this.animer();
	}

	@Override
	public String getClasse() {
		return "Fantome";
	}

	
}


package entite;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

import gameWindow.Dialogue_Box;
import gameWindow.GamePanel;

public class PNJ extends EntiteMobile{
	
	//dialogues dont le premier a apparaitre sur l'écran est le dernier non vide
	private String[] dialogues;
	
	//nbr de messages du pnj
	private int dialogueIndexPNJ = 0;
	private int nbTotalMessages;
	
	/* Chaque PNJ a sa propre boite de dialogue pour quelles puissent être personalisée en fonction du PNJ */
	private Dialogue_Box boiteDialogue;
	
	private String nom;
	private boolean dialogueActif;

	public PNJ(int x, int y, int numeroMap, String orientation, String nom, int vspeed, GamePanel gp, int nbrDialogues, String[] diag) {
		super(x, y, numeroMap, nom, vspeed, gp, "empty");
		this.setOrientation(orientation);
		this.nom = nom;
		this.dialogueActif = false;
		this.dialogues = diag;
		this.dialogueIndexPNJ = 0;
		this.nbTotalMessages = nbrDialogues;
		this.boiteDialogue = new Dialogue_Box(this.dialogues[0]);
	}

	@Override
	public String getClasse() {
		return "pnj";
	}
	
	public void desactiverDialogueActif() {
		this.dialogueActif = false;
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub		
	}
	
	@Override
	public void draw(Graphics2D g2) {
		super.draw(g2);
		if (this.dialogueActif) {
			this.boiteDialogue.draw(g2); 
		}
	}
	

	@Override
	public BufferedImage getTexture() {
		try {
			return ImageIO.read(new File("pnjSprite/" + this.nom.toLowerCase().replaceAll(" ", "") + ".png")); // marche pour PNJ immobile mais on se contente de ça pour l'instant
		} catch (IOException e) {
			System.out.print("Si tu lis ça c'est que le path des files est en absolu enlève le / du début");
			e.printStackTrace();
		}
		return null;
	}
	
	public void interaction() {
		this.gp.stopperLeJeu();
		this.gp.activerDialogue(this);
		this.boiteDialogue.setTexte("[" + this.nom + "] " + this.dialogues[this.dialogueIndexPNJ]);
		this.dialogueActif = true;
		if (this.dialogueIndexPNJ < this.nbTotalMessages-1) {
			this.dialogueIndexPNJ++; //a chaque fois qu'on interragit; diag different jusqu'à ce qu'il n'en ait plus d'autre (pas 2 fois le meme)
		}
	}

}

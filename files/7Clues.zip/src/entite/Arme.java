package entite;

import gameWindow.GamePanel;

public class Arme extends Objet {
	
	public enum TypeArme{
		  EPEE(20);
			

		  private final int degat;

		  private TypeArme(int degat) {
		    this.degat = degat;
		  }

		  public int getDegat() {
		    return this.degat;
		  }
		  
	}
	
	private TypeArme typeArme;
	
	public Arme(NomObjet nom, int nb, String lienImage, GamePanel gp) {
		super(nom, TypeObjet.ARME, nb, lienImage,gp);
		this.typeArme = TypeArme.valueOf(nom.toString());
	}
	
	public Arme(String nom, int nb) {
		super(nom,TypeObjet.ARME,nb);
		this.typeArme = TypeArme.valueOf(nom);
	}
	
	public Arme(NomObjet nom, int nb) {
		super(nom,TypeObjet.ARME,nb);
		this.typeArme = TypeArme.valueOf(nom.toString());
	}
	
	public Arme(NomObjet nom, int nb, String lienImage, int x, int y, int numMap, boolean estInvisible, boolean estSupprimable, GamePanel gp) {
		super(nom, TypeObjet.ARME, nb, lienImage, x, y, numMap, estInvisible, estSupprimable,gp);
		this.typeArme = TypeArme.valueOf(nom.toString());
	}
	
	@Override
	public void utiliser(Joueur joueur) {
		super.utiliser(joueur);
		/* TO DO */ 
		//joueur.gagnerPV(this.typeArme.degat);
		//joueur.removeObjet(this.getNom(), 1);
	}

}

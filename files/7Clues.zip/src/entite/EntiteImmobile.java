package entite;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import gameWindow.GamePanel;

public class EntiteImmobile extends Entite {

	//protected int spriteNum;
	protected String orientation;
	
	/** booleen qui vaut true si le joueur a interagi avec l'objet (auquel cas on ne l'affiche pas) */
	protected boolean wasInteractedWith;
	
	public EntiteImmobile(int vx, int vy, int numeroMap, String vNom, GamePanel gp, String or, boolean interactedWith) {
		super(vx, vy, numeroMap, vNom, gp);
		//this.spriteNum = sprNum;a
		this.orientation = or;
		this.wasInteractedWith = interactedWith;
		this.hpOrNot = false;
	}
	
	public EntiteImmobile(String vNom, GamePanel gp, boolean interactedWith) {
		super(vNom, gp);
		this.orientation = "";
		this.wasInteractedWith = interactedWith;
	}

	@Override
	public BufferedImage getTexture() {
		try {
			if (!this.wasInteractedWith) {
				return ImageIO.read(new File(
						"tiles/" + this.nom + this.orientation + ".png"));
			}
		} catch (IOException e) {
			System.out.print("Si tu lis ça c'est que le path des files est en absolu enlève le / du début");
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public void update() {
		if (this.wasInteractedWith) {
			//this.disappear();
		}
	}

	public void interaction() {
		if(this.nom.equals("Biblio"))  {
			if(this.gp.getPlayer().isCleDebloque()) {
				this.wasInteractedWith = !this.wasInteractedWith;//pb : changer la map des murs
				this.traversable = !this.traversable; // Changer le statut des murs
				System.out.println("wsh");
				System.out.println(this.nom);
			}
		} else {
			this.wasInteractedWith = !this.wasInteractedWith;//pb : changer la map des murs
			this.traversable = !this.traversable; // Changer le statut des murs
			System.out.println("wsh");
			System.out.println(this.nom);
		}
	}

}

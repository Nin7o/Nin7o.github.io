package entite;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Random;

import gameWindow.GamePanel;

public class MonstreAvecAttaqueADistance extends Monstre {
	
	private static final int PT_ATT_INIT = 20;
	private static final int PT_DEF_INIT = 2;
	
	private int compteurTir;
	public Fleche fleche;
	Random random = new Random(x * y);

	public MonstreAvecAttaqueADistance(int x, int y, int numeroMap, String nom, int speed, int hp, int hpMax, GamePanel gp, int compteurTir) {
		super(x, y, numeroMap, nom, speed, hp, hpMax, gp, "musique/player_dead.wav", PT_ATT_INIT, PT_DEF_INIT);
		super.nombreImageAnimeMort = 199;

		this.compteurTir = compteurTir;
		this.fleche = null;
	}
	
	@Override
	public void update() {
		super.update();
		compteurTir++;
		if (compteurTir >= 250 && !this.isMort) {
			compteurTir = 0;
			fleche = new Fleche(x, y, numeroMap, nom, speed, hp, gp);
		}
		if (fleche != null) {
			fleche.update();
			if (fleche.compteurExplosion >= 115) {
				fleche = null;
			}

		}
		if (!this.isMort && stunned==0) {
			this.deplacementAleatoire(6,300);
			this.animer();
		}
		
	}

	@Override
	public void draw(Graphics2D g2) {
		super.draw(g2);
		if (fleche != null) {
			BufferedImage sprite = this.fleche.getTexture();
			g2.drawImage(sprite, fleche.getX(), fleche.getY(), GamePanel.getTileSize(), GamePanel.getTileSize(), null);
		}
	}

	@Override
	public String getClasse() {
		return "Archer";
	}

}

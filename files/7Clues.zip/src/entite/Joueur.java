package entite;

import inputs.OurKeyListener;

import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import entite.Objet.NomObjet;
import entite.Objet.TypeObjet;
import exceptions.TailleMaxInventaireAtteinteException;
import exceptions.QuantiteObjetInsuffisanteException;
import gameWindow.GamePanel;
import gameWindow.Main;
import gameWindow.Main.STATE;

public class Joueur extends EntiteMobileAvecHp {

	private OurKeyListener keyH;

	// probablement à mettre dans une classe plus haut
	public enum SEXE {
		F, G
	}

	private SEXE sexe;
	private int xp = 50;
	private int or = 55;
	private boolean isInteracting;
	private int tailleMaxInventaire = 12;
	private Objet objetEnMain;
	private int nbElementEnquete = 0;
	//private int compteurDebloqueCle;
	
	// variables relatives aux enquêtes
	private int nbRatsMorts;
	private boolean cleDebloque;
	
	private Map<NomObjet,Objet> inventaire;

	/**
	 * Constructeur pour le joueur
	 */
	public Joueur(int x, int y, int numeroMap, String nom, int speed, int hp, int hpMax, GamePanel gp,
			OurKeyListener keyH, SEXE sexe, int vPtAtt, int vPtDef, int vXp, int vOr, Map<NomObjet,Objet> vInventaire) {
		super(x, y, numeroMap, nom, speed, hp, hpMax, gp, "musique/player_dead.wav", vPtAtt, vPtDef,true);
		this.keyH = keyH;
		this.sexe = sexe;
		this.xp = vXp;
		this.or = vOr;
		super.nombreImageAnimeMort = 199;
		this.inventaire = vInventaire;
		this.objetEnMain = null;
		this.cleDebloque = false;
		this.nbRatsMorts = 0;

		// super.Hitbox = new Rectangle(GamePanel.tileSize/4, GamePanel.tileSize*3/4,
		// GamePanel.tileSize/2, GamePanel.tileSize/4);
	}

	public void setSpeed(int vspeed) {
		speed = vspeed;

	}

	public int getOr() {
		return this.or;
	}

	public int getXp() {
		return this.xp;
	}
	
	public int getHp() {
		return this.hp;
	}
	
	public int getHpMax() {
		return this.hpMax;
	}
	
	public int getNbElEnquete() {
		return this.nbElementEnquete;
	}
	
	public int getCurrentMap() {
		return this.numeroMap;
	}
	
	public Map<NomObjet, Objet> getInventaire(){
		return this.inventaire;
	}
	

	
	/**
	 * Permet d'ajouter un objet dans le sac
	 * @param objet
	 * @throws TailleMaxInventaireAtteinteException
	 */
	public void addObjet(Objet objetAjout) throws TailleMaxInventaireAtteinteException {
		if (inventaire.containsKey(objetAjout.getNom())) {
			System.out.println("contient");
			Objet objet = inventaire.get(objetAjout.getNom());
			objet.augmenterQuantite();
			inventaire.replace(objetAjout.getNom(), objet);
		} else {
			if (inventaire.size()>= this.tailleMaxInventaire) {
				throw new TailleMaxInventaireAtteinteException(objetAjout.getNom());
			}
			Objet objet = Objet.creerObjet(objetAjout.getNom(), objetAjout.getType(), objetAjout.getQuantite());

			System.out.println(" classe" + objet.getClass());
			inventaire.put(objetAjout.getNom(), objet);
		}
		if (objetAjout.getType() == TypeObjet.ENQUETE) {
			this.nbElementEnquete++;
			// Si le joueur à récupérer suffisament d'élément de l'enquête : déclarer vainqueur
			if (this.nbElementEnquete > 0) {
				Main.setState(STATE.GAGNE);
			}
		}
		Main.mettreAJourListeObjets();
		System.out.println("objet ajouté : " + objetAjout.getNom());
	}
	
	/**
	 * Permet de retirer un objet du sac
	 * @param nomObjet
	 * @param quantite
	 * @throws QuantiteObjetInsuffisanteException
	 */
	public void removeObjet(NomObjet nomObjet, int quantite) throws QuantiteObjetInsuffisanteException {
		Objet objet = inventaire.get(nomObjet);
		if (objet == null) {
			throw new QuantiteObjetInsuffisanteException(nomObjet,quantite);
		} else if (objet.getQuantite() < quantite) {
			throw new QuantiteObjetInsuffisanteException(nomObjet, quantite - objet.getQuantite());
		} else {
			objet.diminuerQuantite(quantite);
			if (objet.getQuantite() == 0) {
				inventaire.remove(nomObjet);
			} else {
				inventaire.replace(nomObjet, objet);
			}
			
		}
		
		Main.mettreAJourListeObjets();
	}
	
	public void changerObjetEnMain(Objet nom) {
		this.objetEnMain = nom;
		Main.mettreAJourListeObjets();
	}
	
	public Objet getObjetEnMain() {
		return this.objetEnMain ;
	}

	public void addRichesse(int vOr, int vXp) {
		this.or += vOr;
		this.xp += vXp;
		Main.mettreAJourOrXp();
	}

	public void payerAvecOr(int vOr) {
		this.or -= vOr;
		Main.mettreAJourOrXp();
	}

	public void payerAvecXp(int vXp) {
		this.xp -= vXp;
		Main.mettreAJourOrXp();
	}

	public void addPuissance(int vDef, int vAtt, int vSpeed) {
		this.ptDef += vDef;
		this.ptAtt += vAtt;
		this.speed += vSpeed;
	}
	
	/* Methode pour régénérer une partie des points de vie (quand on mange un alliment) */
	public void gagnerPV(int pv) {
		this.hp += pv;
		if (this.hp > this.hpMax) {
			this.hp = this.hpMax;
		}
		Main.mettreAJourOrXp();
	}
	
	public void augmenterNbRatsMorts() {
		this.nbRatsMorts++;
		
		// une clé apparait sur la map si suffisament de rats ont été tués
		if ((this.nbRatsMorts >=3) && (!this.cleDebloque)) {
			this.cleDebloque = true;
			this.gp.addListeObjets(0,new Objet(NomObjet.CLEMAGIQUE, TypeObjet.CLE, 1, "images/clemagique.png", 200, 420, 0, false,true,this.gp));
			System.out.println("Clé magique ajouté");
		}
		
	}

	@Override
	public void deplacerBas(boolean repoussage) {

		super.deplacerBas(repoussage);
		this.orientation = "sud";
	}

	@Override
	public void deplacerHaut(boolean repoussage) {

		super.deplacerHaut(repoussage);
		this.orientation = "nord";
	}

	@Override
	public void deplacerDroite(boolean repoussage) {

		super.deplacerDroite(repoussage);
		this.orientation = "est";
	}

	@Override
	public void deplacerGauche(boolean repoussage) {

		super.deplacerGauche(repoussage);
		this.orientation = "ouest";
	}

	// run at each frame
	// updates the player
	@Override
	public void update() {
		super.update();
	
		if (!isMort && !isAttaquing && !isInteracting) {
			this.trouverOrientationMouvement();

			if (keyH.isKeyPressed(KeyEvent.VK_ESCAPE)) {
				System.exit(1); // c'est ptete un peu violent, c'est pas ce qui était convenu
				// dans le cahier des charges mais c'est en attendant
				// but final: touche échape ferme le menu (pause, quête, map) actuellement
				// ouvert sauf
				// si on est dans le menu principal
			}

			collisionON = false;
			gp.playerCollider.checkCollision(this);
			gp.playerCollider.checkTeleportation(this);

			if (this.isMoving) {
				if (collisionON == false) {
					deplacerVersOrientation(orientation,false);
				}
			}
			animer();
			this.attaquerOuInteragir();
		}
		if (isAttaquing) {
			hit();
		} else if (isInteracting) {
			Interaction interaction = new Interaction(gp);
			List<Entite> entitesInRange = interaction.detectEntity(this, this.orientation, 65, this.numeroMap);
			for (Entite e : entitesInRange) {
				e.interaction();
			}
			isInteracting = false;
		}
		
		if (this.hp <= 0) {
			Main.setState(Main.STATE.MORT);
		}
	}
	
	@Override
	public void draw(Graphics2D g2) {
		super.draw(g2);
		try {
		
		if (isAttaquing && !this.isMort) {
			if (this.compteurAnimeAttaque == this.nombreImageAnimeAttaque - 2) {
			}

				if (this.objetEnMain != null && this.objetEnMain.getType() == TypeObjet.ARME) {
					BufferedImage sprite = ImageIO.read(new File("playerSprite/" + this.getClasse() + "/Attaquing/"
							+ orientation + objetEnMain.getNom().toString().toLowerCase() + Math.round(compteurAnimeAttaque / 10) + ".png"));
					switch (orientation) {
					case "sud":
						g2.drawImage(sprite, this.getX(), this.getY() + 30, GamePanel.getTileSize(), GamePanel.getTileSize(), null);
						break;
					case "nord":
						g2.drawImage(sprite, this.getX(), this.getY() - 25, GamePanel.getTileSize(), GamePanel.getTileSize(), null);
						break;
					case "est":
						g2.drawImage(sprite, this.getX() + 35, this.getY(), GamePanel.getTileSize(), GamePanel.getTileSize(), null);
						break;
					case "ouest":
						g2.drawImage(sprite, this.getX() - 35, this.getY(), GamePanel.getTileSize(), GamePanel.getTileSize(), null);
						break;
					}
				}
				
		} 
		if (this.isMort){
			//this.son_attaque.desactiverSon();
		}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public void interaction() {
		// TODO Auto-generated method stub this.getEntityInFront.interaction() ou si

	}
	
	@Override
	public void hit() {
		super.hit();
	}
	
	/*
	 * Calcul en fonction de l'arme en main et des points d'attaques que le joueur a les dégats qu'il va faire.
	 */
	private int getDamage() {
		int degat = this.ptAtt;
		if (objetEnMain.getType() == TypeObjet.ARME) {
			degat += 10;
		}
		return degat;
	}

	private void trouverOrientationMouvement() {
		this.isMoving = true;
		if (keyH.isKeyPressed(KeyEvent.VK_Q)) {
			this.orientation = "ouest";
		} else if (keyH.isKeyPressed(KeyEvent.VK_S)) {
			this.orientation = "sud";
		} else if (keyH.isKeyPressed(KeyEvent.VK_D)) {
			this.orientation = "est";
		} else if (keyH.isKeyPressed(KeyEvent.VK_Z)) {
			this.orientation = "nord";
		} else {
			this.isMoving = false;
		}
	}

	private void attaquerOuInteragir() {
		if (keyH.isKeyTyped(KeyEvent.VK_A)) {
			keyH.traiterTyped(KeyEvent.VK_A);
			isAttaquing = true;
			isMoving = false;
			Interaction interaction = new Interaction(gp);
			List<Entite> monstres = interaction.detectEntity(this, orientation, 100, numeroMap);
			for (Entite monstrei : monstres) {
				if (monstrei != null && monstrei.hpOrNot == true) {
					System.out.println(orientation);
					String orientationInitiale = ((EntiteMobileAvecHp) monstrei).orientation;
					((EntiteMobileAvecHp) monstrei).deplacerVersOrientation(orientation,true);
					((EntiteMobileAvecHp) monstrei).deplacerVersOrientation(orientation,true);
					((EntiteMobileAvecHp) monstrei).deplacerVersOrientation(orientation,true);
					((EntiteMobileAvecHp) monstrei).deplacerVersOrientation(orientation,true);
					((EntiteMobileAvecHp) monstrei).deplacerVersOrientation(orientation,true);
					((EntiteMobileAvecHp) monstrei).deplacerVersOrientation(orientation,true);
					((EntiteMobileAvecHp) monstrei).deplacerVersOrientation(orientation,true);
					((EntiteMobileAvecHp) monstrei).takeDamage(this.getDamage());
					System.out.println("xp : " + this.xp + "\n or :" + this.or);
					((EntiteMobileAvecHp) monstrei).setOrientation(orientationInitiale);
					((EntiteMobileAvecHp) monstrei).stun(20);

				}

			}
			this.hit();
			
		} else if (keyH.isKeyTyped(KeyEvent.VK_E)) {
			keyH.traiterTyped(KeyEvent.VK_E);
			System.out.println("inter");
			isInteracting = true;// un peu inutile on a dedoublement du hit
			isMoving = false;
			
		/* Manger */
		} else if (keyH.isKeyTyped(KeyEvent.VK_C)) {
			keyH.traiterTyped(KeyEvent.VK_C);
			if (this.objetEnMain != null) {
				this.objetEnMain.utiliser(this);
			}
		}
	}


	@Override
	public String getClasse() {
		return "Joueur";
	}


	public void sauvegarderJoueur(int numSauvegarde) {
		try {
			// System.out.println("sauvegarde en cours");
			PrintWriter save = new PrintWriter("sauvegardes/sauvegarde" + numSauvegarde + ".txt");
			save.println("p : " + this.nom + " " + this.sexe + " " + this.spritNum);
			save.println("v : " + this.xp + " " + this.or + " " + this.hp + " " + this.hpMax);
			save.println("x : " + this.x + " " + this.y + " " + this.numeroMap);
			save.println("c : " + this.speed + " " + this.ptAtt + " " + this.ptDef);
			save.print("i :");
			for (Map.Entry<NomObjet, Objet> objet : inventaire.entrySet()) {
				save.print(" " + objet.getKey().name() + " " + objet.getValue().getQuantite());
			}
			save.close();
			// System.out.println("sauvegarde en terminé");
		} catch (FileNotFoundException e) {
			System.out.println("La sauvegarde a échouer");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	public boolean isCleDebloque() {
		return this.cleDebloque;
	}
}

package sound;

import java.io.File;
import java.io.IOException;

//Pour la musique
import javax.sound.sampled.*;

import gameWindow.Main;

public class Son{
	
	public enum TYPESON{
		BACKGROUND,
		BRUITAGE,
		GLOBAL
	};
	
	public static int MAXVOL = 6;
	public static int MINVOL = -80;
	
	Clip clip;
	private FloatControl volume;
	/**
	 * Constructeur pour les bruitages
	 * @param nomFichier
	 */
	public Son(String nomFichier) {
		this(nomFichier,false);
		this.volume.setValue((Main.getVolumeBruitage()/100)*(MAXVOL - MINVOL) + MINVOL);
	}
	
	public Son(String nomFichier, Boolean loop) {
		File file = new File(nomFichier); // "musique/musique_de_fond.wav"
		AudioInputStream audioStream;
		try {
			
			audioStream = AudioSystem.getAudioInputStream(file);
			System.out.println("la");
			clip = AudioSystem.getClip();
			clip.open(audioStream);
			this.volume = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
			System.out.println("volume ok");
			this.volume.setValue(-30);
			if (loop) {
				clip.loop(Clip.LOOP_CONTINUOUSLY);
			}
		} catch (UnsupportedAudioFileException e) {
			System.out.println("UnsupportedAudioFileException");
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("IOException");
			e.printStackTrace();
		} catch (LineUnavailableException e) {
			System.out.println("LineUnavailableException");
			e.printStackTrace();
		}
		
	}
	/**
	 * Permet d'activer la musique ou l'effet sonore
	 */
	public void activerSon() {
		clip.start();
	}
	/**
	 * Permet de stopper la musique ou l'effet sonore, ou de les "rendre muets"
	 */
	public void desactiverSon() {
		clip.stop();
	}
	
	/**
	 * Permet d'augmenter le volume du son de la valeur du paramètre
	 * @param augmentation
	 */
	public void augmenterSon(float augmentation) {
		float vol = this.volume.getValue() + augmentation;
		if (vol > MAXVOL) {
			vol = MAXVOL;
		}
		this.volume.setValue(vol);
	}
	/**
	 * Permet de diminuer le volume du son de la valeur du paramètre
	 * @param diminution
	 */
	public void diminuerSon(float diminution) {
		float vol = volume.getValue() - diminution;
		if (vol < MINVOL) {
			vol = MINVOL;
		}
		this.setVolume(vol);
		
	}
	/**
	 * Permet de définir le volume que l'on souhaite
	 * @param vol floatant compris entre -80 et 6
	 */
	public void setVolume(float vol) {
		if (vol < MINVOL) {
			vol = MINVOL;
		}
		if (vol > MAXVOL) {
			vol = MAXVOL;
		}
		this.volume.setValue(vol);
		//System.out.println(this.volume);
	}
	
	public float getVolume() {
		return this.volume.getValue();
	}
	
			
}

package loadsave;

import javax.management.RuntimeErrorException;

public class ErreurSauvegardeChargement extends RuntimeException {
	
	public ErreurSauvegardeChargement(String message) {
		super(message);
	}
}

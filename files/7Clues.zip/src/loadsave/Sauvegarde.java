package loadsave;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import entite.Aliment;
import entite.Entite;
import entite.Joueur;
import entite.Objet;
import entite.Objet.NomObjet;
import entite.Objet.TypeObjet;
import gameWindow.GamePanel;
import entite.Joueur.SEXE;

public class Sauvegarde {
	
	private static final int NB_ARG_PERS = 3; // nb d'argument
	private static final int NB_ARG_VAL = 4;
	private static final int NB_ARG_XY = 3;
	private static final int NB_ARG_COM = 3;
	private Joueur player;
	private int numSauvegarde;
	private GamePanel gp;
	
	public Sauvegarde(int numSauvegarde, Joueur player, GamePanel gp) {
		this.numSauvegarde = numSauvegarde;
		this.player = player;
		this.gp = gp;
	}
	
	public void sauvegarder() {
		player.sauvegarderJoueur(this.numSauvegarde);
		List<Entite> listeObjets = new ArrayList<Entite>();
		for (int i = 0; i < gp.getNbMap(); i++) {
			listeObjets.addAll(gp.getListeObjets(i));
		}
		this.sauvegarderObjetsMap(listeObjets);
		
	}
	
	/**
	 * Récupère les données de sauvegardes et créer le joueur correspondant
	 * @param nb numéro du fichier de sauvegarde à charger
	 * @param gp gamepanel
	 * @param keyH keylistener
	 * @return le joueur créer à partir des données de sauvegarde
	 */
	public static entite.Joueur chargerJoueur(int nb, gameWindow.GamePanel gp, inputs.OurKeyListener keyH) {
		Scanner scanner;
		try {
			// charge le fichier contenant la sauvegarde
			File fichierSauvegarde = new File("sauvegardes/sauvegarde" + nb + ".txt");
			scanner = new Scanner(fichierSauvegarde);
		
		
			String ligne;
			String[] tabLigne;
			String[] caracteristiques;
			
			// Caractéristiques (initialisé avec leur valeur par défaut)
			String nom = "pas_de_nom";
			Joueur.SEXE sexe = Joueur.SEXE.G;
			int numSprite = 1;
			int or = 0;
			int xp = 0;
			int hp = 0;
			int hpMax = 0;
			int x = 0;
			int y = 0;
			int numMap = 1;
			int speed = 6;
			int ptAtt = 3;
			int ptDef = 3;
			
			Map<NomObjet,Objet> inventaire = new HashMap<NomObjet,Objet>();
			
			// Parcours du fichier et affectation des variables
			while (scanner.hasNextLine()) {
				ligne = scanner.nextLine();
				if (ligne.charAt(0) == '%') {
					
				} else {
					tabLigne = decouperEtVerifierNbArguments(ligne, 2, " : ");
					
					switch (tabLigne[0].charAt(0)) {
					case ('p') : // identité du personnage (nom, sexe, numero de sprite)
						//System.out.println("id");
						caracteristiques = decouperEtVerifierNbArguments(tabLigne[1], NB_ARG_PERS, " ");
						nom = caracteristiques[0];// Sauvegarder le nom du joueur entre guillement au cas où il met un espace ???
						if (caracteristiques[1].equals("F")) {
							sexe = Joueur.SEXE.F;
						} else if (caracteristiques[1].equals("G")){
							sexe = Joueur.SEXE.G;
						}
						numSprite = Integer.parseInt(caracteristiques[2]);
						break;
					case('v') : // Xp, or, hp, hpMax
						//System.out.println("val");
						caracteristiques = decouperEtVerifierNbArguments(tabLigne[1], NB_ARG_VAL, " ");
						xp = Integer.parseInt(caracteristiques[0]);
						or = Integer.parseInt(caracteristiques[1]);
						hp = Integer.parseInt(caracteristiques[2]);
						hpMax = Integer.parseInt(caracteristiques[3]);
						break;
					case('x') :
						//System.out.println("xy"); // position du personnage (x, y, numéro de la map)
						caracteristiques = decouperEtVerifierNbArguments(tabLigne[1], NB_ARG_XY, " ");
						x = Integer.parseInt(caracteristiques[0]);
						y = Integer.parseInt(caracteristiques[1]);
						numMap = Integer.parseInt(caracteristiques[2]);
						break;
					case('c') :
						//System.out.println("competence"); // compétence du personnage (vitesse, point d'attaque, point de défense)
						caracteristiques = decouperEtVerifierNbArguments(tabLigne[1], NB_ARG_COM, " ");
						speed = Integer.parseInt(caracteristiques[0]);
						ptAtt = Integer.parseInt(caracteristiques[1]);
						ptDef = Integer.parseInt(caracteristiques[2]);
						break;
					case('i') :
						caracteristiques = tabLigne[1].split(" ");
						for (int compteur = 0; compteur < caracteristiques.length/3; compteur++) {
							Objet objet = Objet.creerObjet(caracteristiques[compteur*3], Objet.TypeObjet.valueOf(caracteristiques[compteur*3 + 1].toUpperCase()), Integer.parseInt(caracteristiques[compteur*3 + 2]));
							inventaire.put(objet.getNom(), objet);
						}
					}
				}
			}
			scanner.close();
			/**System.out.print("nom : " + nom + "\n" +"sexe : " + sexe + "\n" +"spritenumber : " 
						+ Integer.toString(numSprite) + "\n" +"xp : " + Integer.toString(xp) + "\n" 
						+ "or : " + Integer.toString(or) + "\n" +"hp : " + Integer.toString(hp) 
						+ "\n" +"x : " + Integer.toString(x) + "\n" +"y : " + Integer.toString(y) + "\n"
						+ "numMap :" + Integer.toString(numMap) + "\n"
						+ "speed :" + Integer.toString(speed) + "\n"
						+ "ptAtt :" + Integer.toString(ptAtt) + "\n"
						+ "ptDef :" + Integer.toString(ptDef) + "\n");*/
			return new entite.Joueur(x, y, numMap, nom, speed, hp, hpMax, gp, keyH, SEXE.G,ptAtt,ptDef, xp, or, inventaire);
		} catch (FileNotFoundException e) {
			throw new ErreurSauvegardeChargement("le fichier de sauvegarde n'a pas été trouvé :" + nb);
		}
	}
	/**
	 * Charger la liste des monstres incrites dans le fichier
	 * @param fichier
	 * @return listre de monstre
	 */
	public static String[][][] charger(File fichier) {
		String[][][] liste = new String[100][1000][100];
		int j = 0;
		int i = 0;
		try {
			Scanner scanner = new Scanner(fichier);
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				if (line.startsWith("Map")) {
					i = scanner.nextInt(); // numéro de la map sur laquelle vont être chargé les monstres 
					line = scanner.nextLine();
				} else {
					liste[i][j] = line.split("_");// ne serait il pas mieux de mettre un autre symbole afin que
					// le fichier test soit plus lisible ? par exemple juste des espaces ou des _
					j = j + 1;	
				}
			}
			scanner.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return liste;
	}
	
	
	public static List<Entite>[] chargerObjets(GamePanel gp, int numSauvegarde) {
		
		List<Entite>[] objets = new ArrayList[gp.getNbMap()];
		for (int i = 0; i<gp.getNbMap(); i++) {
			objets[i] = new ArrayList<Entite>();
		}
		
		try {
			
			File fichierObjets = new File("sauvegardes/objets"+ numSauvegarde +".txt");
			Scanner scanner = new Scanner(fichierObjets);
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				String[] args = line.split(" ");
				if (!(args[0].equals("%"))) {
					NomObjet nom = NomObjet.valueOf(args[0].toUpperCase());
					TypeObjet type = TypeObjet.valueOf(args[1].toUpperCase());
					int quantite = Integer.parseInt(args[2]);
					int x = Integer.parseInt(args[3]);
					int y = Integer.parseInt(args[4]);
					int numMap = Integer.parseInt(args[5]);
					boolean estInvisible = Boolean.valueOf(args[6]);
					boolean estSupprimable = Boolean.valueOf(args[7]);
					Objet objet;
					switch (type) {
					case ALIMENT :
						objet = new Aliment(nom, quantite, "images/" + args[0].toLowerCase() + ".png", x, y, numMap, estInvisible,estSupprimable,gp);
						break;
					default :
						objet = new Objet(nom, type, quantite, "images/" + args[0].toLowerCase() + ".png", x, y, numMap, estInvisible,estSupprimable,gp);
						break;
					}
					objets[numMap].add(objet);
					if (objet.getType() == TypeObjet.COFFRE) {
						String[] objetDedansString = line.split(":");
						for (String objDedans : objetDedansString) {
							String[] sousObj = objDedans.split(" ");
			
							if (sousObj.length == 4) {
								//System.out.println(sousObj.length + sousObj[1]);
								NomObjet sousObjNom = NomObjet.valueOf(sousObj[1].toUpperCase());
								TypeObjet sousObjType = TypeObjet.valueOf(sousObj[2].toUpperCase());
								int sousObjQuantite = Integer.parseInt(sousObj[3]);
								Objet sousObjet = Objet.creerObjet(sousObjNom, sousObjType, sousObjQuantite);
								System.out.println(" classe" + sousObjet.getClass());
								objet.ajouterDedans(sousObjet);
							}
						}
					}
				}
			}
			scanner.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new ErreurSauvegardeChargement("Chargements des objets");
		}
		
		return objets;
	}
	
	/**
	 * découpe la chaine de caractère suivant le symbole fournit en entrée 
	 * et vérifie que après découpe, il y a le bon nombre de chaine de charactère.
	 * @param args String qui va être découpé
	 * @param lengthTheorique la taille du tableau de String que devrait faire args après découpe
	 * @param symbole le symbole selon lequel on va découper la chaine de character
	 * @return un tableau de chaine de charactère dépouper selon le symbole
	 */
	private static String[] decouperEtVerifierNbArguments(String args,int lengthTheorique, String symbole) {
		String[] tab = args.split(symbole);
		if (tab.length != lengthTheorique) {
			throw new ErreurSauvegardeChargement("pas le bon nombre "
					+ "d'arguments dans l'une des caractéristiques décrites "
					+ "dans le fichier sauvegarde");
		}
		return tab;
	}
	
	/* Récupère le nombre total de sauvegardes déjà effectué*/
	public static int nbTotalSauvegardes() {
		File fichierNbSauvegardes = new File("sauvegardes/nbSauvegardes");
		Scanner scanner;
		try {
			scanner = new Scanner(fichierNbSauvegardes);
			int nbSauvegardes = Integer.parseInt(scanner.nextLine());
			scanner.close();
			return nbSauvegardes;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new ErreurSauvegardeChargement("le fichier nbSauvegardes n'a pas pu être lue");
		}
		
	}
	
	public void sauvegarderObjetsMap(List<Entite>listeObjets) {
		try {
			// System.out.println("sauvegarde en cours");
			PrintWriter save = new PrintWriter("sauvegardes/objets" + this.numSauvegarde + ".txt");
			for (Entite objet : listeObjets) {
				save.println(objet.ligneASauvegarder());
			}
			save.close();
			// System.out.println("sauvegarde en terminé");
		} catch (FileNotFoundException e) {
			System.out.println("La sauvegarde des objets a échouer");
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

package slider;

import java.awt.Color;
import java.awt.Dimension;
import javax.swing.event.ChangeEvent;

import gameWindow.Main;
import sound.Son;
import sound.Son.TYPESON;

public class SliderSonore extends Slider{

	
	private int oldvalue;
	
	private Son son;
	private float glob = 5;
	
	private TYPESON typeSon;

	
	public SliderSonore(int depart, int fin, Dimension dim, int minPas, int maxPas, int initVal, Color couleur, Son son,TYPESON tson) {
		super(depart, fin, dim, minPas, maxPas, initVal, couleur);
		typeSon = tson;
		
		if (typeSon != TYPESON.BRUITAGE) {
			this.son = son;
		}
	
	}
	
	
	
	@Override
	public void stateChanged(ChangeEvent e) {
		oldvalue = value;
		value = slider.getValue();
		
		if (typeSon == TYPESON.BACKGROUND) {
			this.son.diminuerSon((oldvalue - value)*(Son.MAXVOL-Son.MINVOL)*glob/100 );
		} 
		
		if (typeSon == TYPESON.BRUITAGE){
			Main.setVolumeBruitage((int)((Son.MAXVOL-Son.MINVOL)*value*glob/100 + Son.MINVOL));
		}
		
		if (typeSon == TYPESON.GLOBAL){
			this.glob = slider.getValue();
			this.son.setVolume((int)(this.son.getVolume() + (Son.MAXVOL - Son.MINVOL)*(glob-5)/10));
			Main.setVolumeBruitage((int)((Main.getVolumeBruitage() - Son.MINVOL)*glob/10 + Son.MINVOL));
		
		}
		
	}
	
	
	
	

}

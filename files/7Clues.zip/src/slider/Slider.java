package slider;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;


public class Slider implements ChangeListener{
	
	final protected static Color beige = new Color(229,226,193); // necessaire ????
	final protected static Color bleu = new Color(39,99,110);
	
	protected int value; // valeur actuelle du slider
	private JPanel panel; // panel contenant le slider
	protected JSlider slider;
	
	public Slider (int depart, int fin, Dimension dim, int minPas, int maxPas, int initVal, Color couleur) {
		
		if (initVal > fin || initVal < depart) {
			throw new RuntimeException("valeur initial pour le curseur non valable");
		}
		panel = new JPanel();
		slider = new JSlider(depart,fin,initVal);
		
		// Customisation du Slider
		slider.setPreferredSize(dim);
		slider.setPaintTicks(true);
		slider.setMinorTickSpacing(minPas);	// petit trait
		slider.setPaintTrack(true);
		slider.setMajorTickSpacing(maxPas); // gros trait
		slider.setPaintLabels(true);
		slider.setFont(new Font("MV Boli",Font.PLAIN,11));
		slider.addChangeListener(this);
		slider.setForeground(Color.white);
		slider.setBackground(couleur);
		
		panel.add(slider);
		panel.setOpaque(false);
	}
	
	@Override
	public void stateChanged(ChangeEvent e) {
		value = slider.getValue();
	}
	
	public int getValue() {
		return this.value;
	}
	
	public JPanel getPanel() {
		return this.panel;
	}

}
